# AI PITO

Asisten AI melayang (bubble di pinggir layar) + scan layar + scan kamera.

## Build APK lewat GitHub
1. Upload semua isi folder ini ke repo GitHub (pastikan folder `.github` ikut).
2. Buka tab **Actions** -> workflow **Build APK** -> tunggu hijau (3-6 menit).
3. Klik run-nya, scroll ke **Artifacts**, download `AI-PITO-APK`, extract, install `app-debug.apk`.

## Tampilan
Intro animasi robot, bubble melayang, panel chat dengan efek mengetik.

## Pakai
Buka app, isi API key, Simpan, Aktifkan bubble.

Kolom API key boleh diisi BANYAK key sekaligus, dipisah koma. Penyedia dikenali dari awalan key:
- `AIza...`  -> Google Gemini (aistudio.google.com, ada jatah gratis)
- `gsk_...`  -> Groq (console.groq.com, Llama, ada jatah gratis)
- `sk-or-...` -> OpenRouter (openrouter.ai, model berlabel :free)
- `nvapi-...` -> NVIDIA NIM (build.nvidia.com, gratis, sekitar 40 permintaan/menit)
- `mistral=KEY` -> Mistral (console.mistral.ai, paket Experiment gratis, perlu verifikasi nomor HP; tulis awalan `mistral=`)
- `csk-...` atau `cerebras=KEY` -> Cerebras (cloud.cerebras.ai, gratis, sangat cepat; konteks gratis dibatasi sekitar 8K token)
- `sambanova=KEY` -> SambaNova Cloud (cloud.sambanova.ai, gratis, Llama; tulis awalan `sambanova=`)
- `cf=ACCOUNT_ID:TOKEN` -> selain gambar, dipakai juga sebagai cadangan chat lewat Cloudflare Workers AI (jatah gratis harian kecil)
- `sk-ant-...` -> Claude (berbayar)

Contoh: `AIzaXXXX, gsk_XXXX, sk-or-XXXX`

Kalau satu key kena limit (HTTP 429) atau error, app otomatis pindah ke key berikutnya.
Urutan = urutan penulisan, jadi taruh yang paling diandalkan di depan.


## Gambar AI
Ketik "buatkan gambar ..." atau "/gambar ...", atau ketuk tombol **Gambar** lalu tulis deskripsinya.
Permintaan otomatis diubah jadi prompt Inggris yang detail supaya hasilnya bagus.

Hasil terbaik (gratis, FLUX lewat Cloudflare Workers AI): tambahkan di kolom API key
`cf=ACCOUNT_ID:API_TOKEN` (dipisah koma dari key lain). Tanpa itu, app memakai Pollinations
(tanpa key, tapi bisa lambat atau dibatasi).


## Unduh video (TikTok, YouTube, Instagram, dll)
Tempel link https ke chat bubble. Video tersimpan di galeri (Movies/AI PITO).
- **TikTok**: langsung jalan, tanpa watermark (layanan tikwm.com).
- **Situs lain** (YouTube, Instagram, Facebook, X, Pinterest, Reddit, Vimeo, dll): butuh server Cobalt. Server publik cobalt.tools dibatasi, jadi pakai server sendiri atau milik orang yang mengizinkan. Tambahkan di kolom API key:
  `cobalt=https://alamat-server-cobalt-mu` dan (opsional) `cobaltkey=KEY`
- Situs yang tidak ada di daftar otomatis: awali pesan dengan `/unduh `.
- **Hanya MP3 (audio)**: ketuk tombol **MP3** di panel (mode MP3 aktif, semua link jadi audio), atau tulis `/mp3 link`, atau sebut kata `mp3`/`audio`/`lagu` di pesan bersama link. Hasil tersimpan di folder Music/AI PITO.

### Cobalt di Termux (lokal di HP)
Isi kolom API key:  `cobalt=http://127.0.0.1:9000`
Alamat http hanya diizinkan untuk 127.0.0.1 / localhost.


## Animasi & suara
- Saat app dibuka ada animasi pembuka (warp bintang, gelombang kejut, cincin neon, judul glitch, lalu layar utama terbuka seperti iris). Ketuk layar untuk melewati.
- Bubble bulat: halo bernapas, cincin gradasi berputar, riak, percikan mengorbit, ping hijau saat balasan datang, pink saat AI sedang berpikir. Bisa digeser, menempel ke pinggir dengan efek membal.
- Suara dibuat lewat kode (tanpa file audio): ketuk tombol, buka/tutup panel, balasan masuk, error, geser bubble. Bisa dimatikan lewat tombol SUARA di kartu Pengaturan.

## Stiker WhatsApp
- Di setiap gambar hasil (Gambar / Quote) ada tombol **Stiker**.
- Gambar diubah jadi WebP 512x512 dan dikumpulkan ke pack "AI PITO Stickers" (min 3, maks 30 stiker).
- Setelah ada 3 stiker, menekan **Stiker** membuka WhatsApp untuk menambahkan pack ke tab stiker (konfirmasi "Tambahkan").
- Stiker baru berikutnya akan memperbarui pack yang sama.

## .sa (stiker dari video / foto + suara)
- Ketik `.sa` (atau tekan chip **SA**), pilih **1 video** atau **1 foto + 1 audio/voice note** sekaligus. Atau lampirkan gambar lalu ketik `.sa`.
- Video (maks 6 detik dipakai) jadi **stiker gerak** di pack "AI PITO Animasi" (maks 500 KB, otomatis diturunkan kualitasnya kalau kegedean). Foto jadi stiker diam.
- Tombol **Stiker WA** menyimpan ke pack lalu membuka WhatsApp (min 3 stiker per pack).
- Tombol **Suara ke WA** mengirim audio video (atau audio yang dipilih) ke WhatsApp sebagai file audio.
- Catatan: suara yang menempel di dalam stiker (ikon speaker) hanya bisa dikirim klien WhatsApp seperti nara-bot. App Android tidak bisa, jadi suara dikirim terpisah.

- Key tanpa awalan sekarang dikenali otomatis: `mstrl_...` = Mistral, kode UUID (xxxxxxxx-xxxx-...) = SambaNova. Key `AQ.` otomatis dipindah ke urutan paling belakang.

- Animasi loading "sedang berpikir" diganti MorphLoader (Loader.kt): garis neon menggambar segi delapan, inti robot muncul membal, sinar pelangi menyembur dengan makhluk pixel, lalu mengulang tiap 4 detik.

## Pilih resolusi & FPS sebelum unduh
- Tempel link YouTube/Instagram/dll -> app tanya dulu: resolusi (360p / 480p / 720p / 1080p / Maks) dan, khusus YouTube, FPS (30 / 60). Lalu ketuk **Unduh**. Defaultnya 1080p + 60fps.
- TikTok dan mode MP3 langsung diunduh tanpa tanya (TikTok ikut kualitas aslinya). Tulis `4k` atau `hq` di pesan untuk langsung kualitas maksimal.
- Hasil menampilkan resolusi dan fps asli file (contoh: `1920×1080 • 60fps`).
- 60fps hanya didapat kalau videonya memang ada versi 60fps di YouTube.
- Server yt-dlp: `termux/pito-ytdlp-server.py` (salin ke `~/pito-ytdlp-server.py`, lalu `bash start-pito.sh` atau restart servernya).
