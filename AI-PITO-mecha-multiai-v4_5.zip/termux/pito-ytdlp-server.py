#!/usr/bin/env python3
"""Server kecil untuk AI PITO: menerima link YouTube lalu mengunduh pakai yt-dlp.
Jalankan di Termux:  python ~/pito-ytdlp-server.py
Alamat: http://127.0.0.1:9100  (hanya bisa diakses dari HP sendiri)
"""
import json
import os
import subprocess
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

HOST, PORT = "127.0.0.1", 9100
MOVIES = "/storage/emulated/0/Movies/AI PITO"
MUSIC = "/storage/emulated/0/Music/AI PITO"
YT_HOSTS = ("youtube.com", "youtu.be")
OUT_TMPL = "%(title).100B [%(id)s].%(ext)s"


def is_youtube(url):
    try:
        u = urlparse(url)
        h = (u.hostname or "").lower()
    except Exception:
        return False
    if u.scheme not in ("http", "https"):
        return False
    return any(h == d or h.endswith("." + d) for d in YT_HOSTS)


def build_cmd(url, audio, height, fps):
    """height: tinggi maksimal (0 = terbaik). fps: batas FPS (0 = bebas)."""
    cmd = ["yt-dlp", "--no-playlist", "--no-simulate", "--windows-filenames",
           "-o", OUT_TMPL,
           "--print", "after_move:TITLE=%(title)s",
           "--print", "after_move:RES=%(width|0)sx%(height|0)s",
           "--print", "after_move:FPS=%(fps|0)s",
           "--print", "after_move:FILE=%(filepath)s"]
    if audio:
        return cmd + ["-x", "--audio-format", "mp3", "-P", MUSIC, "--", url]

    # Batas resolusi & FPS. Tanda "?" = format yang datanya tidak diketahui tetap boleh.
    flt = ""
    if height > 0:
        flt += "[height<=?%d]" % height
    if fps > 0:
        flt += "[fps<=?%d]" % fps
    chain = []
    if 0 < height <= 1080:
        # h264 + m4a: paling aman diputar di galeri HP
        chain.append("bv*%s[vcodec^=avc1]+ba[ext=m4a]" % flt)
    chain.append("bv*%s+ba" % flt)   # kalau h264 tidak ada (mis. 1440p/4K): vp9/av1
    chain.append("b%s" % flt)
    # Urutkan: resolusi tertinggi yang muat batas, lalu FPS tertinggi (60 menang atas 30)
    cmd += ["-S", "res,fps", "-f", "/".join(chain),
            "--merge-output-format", "mp4/mkv", "-P", MOVIES]
    return cmd + ["--", url]


def download(url, audio, height, fps):
    if not is_youtube(url):
        return {"ok": False, "error": "link bukan YouTube"}
    p = subprocess.run(build_cmd(url, audio, height, fps), capture_output=True, text=True)
    info = {}
    for line in p.stdout.splitlines():
        for key in ("TITLE", "RES", "FPS", "FILE"):
            if line.startswith(key + "="):
                info[key] = line[len(key) + 1:]
    path = info.get("FILE", "")
    if p.returncode != 0 or not path or not os.path.exists(path):
        err = [l for l in p.stderr.splitlines() if l.strip()]
        msg = err[-1] if err else "yt-dlp gagal (kode %d)" % p.returncode
        return {"ok": False, "error": msg[:300]}
    w, _, h = info.get("RES", "0x0").partition("x")
    try:
        fps_real = int(round(float(info.get("FPS", "0"))))
    except ValueError:
        fps_real = 0
    return {"ok": True, "title": info.get("TITLE", ""), "file": path,
            "width": int(w) if w.isdigit() else 0,
            "height": int(h) if h.isdigit() else 0,
            "fps": fps_real}


class Handler(BaseHTTPRequestHandler):
    def _send(self, obj, code=200):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        self._send({"ok": True, "server": "pito-ytdlp"})

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length", "0"))
            body = json.loads(self.rfile.read(n) or b"{}")
            if "height" in body:
                height = max(0, int(body.get("height") or 0))
            else:  # app lama: hq = terbaik, selain itu 1080p
                height = 0 if body.get("hq") else 1080
            fps = max(0, int(body.get("fps") or 0))
            res = download(str(body.get("url", "")), bool(body.get("audio")), height, fps)
        except Exception as e:
            res = {"ok": False, "error": str(e)[:300]}
        self._send(res, 200 if res.get("ok") else 500)

    def log_message(self, fmt, *args):
        print("[pito-ytdlp]", fmt % args, flush=True)


if __name__ == "__main__":
    print("PITO yt-dlp server jalan di http://%s:%d  (Ctrl+C untuk berhenti)" % (HOST, PORT), flush=True)
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
