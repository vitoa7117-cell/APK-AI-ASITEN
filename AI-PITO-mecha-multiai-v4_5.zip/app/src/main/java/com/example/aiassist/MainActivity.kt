package com.example.aiassist

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.text.Spannable
import android.text.SpannableString
import android.text.method.PasswordTransformationMethod
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun typewriter(tv: TextView, full: String, delay: Long) {
        tv.text = ""
        var i = 0
        val r = object : Runnable {
            override fun run() {
                i++
                tv.text = full.substring(0, i)
                if (i < full.length) handler.postDelayed(this, 28)
            }
        }
        handler.postDelayed(r, delay)
    }

    private fun lp(
        w: Int = ViewGroup.LayoutParams.MATCH_PARENT,
        h: Int = ViewGroup.LayoutParams.WRAP_CONTENT,
        top: Int = 0
    ) = LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

    // ---------- komponen kecil ----------

    private fun label(t: String) = TextView(this).apply {
        text = t
        setTextColor(0xFFE69FAB.toInt())
        textSize = 12.5f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        letterSpacing = 0.04f
        setPadding(dp(2), dp(14), 0, dp(7))
    }

    private fun fieldBg(): StateListDrawable {
        val focused = CutDrawable().apply {
            setColor(0xFF1E060A.toInt()); cornerRadius = dp(14).toFloat(); setStroke(dp(2), Fx.CYAN)
        }
        val normal = CutDrawable().apply {
            setColor(0xFF1E060A.toInt()); cornerRadius = dp(14).toFloat(); setStroke(dp(1), 0x44FF6E86)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    private fun edit(hintText: String, value: String, secret: Boolean): EditText = EditText(this).apply {
        setText(value)
        hint = hintText
        setHintTextColor(0xFF905B64.toInt())
        setTextColor(Fx.INK)
        textSize = 15f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setSingleLine()
        background = fieldBg()
        setPadding(dp(16), dp(14), dp(48), dp(14))
        if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    /** Kotak field + ikon di kanan. [trailing] dipasang ke ImageView yang dikembalikan lewat callback. */
    private fun fieldBox(input: EditText, iconRes: Int, onIcon: (() -> Unit)?): FrameLayout {
        val box = FrameLayout(this)
        box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        val ic = ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Fx.MUTE)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            if (onIcon != null) setOnClickListener { onIcon() }
        }
        box.addView(ic, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = dp(12)
        })
        return box
    }

    private fun iconBox(res: Int, color: Int, size: Int, radius: Int): ImageView = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(color)
        val pad = dp(size / 4)
        setPadding(pad, pad, pad, pad)
        background = CutDrawable().apply {
            cornerRadius = dp(radius).toFloat()
            setColor(Fx.alpha(color, 48))
            setStroke(dp(1), Fx.alpha(color, 150))
        }
    }

    private fun header(iconRes: Int, title: String, sub: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(iconBox(iconRes, Fx.CYAN, 34, 10), LinearLayout.LayoutParams(dp(34), dp(34)))
        addView(TextView(context).apply {
            text = title
            setTextColor(Fx.INK)
            textSize = 14f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            letterSpacing = 0.14f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(11) })
        addView(TextView(context).apply {
            text = sub
            setTextColor(Fx.MUTE)
            textSize = 9f
            letterSpacing = 0.18f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
    }

    private fun tile(iconRes: Int, color: Int, title: String, desc: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = CutDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(0x14FFFFFF)
            setStroke(dp(1), Fx.alpha(color, 70))
        }
        setPadding(dp(13), dp(14), dp(13), dp(15))
        addView(iconBox(iconRes, color, 38, 12), LinearLayout.LayoutParams(dp(38), dp(38)))
        addView(TextView(context).apply {
            text = title
            setTextColor(Fx.INK)
            textSize = 10.5f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            letterSpacing = 0.08f
        }, lp(top = 11))
        addView(TextView(context).apply {
            text = desc
            setTextColor(0xFFDEA9B2.toInt())
            textSize = 12.5f
            setLineSpacing(0f, 1.1f)
        }, lp(top = 4))
    }

    private fun row(a: View, b: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { rightMargin = dp(6) })
        addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { leftMargin = dp(6) })
    }

    private fun openUrl(url: String) {
        if (url.contains("XXXX")) {
            Toast.makeText(this, "Kontak penjual belum diatur (isi BUY_KEY_URL di Prefs.kt)", Toast.LENGTH_LONG).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun bodyText(t: String, color: Int = 0xFFDEA9B2.toInt()) = TextView(this).apply {
        text = t
        setTextColor(color)
        textSize = 12.5f
        setLineSpacing(0f, 1.15f)
    }

    /** Satu langkah panduan: judul penyedia + isi + tombol buka situs. */
    private fun guideStep(color: Int, title: String, steps: String, btn: String, url: String): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CutDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0x14FFFFFF)
                setStroke(dp(1), Fx.alpha(color, 80))
            }
            setPadding(dp(13), dp(12), dp(13), dp(12))
            addView(TextView(context).apply {
                text = title
                setTextColor(color)
                textSize = 11.5f
                typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
                letterSpacing = 0.06f
            }, lp())
            addView(bodyText(steps), lp(top = 5))
            addView(
                Ui.pill(context, btn, Ui.rounded(Fx.alpha(color, 40), dp(12), Fx.alpha(color, 150), dp(1)), Fx.INK, 12f) {
                    openUrl(url)
                },
                lp(w = ViewGroup.LayoutParams.WRAP_CONTENT, top = 9)
            )
        }

    /** Bagian lipat: ketuk judul untuk buka/tutup. */
    private fun fold(title: String, color: Int, body: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val head = TextView(context).apply {
            text = "▸  $title"
            setTextColor(color)
            textSize = 11.5f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            letterSpacing = 0.06f
            setPadding(dp(2), dp(12), dp(2), dp(12))
            isClickable = true
        }
        Ui.pressable(head)
        body.visibility = View.GONE
        head.setOnClickListener {
            val open = body.visibility == View.GONE
            body.visibility = if (open) View.VISIBLE else View.GONE
            head.text = (if (open) "▾  " else "▸  ") + title
        }
        addView(head, lp())
        addView(body, lp().apply { bottomMargin = dp(12) })
    }

    private val entrances = ArrayList<() -> Unit>()
    private fun later(b: () -> Unit) { entrances.add(b) }
    private fun runEntrances() {
        val l = ArrayList(entrances)
        entrances.clear()
        l.forEach { it() }
    }

    private fun soundLabel() = if (Prefs.soundOn(this)) "🔊 ON" else "🔇 OFF"

    // ---------- layar utama ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Sfx.init(this)
        window.statusBarColor = Fx.BG
        window.navigationBarColor = Fx.BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(20), dp(16), dp(22))
        }

        // ===== bar atas (status kecil) =====
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val status = TextView(this).apply {
            val s = SpannableString("●  ONLINE")
            s.setSpan(ForegroundColorSpan(Fx.GREEN), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            text = s
            textSize = 10f
            setTextColor(Fx.CYAN)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = 0.14f
            background = Ui.rounded(0x14FF2537, dp(20), 0x47FF2537, dp(1))
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        val snd = TextView(this).apply {
            text = soundLabel()
            textSize = 11f
            setTextColor(Fx.MUTE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(dp(8), dp(4), dp(2), dp(4))
            isClickable = true
            setOnClickListener {
                val on = !Prefs.soundOn(context)
                Prefs.setSound(context, on)
                Sfx.enabled = on
                text = soundLabel()
                if (on) Sfx.play("open")
            }
        }
        top.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(snd, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(top, lp())
        later { Ui.enter(top, 100, dp(-16).toFloat()) }

        // ===== kepala: robot kecil + judul di sebelahnya =====
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val robot = MechaFace(this)
        head.addView(robot, LinearLayout.LayoutParams(dp(110), dp(110)))
        robot.alpha = 0f
        robot.scaleX = 0.6f
        robot.scaleY = 0.6f
        later {
            robot.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(800)
                .setInterpolator(android.view.animation.OvershootInterpolator(1.4f)).start()
        }
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = ShimmerTitle(this).apply { textSize = 30f; gravity = Gravity.START }
        titleCol.addView(title, lp())
        val sub = TextView(this).apply {
            setTextColor(0xFFE8A9B4.toInt())
            textSize = 10f
            letterSpacing = 0.1f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            minHeight = dp(18)
        }
        titleCol.addView(sub, lp(top = 6))
        head.addView(titleCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) })
        root.addView(head, lp(top = 6))
        later { Ui.enter(head, 600, dp(24).toFloat()) }
        later { typewriter(sub, "ASISTEN AI  •  CODING  •  SCAN", 1000) }

        // ===== kartu pengaturan (ringkas) =====
        val keyIn = edit("AIza... , gsk_... , sk-or-... , csk-... , sambanova=... , mistral=... (pisah koma)", Prefs.apiKey(this), true)
        val modelIn = edit(Prefs.DEFAULT_MODEL, Prefs.model(this), false)
        var shown = false
        val keyBox = fieldBox(keyIn, R.drawable.ic_eye) {
            shown = !shown
            val sel = keyIn.selectionStart
            keyIn.transformationMethod = if (shown) null else PasswordTransformationMethod.getInstance()
            if (sel >= 0) keyIn.setSelection(sel)
        }
        val modelBox = fieldBox(modelIn, R.drawable.ic_bolt, null)

        val save = GlowButton(this, "SIMPAN", R.drawable.ic_save, GlowButton.CYAN)
        Ui.pressable(save)
        save.setOnClickListener {
            Prefs.save(this, keyIn.text.toString(), modelIn.text.toString())
            Toast.makeText(this, "Tersimpan ✓", Toast.LENGTH_SHORT).show()
        }

        val c1 = HudCard(this)
        c1.setPadding(dp(14), dp(12), dp(14), dp(12))
        c1.addView(header(R.drawable.ic_key, "API KEY", "// CONFIG"), lp())
        c1.addView(keyBox, lp(top = 10))
        c1.addView(
            fold("Model (opsional)", Fx.MUTE, LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(bodyText("Biarkan default kalau bingung.", Fx.MUTE), lp())
                addView(modelBox, lp(top = 6))
            }), lp()
        )
        c1.addView(save, lp(h = dp(44 + 16), top = 2))
        root.addView(c1, lp(top = 14))
        later { Ui.enter(c1, 1100, dp(40).toFloat()) }

        // ===== tombol aksi: sejajar =====
        val go = GlowButton(this, "AKTIFKAN", R.drawable.ic_rocket, GlowButton.PRIMARY)
        Ui.pressable(go)
        go.setOnClickListener {
            Prefs.save(this, keyIn.text.toString(), modelIn.text.toString())
            startBubble()
        }
        val off = GlowButton(this, "MATIKAN", R.drawable.ic_power, GlowButton.PINK)
        Ui.pressable(off)
        off.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Bubble dimatikan", Toast.LENGTH_SHORT).show()
        }
        val c2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        c2.addView(go, LinearLayout.LayoutParams(0, dp(56 + 16), 1.25f))
        c2.addView(off, LinearLayout.LayoutParams(0, dp(56 + 16), 1f))
        root.addView(c2, lp(top = 6))
        later { Ui.enter(c2, 1250, dp(40).toFloat()) }

        // ===== info tambahan: dilipat semua =====
        val guideBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bodyText("Pilih salah satu, salin key-nya, tempel di kolom API key, lalu SIMPAN. Boleh isi banyak key (pisah koma), kalau kena limit otomatis pindah."), lp())
            addView(guideStep(Fx.CYAN, "GOOGLE GEMINI  (paling gampang)", "Login Google > Create API key > salin yang diawali AIza...", "BUKA AI STUDIO", "https://aistudio.google.com/apikey"), lp(top = 10))
            addView(guideStep(Fx.VIOLET, "GROQ  (cepat, Llama)", "Daftar/login > Create API Key > salin yang diawali gsk_...", "BUKA GROQ", "https://console.groq.com/keys"), lp(top = 8))
            addView(guideStep(Fx.GREEN, "OPENROUTER  (model :free)", "Daftar/login > Create Key > salin yang diawali sk-or-...", "BUKA OPENROUTER", "https://openrouter.ai/keys"), lp(top = 8))
            addView(guideStep(Fx.CYAN, "NVIDIA NIM  (gratis, banyak model)", "Daftar/login > buat API key > salin yang diawali nvapi-...", "BUKA NVIDIA", "https://build.nvidia.com"), lp(top = 8))
            addView(guideStep(Fx.VIOLET, "MISTRAL  (paket Experiment gratis)", "Butuh verifikasi nomor HP. Salin key lalu tempel saja (awalan mistral= boleh dipakai boleh tidak)", "BUKA MISTRAL", "https://console.mistral.ai"), lp(top = 8))
            addView(guideStep(Fx.GREEN, "CEREBRAS  (gratis, sangat cepat)", "Daftar/login > API Keys > salin yang diawali csk-... (atau tulis cerebras=KEYMU)", "BUKA CEREBRAS", "https://cloud.cerebras.ai"), lp(top = 8))
            addView(guideStep(Fx.CYAN, "SAMBANOVA  (gratis, Llama)", "Daftar/login > API Keys > salin key lalu tempel saja (awalan sambanova= boleh dipakai boleh tidak)", "BUKA SAMBANOVA", "https://cloud.sambanova.ai"), lp(top = 8))
            addView(bodyText("Cloudflare: key cf=ACCOUNT_ID:TOKEN yang dipakai untuk gambar juga jadi cadangan chat (jatah gratis harian kecil).", Fx.MUTE), lp(top = 8))
            addView(bodyText("Jangan bagikan key-mu ke siapa pun.", Fx.MUTE), lp(top = 10))
        }
        val buyBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bodyText("Malas daftar? Beli dari admin PITO: key AI (chat, scan, foto soal), paket gambar HD, paket unduh video. Bayar, key dikirim, tempel, selesai."), lp())
            val buy = GlowButton(context, "BELI KEY INSTAN", R.drawable.ic_rocket, GlowButton.CYAN)
            Ui.pressable(buy)
            buy.setOnClickListener { openUrl(Prefs.BUY_KEY_URL) }
            addView(buy, lp(h = dp(44 + 16), top = 4))
        }
        val skillBody = bodyText(
            "• Tanya apa pun & bantu coding\n• Scan layar, AI langsung menjawab\n• Foto soal / dokumen\n" +
                "• Unduh video (tempel link https)\n• Buat gambar dari deskripsi\n• Bubble melayang di pinggir layar"
        )
        fun divider() = View(this).apply { setBackgroundColor(Fx.alpha(Fx.CYAN, 30)) }

        val c3 = HudCard(this)
        c3.setPadding(dp(14), dp(2), dp(14), dp(2))
        c3.addView(fold("CARA DAPAT KEY GRATIS", Fx.CYAN, guideBody), lp())
        c3.addView(divider(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
        c3.addView(fold("BELI KEY INSTAN", Fx.PINK, buyBody), lp())
        c3.addView(divider(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
        c3.addView(fold("BISA APA AJA?", Fx.VIOLET, skillBody), lp())
        root.addView(c3, lp(top = 10))
        later { Ui.enter(c3, 1400, dp(40).toFloat()) }

        val foot = TextView(this).apply {
            text = "POWERED BY ◆ PITO NEURAL ENGINE"
            textSize = 8.5f
            setTextColor(0xFF905B64.toInt())
            letterSpacing = 0.22f
            gravity = Gravity.CENTER
        }
        root.addView(foot, lp(top = 14))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            addView(root)
        }
        val screen = FrameLayout(this)
        screen.addView(AuroraBackground(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        screen.addView(VideoBackground(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // lapisan gelap tipis biar tulisan tetap terbaca di atas video
        screen.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x66080204, 0x99080204.toInt(), 0xDD080204.toInt())
            )
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        screen.addView(EmberView(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        screen.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(screen)

        if (savedInstanceState == null) {
            val intro = IntroView(this)
            screen.addView(
                intro,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
            intro.onReveal = { runEntrances() }
            intro.onFinish = { screen.removeView(intro) }
        } else {
            runEntrances()
        }
    }

    private fun startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan 'tampil di atas aplikasi lain', lalu balik dan ketuk lagi", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Bubble aktif 🤖", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
