package com.example.aiassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Animasi pembuka: warp-speed bintang, gelombang kejut, cincin neon + tick loader,
 * judul glitch dengan pemisahan warna (chromatic), lalu "iris" membuka layar utama.
 * Semua digambar langsung di Canvas, sinkron dengan suara intro dari Sfx.
 */
class IntroView(ctx: Context) : View(ctx) {
    var onReveal: (() -> Unit)? = null
    var onFinish: (() -> Unit)? = null

    private companion object {
        const val T_EXIT = 2.35f
        const val T_END = 2.95f
        const val N = 120
    }

    private val d = resources.displayMetrics.density
    private val icon = ctx.getDrawable(R.drawable.ic_robot_bubble)

    private val bgP = Paint().apply { color = Fx.BG }
    private val starP = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dashP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(2f * d, 7f * d), 0f)
        strokeWidth = 1.5f * d
    }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val scanP = Paint()
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        textSize = Fx.sp(ctx, 40f)
        letterSpacing = 0.22f
    }
    private val subP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        textSize = Fx.sp(ctx, 11f)
        letterSpacing = 0.35f
    }
    private val barP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trackP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x28FFFFFF }
    private val clearP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }
    private val sweepM = Matrix()
    private var sweep: SweepGradient? = null
    private var coreGlow: RadialGradient? = null
    private var barShader: LinearGradient? = null

    private val rnd = Random(42)
    private val sa = FloatArray(N) { rnd.nextFloat() * 6.2832f }
    private val ss = FloatArray(N) { 0.35f + rnd.nextFloat() * 0.65f }
    private val so = FloatArray(N) { rnd.nextFloat() }
    private var warpPhase = 0f

    private var startMs = -1L
    private var lastT = 0f
    private var lastTick = -1
    private var revealed = false
    private var finished = false
    private val waitSince = SystemClock.uptimeMillis()

    private val title = "AI PITO"
    private val sub = "NEURAL CORE ONLINE"

    init {
        isClickable = true
        setOnClickListener { skip() }
    }

    private fun skip() {
        if (startMs < 0) return
        val t = (SystemClock.uptimeMillis() - startMs) / 1000f
        if (t < T_EXIT) startMs -= ((T_EXIT - t) * 1000).toLong()
    }

    private fun eo(x: Float): Float {
        val k = x.coerceIn(0f, 1f)
        return 1f - (1f - k) * (1f - k) * (1f - k)
    }

    private fun ob(x: Float): Float {
        val k = x.coerceIn(0f, 1f) - 1f
        val c1 = 1.70158f
        return 1f + (c1 + 1f) * k * k * k + c1 * k * k
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val cx = w / 2f
        val cy = h * 0.38f
        sweep = SweepGradient(
            cx, cy,
            intArrayOf(Fx.clear(Fx.CYAN), Fx.CYAN, Fx.PINK, Fx.clear(Fx.PINK), Fx.clear(Fx.CYAN)),
            floatArrayOf(0f, 0.35f, 0.6f, 0.75f, 1f)
        )
        val gr = hypot(w.toFloat(), h.toFloat()) * 0.25f
        coreGlow = RadialGradient(
            cx, cy, gr,
            intArrayOf(Fx.alpha(Fx.CYAN, 200), Fx.alpha(Fx.VIOLET, 70), Fx.clear(Fx.VIOLET)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        barShader = LinearGradient(w * 0.22f, 0f, w * 0.78f, 0f, Fx.CYAN, Fx.PINK, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val w = width.toFloat()
        val h = height.toFloat()
        if (startMs < 0) {
            if (Sfx.ready("intro") || now - waitSince > 500) {
                startMs = now
                Sfx.play("intro")
            } else {
                c.drawRect(0f, 0f, w, h, bgP)
                postInvalidateOnAnimation()
                return
            }
        }
        val t = (now - startMs) / 1000f
        val dt = (t - lastT).coerceIn(0f, 0.1f)
        lastT = t

        val cx = w / 2f
        val cy = h * 0.38f
        val maxR = hypot(w, h) / 2f
        val prog = ((t - 0.2f) / 2.0f).coerceIn(0f, 1f)

        val layer = c.saveLayer(0f, 0f, w, h, null)
        c.drawRect(0f, 0f, w, h, bgP)

        // --- glow inti (berdenyut, lonjakan saat "hit" di detik 1.0) ---
        val g = (0.25f + 0.15f * sin(t * 5f) + 0.75f * max(0f, 1f - abs(t - 1f) * 2.5f)).coerceIn(0f, 1f)
        glowP.shader = coreGlow
        glowP.alpha = (255 * g).toInt()
        c.drawCircle(cx, cy, hypot(w, h) * 0.25f, glowP)

        // --- warp bintang ---
        val wi = if (t < 1f) 0.3f + 0.7f * t else max(0f, 1f - (t - 1f) / 0.9f)
        warpPhase += dt * (0.25f + 2.4f * wi)
        val starFade = 1f - 0.6f * eo((t - 1.6f) / 0.7f)
        for (i in 0 until N) {
            val k = (so[i] + warpPhase * ss[i]) % 1f
            val rho = k * k * maxR
            val len = rho * (0.04f + 0.22f * wi)
            val ca = cos(sa[i])
            val sn = sin(sa[i])
            starP.strokeWidth = (0.6f + 1.8f * k) * d
            val a = (k * 255 * (0.4f + 0.6f * (0.4f + wi)) * starFade).toInt().coerceIn(0, 255)
            starP.color = Fx.alpha(if (i % 3 == 0) Fx.CYAN else Color.WHITE, a)
            c.drawLine(cx + ca * (rho - len), cy + sn * (rho - len), cx + ca * rho, cy + sn * rho, starP)
        }

        // --- garis scan ---
        val sy = ((t * 0.7f) % 1f) * h
        scanP.color = Fx.alpha(Fx.CYAN, (30 * starFade).toInt())
        c.drawRect(0f, sy, w, sy + 2f * d, scanP)

        // --- cincin inti ---
        val ra = ((t - 0.15f) / 0.3f).coerceIn(0f, 1f)
        val rr = maxR * 0.8f + (62f * d - maxR * 0.8f) * eo((t - 0.2f) / 0.8f)
        sweepM.setRotate(t * 220f, cx, cy)
        sweep?.setLocalMatrix(sweepM)
        ringP.shader = sweep
        ringP.strokeWidth = 3f * d
        ringP.alpha = (255 * ra).toInt()
        c.drawCircle(cx, cy, rr, ringP)
        ringP.shader = null

        dashP.color = Fx.alpha(Fx.VIOLET, (190 * ra).toInt())
        c.save()
        c.rotate(-t * 60f, cx, cy)
        c.drawCircle(cx, cy, rr - 10f * d, dashP)
        c.restore()

        // tick loader mengelilingi cincin
        starP.strokeWidth = 1.6f * d
        for (i in 0 until 60) {
            val lit = i / 60f < prog
            val ang = i / 60f * 2f * PI.toFloat() - PI.toFloat() / 2f
            val r0 = rr + 8f * d
            val r1 = r0 + (if (lit) 7f else 4f) * d
            starP.color = if (lit) {
                Fx.alpha(if (i % 5 == 0) Fx.PINK else Fx.CYAN, (230 * ra).toInt())
            } else {
                Fx.alpha(Fx.MUTE, (60 * ra).toInt())
            }
            c.drawLine(cx + cos(ang) * r0, cy + sin(ang) * r0, cx + cos(ang) * r1, cy + sin(ang) * r1, starP)
        }

        // --- gelombang kejut ---
        for (t0 in floatArrayOf(1.0f, 1.12f)) {
            val p = (t - t0) / 0.9f
            if (p in 0f..1f) {
                ringP.strokeWidth = (5f * (1f - p) + 1f) * d
                ringP.color = Fx.alpha(Fx.CYAN, ((1f - p) * 200).toInt())
                c.drawCircle(cx, cy, eo(p) * maxR * 0.9f, ringP)
            }
        }

        // --- robot ---
        icon?.let {
            val s = ob((t - 0.45f) / 0.65f)
            val sz = 68f * d * s
            val jit = if (t in 0.6f..1.0f && ((t * 40f).toInt() % 7 == 0)) 3f * d else 0f
            it.alpha = (255 * s.coerceIn(0f, 1f)).toInt()
            it.setBounds(
                (cx - sz / 2f + jit).toInt(), (cy - sz / 2f).toInt(),
                (cx + sz / 2f + jit).toInt(), (cy + sz / 2f).toInt()
            )
            it.draw(c)
        }

        // --- judul: reveal kiri->kanan + chromatic + potongan glitch ---
        val tw = textP.measureText(title)
        val x0 = cx - tw / 2f
        val yT = cy + 62f * d + 74f * d
        val rp = eo((t - 1.0f) / 0.55f)
        if (rp > 0f) {
            val off = (1f - rp) * 14f * d
            c.save()
            c.clipRect(x0 - 8f * d, yT - 60f * d, x0 - 8f * d + (tw + 16f * d) * rp, yT + 20f * d)
            textP.color = Fx.alpha(Fx.PINK, (200 * rp).toInt())
            c.drawText(title, x0 - off, yT, textP)
            textP.color = Fx.alpha(Fx.CYAN, (200 * rp).toInt())
            c.drawText(title, x0 + off, yT, textP)
            textP.color = Fx.alpha(Fx.INK, (255 * rp).toInt())
            c.drawText(title, x0, yT, textP)
            c.restore()
            if (t in 1.0f..1.5f) {
                val gr = Random((t * 25f).toInt().toLong())
                repeat(3) {
                    val top = yT - 44f * d + gr.nextFloat() * 50f * d
                    val hh = 6f * d + gr.nextFloat() * 10f * d
                    val dx = (gr.nextFloat() - 0.5f) * 30f * d
                    c.save()
                    c.clipRect(x0 - 20f * d, top, x0 + tw + 20f * d, top + hh)
                    textP.color = Fx.CYAN
                    c.drawText(title, x0 + dx, yT, textP)
                    c.restore()
                }
            }
        }

        // --- subjudul ---
        val sa2 = eo((t - 1.5f) / 0.5f)
        if (sa2 > 0f) {
            subP.color = Fx.alpha(Fx.CYAN, (200 * sa2).toInt())
            c.drawText(sub, cx - subP.measureText(sub) / 2f, yT + 30f * d, subP)
        }

        // --- progress bawah ---
        val tk = (prog * 10).toInt()
        if (tk != lastTick) {
            lastTick = tk
            if (tk > 0) Sfx.play("tick")
        }
        val label = if (prog < 1f) "INITIALIZING  ${(prog * 100).toInt()}%" else "READY"
        subP.color = Fx.alpha(Fx.MUTE, 230)
        val by = h * 0.88f
        c.drawText(label, cx - subP.measureText(label) / 2f, by, subP)
        val bl = w * 0.22f
        val bw = w * 0.56f
        c.drawRoundRect(bl, by + 14f * d, bl + bw, by + 17f * d, 2f * d, 2f * d, trackP)
        barP.shader = barShader
        c.drawRoundRect(bl, by + 14f * d, bl + bw * prog, by + 17f * d, 2f * d, 2f * d, barP)

        // --- iris: lubang bulat membesar, membuka layar utama ---
        val q = ((t - T_EXIT) / (T_END - T_EXIT)).coerceIn(0f, 1f)
        val hole = q * q * maxR * 1.1f
        if (q > 0f) c.drawCircle(cx, cy, hole, clearP)
        c.restoreToCount(layer)

        if (q > 0f) {
            ringP.shader = null
            ringP.strokeWidth = 3f * d
            ringP.color = Fx.alpha(Fx.CYAN, ((1f - q) * 255).toInt())
            c.drawCircle(cx, cy, hole, ringP)
            if (!revealed) {
                revealed = true
                post { onReveal?.invoke() }
            }
        }
        if (t >= T_END) {
            if (!finished) {
                finished = true
                post { onFinish?.invoke() }
            }
            return
        }
        postInvalidateOnAnimation()
    }
}
