package com.example.aiassist

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.MimeTypeMap
import java.io.File

/** Pilih video, atau foto + audio/voice note (bisa pilih beberapa sekaligus), lalu salin ke cache. */
class PickActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "image/*", "audio/*"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try {
            startActivityForResult(i, 7)
        } catch (e: Exception) {
            Bridge.onCancel?.invoke()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uris = ArrayList<Uri>()
        if (resultCode == RESULT_OK && data != null) {
            data.clipData?.let { for (k in 0 until it.itemCount) uris.add(it.getItemAt(k).uri) }
            if (uris.isEmpty()) data.data?.let { uris.add(it) }
        }
        if (uris.isEmpty()) {
            Bridge.onCancel?.invoke()
            finish()
            return
        }
        Thread {
            val out = ArrayList<Pair<File, String>>()
            try {
                uris.take(3).forEachIndexed { idx, u ->
                    val mime = contentResolver.getType(u) ?: ""
                    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
                    val f = File(cacheDir, "sa_in_$idx.$ext")
                    contentResolver.openInputStream(u)?.use { ins -> f.outputStream().use { ins.copyTo(it) } }
                    out.add(f to mime)
                }
            } catch (_: Exception) {
            }
            runOnUiThread {
                finish()
                if (out.isEmpty()) Bridge.onCancel?.invoke() else Bridge.onPick?.invoke(out)
            }
        }.start()
    }
}
