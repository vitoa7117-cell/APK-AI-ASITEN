package com.example.aiassist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * Cadangan kalau Accessibility Scan belum aktif / Android < 11.
 * Sekali jepret: berbagi layar otomatis berhenti setelah satu kali capture.
 */
class CaptureService : Service() {

    companion object {
        @Volatile var instance: CaptureService? = null
        private const val CH = "capture"
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()
    private var frame: Bitmap? = null
    private var w = 0
    private var h = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")

        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, main)

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        w = dm.widthPixels
        h = dm.heightPixels

        thread = HandlerThread("capture").also { it.start() }
        val bg = Handler(thread!!.looper)
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = img.planes[0]
                val bw = plane.rowStride / plane.pixelStride
                synchronized(lock) {
                    var f = frame
                    if (f == null || f.width != bw || f.height != img.height) {
                        f?.recycle()
                        f = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
                        frame = f
                    }
                    plane.buffer.rewind()
                    f!!.copyPixelsFromBuffer(plane.buffer)
                }
            } finally {
                img.close()
            }
        }, bg)

        display = proj.createVirtualDisplay(
            "ai-assist", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, null
        )
        instance = this
        main.postDelayed({ capture() }, 900)
        return START_NOT_STICKY
    }

    /** Ambil frame terakhir lalu kirim lewat Bridge. */
    fun capture() {
        val out: Bitmap? = synchronized(lock) {
            frame?.let { Bitmap.createBitmap(it, 0, 0, minOf(w, it.width), minOf(h, it.height)) }
        }
        if (out != null) Bridge.onImage?.invoke(out) else Bridge.onCancel?.invoke()
        // Sekali jepret: langsung hentikan berbagi layar setelah selesai scan.
        main.post { stopSelf() }
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Scan layar", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, CH)
            .setContentTitle("Scan layar aktif")
            .setContentText("AI PITO siap membaca layar")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(2, n)
    }

    override fun onDestroy() {
        instance = null
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        synchronized(lock) { frame?.recycle(); frame = null }
        super.onDestroy()
    }
}
