package com.example.aiassist

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/** Efek suara sintetis: dibuat lewat kode (tanpa file audio), jadi ukuran APK tidak nambah. */
object Sfx {
    private const val SR = 22050
    private val tracks = HashMap<String, AudioTrack>()
    @Volatile private var started = false
    @Volatile var enabled = true

    fun init(c: Context) {
        if (started) return
        started = true
        val app = c.applicationContext
        enabled = Prefs.soundOn(app)
        Thread {
            try {
                // intro duluan supaya siap saat animasi pembuka mulai
                build(
                    "intro",
                    mix(
                        2800,
                        0 to tone(120f, 1400f, 1100, 0.16f, 0.3f, rise = true),
                        0 to whoosh(1200, 0.5f, true),
                        1000 to tone(55f, 40f, 500, 0.40f),
                        1000 to tone(523f, 523f, 900, 0.12f, 0.25f),
                        1000 to tone(659f, 659f, 900, 0.12f, 0.25f),
                        1000 to tone(784f, 784f, 900, 0.12f, 0.25f),
                        1000 to tone(1047f, 1047f, 900, 0.09f, 0.2f)
                    )
                )
                build("tap", tone(1250f, 760f, 45, 0.28f))
                build("open", mix(170, 0 to tone(520f, 1000f, 90, 0.30f, 0.2f), 60 to tone(900f, 1600f, 110, 0.22f)))
                build("close", tone(950f, 420f, 100, 0.28f))
                build("recv", mix(320, 0 to tone(880f, 880f, 300, 0.25f, 0.3f), 70 to tone(1320f, 1320f, 240, 0.18f)))
                build("error", mix(300, 0 to tone(190f, 150f, 130, 0.35f, 0.8f), 150 to tone(170f, 120f, 150, 0.35f, 0.8f)))
                build("ping", tone(700f, 260f, 70, 0.30f))
                build("tick", tone(2600f, 2600f, 14, 0.18f))
            } catch (e: Exception) {
                // kalau perangkat menolak, app tetap jalan tanpa suara
            }
        }.start()
    }

    fun ready(name: String): Boolean = synchronized(tracks) { tracks.containsKey(name) }

    fun play(name: String) {
        if (!enabled) return
        val t = synchronized(tracks) { tracks[name] } ?: return
        try {
            t.stop()
            t.reloadStaticData()
            t.play()
        } catch (e: Exception) {
        }
    }

    // ---------- sintesis ----------

    private fun n(ms: Int) = SR * ms / 1000

    /** Nada dengan sapuan frekuensi f0 -> f1. rise=true: makin keras (untuk sapuan naik). */
    private fun tone(f0: Float, f1: Float, ms: Int, vol: Float, harm: Float = 0f, rise: Boolean = false): FloatArray {
        val len = n(ms)
        val out = FloatArray(len)
        var ph = 0.0
        for (i in 0 until len) {
            val p = i / len.toFloat()
            val f = f0 + (f1 - f0) * p
            ph += 2.0 * PI * f / SR
            val atk = min(1f, i / (SR * 0.004f))
            val env = if (rise) p * p else exp(-4f * p)
            val s = sin(ph).toFloat() + harm * sin(2.0 * ph).toFloat()
            out[i] = s * atk * env * vol
        }
        return out
    }

    /** Desir angin: noise yang disaring, naik atau turun. */
    private fun whoosh(ms: Int, vol: Float, rise: Boolean): FloatArray {
        val len = n(ms)
        val out = FloatArray(len)
        val rnd = Random(7)
        var lp = 0f
        for (i in 0 until len) {
            val p = i / len.toFloat()
            val q = if (rise) p else 1f - p
            val k = 0.04f + 0.5f * q * q
            lp += k * ((rnd.nextFloat() * 2f - 1f) - lp)
            val env = sin(PI.toFloat() * p)
            out[i] = lp * env * vol * 3f
        }
        return out
    }

    private fun mix(totalMs: Int, vararg parts: Pair<Int, FloatArray>): FloatArray {
        val out = FloatArray(n(totalMs))
        for ((at, a) in parts) {
            val o = n(at)
            for (i in a.indices) if (o + i < out.size) out[o + i] += a[i]
        }
        return out
    }

    private fun pcm(f: FloatArray): ShortArray {
        var m = 0f
        for (v in f) m = maxOf(m, abs(v))
        val g = if (m > 0.95f) 0.95f / m else 1f
        return ShortArray(f.size) { (f[it] * g * 32000f).toInt().coerceIn(-32767, 32767).toShort() }
    }

    private fun build(name: String, f: FloatArray) {
        val s = pcm(f)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(s.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(s, 0, s.size)
        synchronized(tracks) { tracks[name] = t }
    }
}
