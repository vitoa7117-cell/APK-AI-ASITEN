package com.example.aiassist

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Pengganti GradientDrawable: sudutnya dipotong miring (chamfer) supaya semua
 * kotak, tombol, dan gelembung terlihat tajam ala mecha. Bentuk OVAL jadi segi delapan.
 */
class CutDrawable() : Drawable() {
    constructor(orientation: GradientDrawable.Orientation, colors: IntArray) : this() {
        this.orientation = orientation
        this.colors = colors
    }

    companion object {
        const val RECTANGLE = 0
        const val OVAL = 1
    }

    var shape: Int = RECTANGLE
    private var orientation = GradientDrawable.Orientation.LEFT_RIGHT
    private var colors: IntArray = intArrayOf(0)
    private var strokeW = 0f
    private var strokeC = 0
    private var a = 255

    var cornerRadius: Float = 0f
        set(v) { field = v; cornerRadii = null; invalidateSelf() }
    var cornerRadii: FloatArray? = null
        set(v) { field = v; invalidateSelf() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.MITER
    }
    private val path = Path()

    fun setColor(c: Int) { colors = intArrayOf(c); invalidateSelf() }
    fun setStroke(w: Int, c: Int) { strokeW = w.toFloat(); strokeC = c; invalidateSelf() }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val inset = strokeW / 2f
        val l = b.left + inset
        val t = b.top + inset
        val r = b.right - inset
        val bt = b.bottom - inset
        val m = min(r - l, bt - t)
        val cuts = FloatArray(4)
        val rr = cornerRadii
        when {
            shape == OVAL -> cuts.fill(m * 0.30f)
            rr != null && rr.size >= 8 -> for (i in 0 until 4) cuts[i] = min(rr[i * 2] * 0.6f, m * 0.45f)
            else -> cuts.fill(min(cornerRadius * 0.6f, m * 0.45f))
        }
        path.reset()
        path.moveTo(l + cuts[0], t)
        path.lineTo(r - cuts[1], t)
        path.lineTo(r, t + cuts[1])
        path.lineTo(r, bt - cuts[2])
        path.lineTo(r - cuts[2], bt)
        path.lineTo(l + cuts[3], bt)
        path.lineTo(l, bt - cuts[3])
        path.lineTo(l, t + cuts[0])
        path.close()

        if (colors.size == 1) {
            fill.shader = null
            fill.color = colors[0]
            fill.alpha = Color.alpha(colors[0]) * a / 255
        } else {
            val (x0, y0, x1, y1) = when (orientation) {
                GradientDrawable.Orientation.TL_BR -> floatArrayOf(l, t, r, bt)
                GradientDrawable.Orientation.TOP_BOTTOM -> floatArrayOf(l, t, l, bt)
                GradientDrawable.Orientation.BOTTOM_TOP -> floatArrayOf(l, bt, l, t)
                GradientDrawable.Orientation.RIGHT_LEFT -> floatArrayOf(r, t, l, t)
                else -> floatArrayOf(l, t, r, t)
            }
            fill.shader = LinearGradient(x0, y0, x1, y1, colors, null, Shader.TileMode.CLAMP)
            fill.color = Color.WHITE
            fill.alpha = a
        }
        canvas.drawPath(path, fill)
        if (strokeW > 0f && Color.alpha(strokeC) > 0) {
            line.strokeWidth = strokeW
            line.color = strokeC
            line.alpha = Color.alpha(strokeC) * a / 255
            canvas.drawPath(path, line)
        }
    }


    override fun setAlpha(alpha: Int) { a = alpha; invalidateSelf() }
    override fun setColorFilter(cf: ColorFilter?) { fill.colorFilter = cf; line.colorFilter = cf; invalidateSelf() }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Wajah mecha berbingkai segi delapan dengan cincin api yang berputar dan mata yang berdenyut. */
class MechaFace(ctx: Context) : View(ctx) {
    private val bmp: Bitmap? = try {
        BitmapFactory.decodeResource(resources, R.drawable.mecha_face)
    } catch (_: Throwable) { null }
    private val img = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.MITER }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val eyeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val sweep = Matrix()
    private var sweepShader: SweepGradient? = null
    private var eyeL: RadialGradient? = null
    private var eyeR: RadialGradient? = null
    private var t = 0f

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val cx = w / 2f
        val cy = h / 2f
        sweepShader = SweepGradient(
            cx, cy,
            intArrayOf(Fx.CYAN, Fx.alpha(Fx.CYAN, 0), Fx.PINK, Fx.alpha(Fx.PINK, 0), Fx.CYAN),
            null
        )
        val er = w * 0.16f
        val glowC = intArrayOf(0xFFFFC25A.toInt(), Fx.alpha(Fx.PINK, 120), 0x00FF2A3D)
        eyeL = RadialGradient(w * 0.44f, h * 0.54f, er, glowC, floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
        eyeR = RadialGradient(w * 0.59f, h * 0.54f, er, glowC, floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        val pad = 5f * d
        val cut = (min(w, h) - 2 * pad) * 0.22f
        path.reset()
        path.moveTo(pad + cut, pad)
        path.lineTo(w - pad - cut, pad)
        path.lineTo(w - pad, pad + cut)
        path.lineTo(w - pad, h - pad - cut)
        path.lineTo(w - pad - cut, h - pad)
        path.lineTo(pad + cut, h - pad)
        path.lineTo(pad, h - pad - cut)
        path.lineTo(pad, pad + cut)
        path.close()

        val pulse = 0.55f + 0.45f * sin(t * 2f * PI.toFloat())
        c.save()
        c.clipPath(path)
        if (bmp != null) c.drawBitmap(bmp, null, RectF(pad, pad, w - pad, h - pad), img)
        else c.drawColor(0xFF1A0508.toInt())
        eyeP.shader = eyeL; eyeP.alpha = (200 * pulse).toInt(); c.drawRect(0f, 0f, w, h, eyeP)
        eyeP.shader = eyeR; eyeP.alpha = (200 * pulse).toInt(); c.drawRect(0f, 0f, w, h, eyeP)
        c.restore()

        glow.strokeWidth = 7f * d
        glow.color = Fx.alpha(Fx.CYAN, (90 * pulse).toInt())
        c.drawPath(path, glow)

        ring.strokeWidth = 2.2f * d
        ring.shader = sweepShader
        sweep.setRotate(t * 360f, w / 2f, h / 2f)
        sweepShader?.setLocalMatrix(sweep)
        c.drawPath(path, ring)
    }
}

/** Latar video mecha yang berulang tanpa suara, dipotong penuh layar. Kalau gagal, tetap hitam kemerahan. */
class VideoBackground(ctx: Context) : FrameLayout(ctx), TextureView.SurfaceTextureListener {
    private val tv = TextureView(ctx)
    private var mp: MediaPlayer? = null
    private var surface: Surface? = null
    private var vw = 0
    private var vh = 0

    init {
        setBackgroundColor(0xFF0C0305.toInt())
        tv.surfaceTextureListener = this
        tv.alpha = 0f
        addView(tv, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { start(st) }
    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { fit() }
    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { release(); return true }

    private fun start(st: SurfaceTexture) {
        release()
        try {
            surface = Surface(st)
            val afd = resources.openRawResourceFd(R.raw.mecha_bg)
            val player = MediaPlayer()
            mp = player
            player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            player.setSurface(surface)
            player.isLooping = true
            player.setVolume(0f, 0f)
            player.setOnPreparedListener {
                vw = it.videoWidth
                vh = it.videoHeight
                fit()
                it.start()
                tv.animate().alpha(1f).setDuration(700).start()
            }
            player.setOnErrorListener { _, _, _ -> true }
            player.prepareAsync()
        } catch (_: Throwable) {
        }
    }

    /** Potong tengah (center-crop) supaya video memenuhi layar tanpa gepeng. */
    private fun fit() {
        val w = tv.width.toFloat()
        val h = tv.height.toFloat()
        if (vw == 0 || vh == 0 || w == 0f || h == 0f) return
        val viewRatio = w / h
        val videoRatio = vw.toFloat() / vh
        val m = Matrix()
        if (videoRatio > viewRatio) m.setScale(videoRatio / viewRatio, 1f, w / 2f, h / 2f)
        else m.setScale(1f, viewRatio / videoRatio, w / 2f, h / 2f)
        tv.setTransform(m)
    }

    private fun release() {
        try { mp?.release() } catch (_: Throwable) {}
        mp = null
        try { surface?.release() } catch (_: Throwable) {}
        surface = null
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        try { if (visibility == VISIBLE) mp?.start() else mp?.pause() } catch (_: Throwable) {}
    }

    override fun onDetachedFromWindow() { release(); super.onDetachedFromWindow() }
}

/** Segi delapan beraturan yang muat di dalam lingkaran berjari-jari r (menggantikan lingkaran). */
fun Path.oct(cx: Float, cy: Float, r: Float): Path {
    reset()
    val rr = r / kotlin.math.cos(PI / 8).toFloat()
    for (i in 0 until 8) {
        val ang = PI / 8 + i * PI / 4
        val x = cx + rr * kotlin.math.cos(ang).toFloat()
        val y = cy + rr * kotlin.math.sin(ang).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
    return this
}

/** Percikan api oranye yang naik pelan dan berkedip, mirip bara di video. */
class EmberView(ctx: Context, private val count: Int = 34) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val x = FloatArray(count)
    private val y = FloatArray(count)
    private val sp = FloatArray(count)
    private val r = FloatArray(count)
    private val ph = FloatArray(count)
    private val rnd = java.util.Random(7)
    private var last = 0L

    init { for (i in 0 until count) reset(i, true) }

    private fun reset(i: Int, anywhere: Boolean) {
        x[i] = rnd.nextFloat()
        y[i] = if (anywhere) rnd.nextFloat() else 1.05f
        sp[i] = 0.05f + rnd.nextFloat() * 0.17f
        r[i] = 0.8f + rnd.nextFloat() * 2.0f
        ph[i] = rnd.nextFloat() * 6.28f
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceAtMost(0.05f)
        last = now
        val sec = now / 1e9f
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 0 until count) {
            y[i] -= sp[i] * dt
            if (y[i] < -0.05f) reset(i, false)
            val px = (x[i] + sin(sec * 1.3f + ph[i]) * 0.02f) * w
            val py = y[i] * h
            val life = y[i].coerceIn(0f, 1f)
            val flick = 0.6f + 0.4f * sin(sec * 9f + ph[i] * 3f)
            val a = (210 * life * flick).toInt().coerceIn(0, 255)
            p.color = Fx.alpha(0xFFFF6A2D.toInt(), a / 3)
            c.drawCircle(px, py, r[i] * d * 2.4f, p)
            p.color = Fx.alpha(0xFFFFC25A.toInt(), a)
            c.drawCircle(px, py, r[i] * d, p)
        }
        postInvalidateOnAnimation()
    }
}
