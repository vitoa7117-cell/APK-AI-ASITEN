package com.example.aiassist

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class CameraActivity : Activity() {
    private lateinit var file: File

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        file = File(cacheDir, "shot.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(MediaStore.EXTRA_OUTPUT, uri)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivityForResult(i, 2)
        } catch (e: Exception) {
            Toast.makeText(this, "Aplikasi kamera tidak ditemukan", Toast.LENGTH_SHORT).show()
            Bridge.onCancel?.invoke()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && file.exists()) {
            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
            var bmp = BitmapFactory.decodeFile(file.absolutePath, opts)
            if (bmp != null) {
                val rot = when (ExifInterface(file.absolutePath)
                    .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
                if (rot != 0f) {
                    val m = Matrix().apply { postRotate(rot) }
                    bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                }
                Bridge.onImage?.invoke(bmp)
            } else Bridge.onCancel?.invoke()
        } else {
            Bridge.onCancel?.invoke()
        }
        finish()
    }
}
