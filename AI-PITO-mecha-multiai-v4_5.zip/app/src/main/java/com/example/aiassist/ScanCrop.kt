package com.example.aiassist

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Layar "kotak scan" ala scan QR: tampil screenshot beku, pengguna geser/ubah ukuran kotak
 * ke soal yang mau dijawab, lalu ketuk SCAN. Hanya area di dalam kotak yang dibaca.
 */
class ScanCropView(
    ctx: Context,
    private val bmp: Bitmap,
    private val onScan: (Bitmap) -> Unit,
    private val onCancel: () -> Unit
) : FrameLayout(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val rect = RectF()
    private val dim = Paint().apply { color = 0xAA000000.toInt() }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.CYAN; style = Paint.Style.STROKE; strokeWidth = 2.5f * d
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.CYAN }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 14f * d; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    private val hintBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC451A27.toInt() }

    // 0 = diam, 1 = geser kotak, 2 = ubah ukuran (anchor = sudut lawan)
    private var mode = 0
    private var ax = 0f
    private var ay = 0f
    private var lx = 0f
    private var ly = 0f
    private val hit = 46f * d
    private val minSize = 56f * d

    private val surface = object : View(ctx) {
        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            if (rect.isEmpty) rect.set(w * 0.06f, h * 0.28f, w * 0.94f, h * 0.60f)
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            c.drawColor(Color.BLACK)
            val p = place()
            c.drawBitmap(bmp, null, RectF(p[1], p[2], p[1] + p[3], p[2] + p[4]), bmpPaint)
            // gelapkan di luar kotak
            c.drawRect(0f, 0f, w, rect.top, dim)
            c.drawRect(0f, rect.bottom, w, h, dim)
            c.drawRect(0f, rect.top, rect.left, rect.bottom, dim)
            c.drawRect(rect.right, rect.top, w, rect.bottom, dim)
            c.drawRoundRect(rect, 8f * d, 8f * d, border)
            val r = 8f * d
            c.drawCircle(rect.left, rect.top, r, dot)
            c.drawCircle(rect.right, rect.top, r, dot)
            c.drawCircle(rect.left, rect.bottom, r, dot)
            c.drawCircle(rect.right, rect.bottom, r, dot)
            // petunjuk
            val msg = "Atur kotak ke soal, lalu ketuk SCAN"
            val tw = hintPaint.measureText(msg)
            val cy = 96f * d
            c.drawRoundRect(RectF(w / 2 - tw / 2 - 16 * d, cy - 22 * d, w / 2 + tw / 2 + 16 * d, cy + 18 * d), 20f * d, 20f * d, hintBg)
            c.drawText(msg, w / 2, cy + 5 * d, hintPaint)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val x = e.x.coerceIn(0f, width.toFloat())
            val y = e.y.coerceIn(0f, height.toFloat())
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val corners = arrayOf(
                        floatArrayOf(rect.left, rect.top, rect.right, rect.bottom),
                        floatArrayOf(rect.right, rect.top, rect.left, rect.bottom),
                        floatArrayOf(rect.left, rect.bottom, rect.right, rect.top),
                        floatArrayOf(rect.right, rect.bottom, rect.left, rect.top)
                    )
                    val hitCorner = corners.firstOrNull { hypot(x - it[0], y - it[1]) < hit }
                    when {
                        hitCorner != null -> { mode = 2; ax = hitCorner[2]; ay = hitCorner[3] }
                        rect.contains(x, y) -> { mode = 1; lx = x; ly = y }
                        else -> { mode = 2; ax = x; ay = y; rect.set(x, y, x, y) }
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (mode == 2) {
                        rect.set(min(ax, x), min(ay, y), max(ax, x), max(ay, y))
                    } else if (mode == 1) {
                        var dx = x - lx
                        var dy = y - ly
                        dx = dx.coerceIn(-rect.left, width - rect.right)
                        dy = dy.coerceIn(-rect.top, height - rect.bottom)
                        rect.offset(dx, dy)
                        lx = x
                        ly = y
                    }
                    invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mode = 0
                    if (rect.width() < minSize) {
                        val cx = rect.centerX()
                        rect.left = (cx - minSize / 2).coerceAtLeast(0f)
                        rect.right = (rect.left + minSize).coerceAtMost(width.toFloat())
                    }
                    if (rect.height() < minSize) {
                        val cy = rect.centerY()
                        rect.top = (cy - minSize / 2).coerceAtLeast(0f)
                        rect.bottom = (rect.top + minSize).coerceAtMost(height.toFloat())
                    }
                    invalidate()
                }
            }
            return true
        }
    }

    /** [skala, offsetX, offsetY, lebar, tinggi] gambar yang digambar di layar. */
    private fun place(): FloatArray {
        val w = surface.width.toFloat()
        val h = surface.height.toFloat()
        val s = min(w / bmp.width, h / bmp.height)
        val iw = bmp.width * s
        val ih = bmp.height * s
        return floatArrayOf(s, (w - iw) / 2, (h - ih) / 2, iw, ih)
    }

    private fun cropNow(whole: Boolean): Bitmap {
        if (whole) return bmp
        val p = place()
        val l = ((rect.left - p[1]) / p[0]).toInt().coerceIn(0, bmp.width - 1)
        val t = ((rect.top - p[2]) / p[0]).toInt().coerceIn(0, bmp.height - 1)
        val r = ((rect.right - p[1]) / p[0]).toInt().coerceIn(l + 1, bmp.width)
        val b = ((rect.bottom - p[2]) / p[0]).toInt().coerceIn(t + 1, bmp.height)
        return Bitmap.createBitmap(bmp, l, t, r - l, b - t)
    }

    private fun btn(label: String, primary: Boolean, click: () -> Unit) = TextView(context).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding((18 * d).toInt(), (13 * d).toInt(), (18 * d).toInt(), (13 * d).toInt())
        background = if (primary) Ui.gradient(Ui.PURPLE, 0xFFD40012.toInt(), (16 * d).toInt())
        else Ui.rounded(0xDD451A27.toInt(), (16 * d).toInt(), 0x88FF0015.toInt(), (1 * d).toInt())
        setOnClickListener { click() }
    }

    init {
        addView(surface, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        val bar = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val m = (6 * d).toInt()
        bar.addView(btn("Batal", false) { onCancel() }, LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(m, 0, m, 0) })
        bar.addView(btn("Semua layar", false) { onScan(cropNow(true)) }, LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1.3f).apply { setMargins(m, 0, m, 0) })
        bar.addView(btn("SCAN", true) { onScan(cropNow(false)) }, LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1.3f).apply { setMargins(m, 0, m, 0) })
        addView(bar, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.BOTTOM
            setMargins((14 * d).toInt(), 0, (14 * d).toInt(), (56 * d).toInt())
        })
    }
}
