package com.example.aiassist

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.UriMatcher
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Stiker WhatsApp (cara resmi: sticker pack via ContentProvider).
 * Gambar diubah jadi WebP 512x512 (<100KB), dikumpulkan jadi satu pack "AI PITO Stickers"
 * (WhatsApp minta minimal 3, maksimal 30 stiker per pack).
 */
/** WhatsApp: satu pack hanya boleh semua statis ATAU semua animasi, jadi dibuat dua pack. */
enum class Pack(val id: String, val title: String, val animated: Boolean, val folder: String) {
    STATIC("ai_pito_pack", "AI PITO Stickers", false, "stickers"),
    ANIM("ai_pito_anim", "AI PITO Animasi", true, "stickers_anim");

    companion object {
        fun byId(id: String?): Pack? = values().firstOrNull { it.id == id }
    }
}

object StickerStore {
    const val PUBLISHER = "AI PITO"
    const val MIN = 3
    const val MAX = 30
    const val TRAY = "tray.png"
    const val ANIM_LIMIT = 500_000

    fun authority(ctx: Context) = ctx.packageName + ".stickercontentprovider"

    fun dir(ctx: Context, pack: Pack = Pack.STATIC): File = File(ctx.filesDir, pack.folder).apply { mkdirs() }

    fun list(ctx: Context, pack: Pack = Pack.STATIC): List<File> =
        dir(ctx, pack).listFiles { f -> f.name.startsWith("sticker_") && f.name.endsWith(".webp") }
            ?.sortedBy { it.name } ?: emptyList()

    /** Harus berubah tiap isi pack berubah, kalau tidak WhatsApp memakai cache lama. */
    fun version(ctx: Context, pack: Pack = Pack.STATIC): String {
        val l = list(ctx, pack)
        return (l.maxOfOrNull { it.lastModified() } ?: 0L).toString() + "_" + l.size
    }

    @Suppress("DEPRECATION")
    fun webpFormat(): Bitmap.CompressFormat =
        if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP

    private fun toWebp(src: Bitmap): ByteArray {
        val size = 512
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val margin = 16f
        val box = size - 2 * margin
        val s = minOf(box / src.width, box / src.height)
        val dw = src.width * s
        val dh = src.height * s
        val l = (size - dw) / 2f
        val t = (size - dh) / 2f
        val rect = RectF(l, t, l + dw, t + dh)
        c.clipPath(Path().apply { addRoundRect(rect, 48f, 48f, Path.Direction.CW) })
        c.drawBitmap(src, null, rect, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        val fmt = webpFormat()
        var q = 90
        while (true) {
            val bos = ByteArrayOutputStream()
            out.compress(fmt, q, bos)
            if (bos.size() <= 95_000 || q <= 20) {
                out.recycle()
                return bos.toByteArray()
            }
            q -= 10
        }
    }

    private fun commit(ctx: Context, pack: Pack, bytes: ByteArray, tray: Bitmap?): Int {
        val d = dir(ctx, pack)
        File(d, "sticker_${System.currentTimeMillis()}.webp").writeBytes(bytes)
        val all = list(ctx, pack)
        if (all.size > MAX) all.take(all.size - MAX).forEach { it.delete() }

        // ikon tray 96x96 dari stiker pertama
        val trayFile = File(d, TRAY)
        if (!trayFile.exists() || list(ctx, pack).size == 1) {
            val src = tray ?: BitmapFactory.decodeFile(list(ctx, pack).first().absolutePath)
            if (src != null) {
                val t = Bitmap.createScaledBitmap(src, 96, 96, true)
                trayFile.outputStream().use { t.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
        }
        return list(ctx, pack).size
    }

    /** Simpan satu stiker diam ke pack. Mengembalikan jumlah stiker sekarang. */
    fun add(ctx: Context, bmp: Bitmap): Int = commit(ctx, Pack.STATIC, toWebp(bmp), null)

    /** Simpan stiker animasi (webp animasi < 500 KB) ke pack animasi. */
    fun addAnimated(ctx: Context, webp: ByteArray, preview: Bitmap): Int {
        if (webp.size > ANIM_LIMIT) throw Exception("stiker animasi kegedean (maks 500 KB)")
        return commit(ctx, Pack.ANIM, webp, preview)
    }

    /** Buka WhatsApp untuk menambahkan pack. false kalau WhatsApp tidak terpasang. */
    fun openWhatsApp(ctx: Context, pack: Pack = Pack.STATIC): Boolean {
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            val i = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK")
                .setPackage(pkg)
                .putExtra("sticker_pack_id", pack.id)
                .putExtra("sticker_pack_authority", authority(ctx))
                .putExtra("sticker_pack_name", pack.title)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                ctx.startActivity(i)
                return true
            } catch (_: Exception) {
            }
        }
        return false
    }
}

class StickerProvider : ContentProvider() {
    private val matcher = UriMatcher(UriMatcher.NO_MATCH)

    private companion object {
        const val METADATA = 1
        const val METADATA_ONE = 2
        const val STICKERS = 3
        const val ASSET = 4
    }

    override fun onCreate(): Boolean {
        val a = context!!.packageName + ".stickercontentprovider"
        matcher.addURI(a, "metadata", METADATA)
        matcher.addURI(a, "metadata/*", METADATA_ONE)
        matcher.addURI(a, "stickers/*", STICKERS)
        matcher.addURI(a, "stickers_asset/*/*", ASSET)
        return true
    }

    override fun query(
        uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?
    ): Cursor? {
        val ctx = context!!
        return when (matcher.match(uri)) {
            METADATA, METADATA_ONE -> {
                val c = MatrixCursor(
                    arrayOf(
                        "sticker_pack_identifier", "sticker_pack_name", "sticker_pack_publisher",
                        "sticker_pack_icon", "android_play_store_link", "ios_app_download_link",
                        "sticker_pack_publisher_email", "sticker_pack_publisher_website",
                        "sticker_pack_privacy_policy_website", "sticker_pack_license_agreement_website",
                        "image_data_version", "whatsapp_will_not_cache_stickers", "animated_sticker_pack"
                    )
                )
                val only = if (matcher.match(uri) == METADATA_ONE) uri.lastPathSegment else null
                for (pk in Pack.values()) {
                    if (only != null && only != pk.id) continue
                    if (StickerStore.list(ctx, pk).size < StickerStore.MIN) continue
                    c.addRow(
                        arrayOf<Any>(
                            pk.id, pk.title, StickerStore.PUBLISHER,
                            StickerStore.TRAY, "", "", "", "", "", "",
                            StickerStore.version(ctx, pk), 0, if (pk.animated) 1 else 0
                        )
                    )
                }
                c
            }
            STICKERS -> {
                val c = MatrixCursor(arrayOf("sticker_file_name", "sticker_emoji", "sticker_accessibility_text"))
                val pk = Pack.byId(uri.lastPathSegment)
                if (pk != null) {
                    StickerStore.list(ctx, pk).forEach { c.addRow(arrayOf<Any>(it.name, "😀", "Stiker AI PITO")) }
                }
                c
            }
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
    }

    override fun getType(uri: Uri): String? {
        val a = context!!.packageName + ".stickercontentprovider"
        return when (matcher.match(uri)) {
            METADATA -> "vnd.android.cursor.dir/vnd.$a.metadata"
            METADATA_ONE -> "vnd.android.cursor.item/vnd.$a.metadata"
            STICKERS -> "vnd.android.cursor.dir/vnd.$a.stickers"
            ASSET -> "image/webp"
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
    }

    override fun openAssetFile(uri: Uri, mode: String): AssetFileDescriptor? {
        if (matcher.match(uri) != ASSET) return null
        val seg = uri.pathSegments
        val pk = Pack.byId(seg.getOrNull(seg.size - 2)) ?: return null
        val f = File(StickerStore.dir(context!!, pk), File(seg.last()).name) // cegah path traversal
        if (!f.exists()) return null
        return AssetFileDescriptor(
            ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY),
            0, AssetFileDescriptor.UNKNOWN_LENGTH
        )
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException()
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int =
        throw UnsupportedOperationException()
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int =
        throw UnsupportedOperationException()
}
