package com.example.aiassist

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Klien jembatan ke nara-bot (jalan di Termux, HP yang sama). Lihat lib/bridge.js di bot. */
object BotBridge {
    const val PORT = 8787

    class Status(val reachable: Boolean, val connected: Boolean, val me: String, val error: String?)

    private fun open(ctx: Context, path: String): HttpURLConnection {
        val c = URL("http://127.0.0.1:$PORT$path").openConnection() as HttpURLConnection
        c.setRequestProperty("X-Token", Prefs.saToken(ctx))
        return c
    }

    private fun body(c: HttpURLConnection, code: Int): String =
        (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""

    /** Cek bot hidup. reachable=false berarti bot tidak jalan (atau versi lama tanpa jembatan). */
    fun ping(ctx: Context): Status = try {
        val c = open(ctx, "/ping")
        c.connectTimeout = 1500
        c.readTimeout = 4000
        val code = c.responseCode
        val j = runCatching { JSONObject(body(c, code)) }.getOrNull()
        when {
            code == 401 -> Status(true, false, "", "Token salah. Lihat token di log bot, lalu ketik .satoken <token>")
            code in 200..299 -> Status(true, j?.optBoolean("connected") == true, j?.optString("me") ?: "", null)
            else -> Status(true, false, "", j?.optString("error") ?: "HTTP $code")
        }
    } catch (e: Exception) {
        Status(false, false, "", e.message)
    }

    /** Kirim video, atau foto + audio, ke bot. Mengembalikan "" kalau sukses, selain itu pesan error. */
    fun sendSa(ctx: Context, visual: File, isVideo: Boolean, audio: File?, seconds: Int): String = try {
        val c = open(ctx, "/sa")
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 3000
        c.readTimeout = 5 * 60 * 1000
        c.setRequestProperty("Content-Type", "application/octet-stream")
        c.setRequestProperty("X-Visual-Kind", if (isVideo) "video" else "image")
        c.setRequestProperty("X-Visual-Len", visual.length().toString())
        c.setRequestProperty("X-Seconds", seconds.toString())
        c.setRequestProperty("X-To", Prefs.saTo(ctx))
        c.setFixedLengthStreamingMode(visual.length() + (audio?.length() ?: 0L))
        c.outputStream.use { o ->
            visual.inputStream().use { it.copyTo(o) }
            audio?.inputStream()?.use { it.copyTo(o) }
        }
        val code = c.responseCode
        val txt = body(c, code)
        if (code in 200..299) "" else (runCatching { JSONObject(txt).optString("error") }.getOrNull()
            ?.ifBlank { null } ?: "HTTP $code")
    } catch (e: Exception) {
        e.message ?: e.toString()
    }
}
