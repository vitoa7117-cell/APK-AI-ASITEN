package com.example.aiassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.min
import kotlin.math.sin

/* ====================================================================== */
/*  Tampilan panel chat melayang: kaca gelap, aurora, grid, garis scan,   */
/*  dan border neon yang berputar.                                        */
/* ====================================================================== */

open class NeonFrame(ctx: Context) : LinearLayout(ctx) {
    private val d = resources.displayMetrics.density
    private val cut = 18f * d
    private val path = Path()
    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blobCyan = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blobViolet = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridP = Paint().apply { color = 0x0CFF2537; strokeWidth = d }
    private val scanP = Paint()
    private val borderP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.6f * d }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f * d }
    private var sweep: SweepGradient? = null
    private val m = Matrix()
    private var blobR = 0f
    private val scanBand = 90f * d
    private val gridStep = 26f * d

    init {
        setWillNotDraw(false)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val i = 0.8f * d
        val wf = w.toFloat()
        val hf = h.toFloat()
        path.reset()
        path.moveTo(cut, i)
        path.lineTo(wf - i, i)
        path.lineTo(wf - i, hf - cut)
        path.lineTo(wf - cut, hf - i)
        path.lineTo(i, hf - i)
        path.lineTo(i, cut)
        path.close()
        bgP.shader = LinearGradient(0f, 0f, wf, hf, 0x8C330B17.toInt(), 0x9924080D.toInt(), Shader.TileMode.CLAMP)
        blobR = wf * 0.75f
        blobCyan.shader = RadialGradient(0f, 0f, blobR, 0x33FF2537, 0x00FF2537, Shader.TileMode.CLAMP)
        blobViolet.shader = RadialGradient(0f, 0f, blobR, 0x38FF5C8D, 0x00FF5C8D, Shader.TileMode.CLAMP)
        scanP.shader = LinearGradient(
            0f, 0f, 0f, scanBand,
            intArrayOf(0x00FF2537, 0x24FF2537, 0x00FF2537), null, Shader.TileMode.CLAMP
        )
        sweep = SweepGradient(
            wf / 2f, hf / 2f,
            intArrayOf(Fx.CYAN, Fx.VIOLET, Fx.PINK, Fx.VIOLET, Fx.CYAN), null
        )
    }

    override fun onDraw(c: Canvas) {
        val t = Fx.time()
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawPath(path, bgP)

        c.save()
        c.clipPath(path)
        // aurora yang melayang pelan
        c.save()
        c.translate(w * (0.2f + 0.15f * sin(t * 0.5f)), h * (0.12f + 0.08f * sin(t * 0.37f + 1f)))
        c.drawCircle(0f, 0f, blobR, blobCyan)
        c.restore()
        c.save()
        c.translate(w * (0.85f + 0.1f * sin(t * 0.4f + 2f)), h * (0.92f + 0.06f * sin(t * 0.6f)))
        c.drawCircle(0f, 0f, blobR, blobViolet)
        c.restore()
        // grid tipis
        var x = 0f
        while (x < w) { c.drawLine(x, 0f, x, h, gridP); x += gridStep }
        var y = 0f
        while (y < h) { c.drawLine(0f, y, w, y, gridP); y += gridStep }
        // garis scan yang turun pelan
        val sy = ((t * 0.22f) % 1f) * (h + scanBand) - scanBand
        c.save()
        c.translate(0f, sy)
        c.drawRect(0f, 0f, w, scanBand, scanP)
        c.restore()
        c.restore()

        // border neon berputar
        val sg = sweep
        if (sg != null) {
            m.setRotate((t * 45f) % 360f, w / 2f, h / 2f)
            sg.setLocalMatrix(m)
            glowP.shader = sg
            glowP.alpha = 55
            borderP.shader = sg
            c.drawPath(path, glowP)
            c.drawPath(path, borderP)
        }
        super.onDraw(c)
        postInvalidateOnAnimation()
    }
}

/** Avatar AI: cincin neon berputar + denyut cahaya di sekeliling robot. */
class AiOrb(ctx: Context) : View(ctx) {
    private val octP = Path()
    private val d = resources.displayMetrics.density
    private val icon: Drawable? = ctx.getDrawable(R.drawable.ic_robot_bubble)
    private val discP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2E0B15.toInt() }
    private val haloP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val arcP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.BUTT
        strokeWidth = 2f * d
    }
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val t = Fx.time()
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy) - 5f * d
        val pulse = 0.5f + 0.5f * sin(t * 2.4f)
        for (i in 1..3) {
            haloP.strokeWidth = i * 2.2f * d
            val a = ((26 - i * 6) * (0.6f + 0.9f * pulse)).toInt().coerceIn(0, 255)
            haloP.color = Fx.alpha(Fx.CYAN, a)
            c.drawPath(octP.oct(cx, cy, r + i * 1.2f * d), haloP)
        }
        c.drawPath(octP.oct(cx, cy, r), discP)
        rect.set(cx - r, cy - r, cx + r, cy + r)
        arcP.strokeWidth = 2f * d
        arcP.color = Fx.CYAN
        c.drawArc(rect, (t * 150f) % 360f, 100f, false, arcP)
        arcP.color = Fx.PINK
        c.drawArc(rect, (t * 150f + 180f) % 360f, 70f, false, arcP)
        arcP.strokeWidth = d
        arcP.color = Fx.alpha(Fx.VIOLET, 140)
        c.drawPath(octP.oct(cx, cy, r - 4f * d), arcP)
        icon?.let {
            val s = r * 1.55f
            it.setBounds((cx - s / 2f).toInt(), (cy - s / 2f).toInt(), (cx + s / 2f).toInt(), (cy + s / 2f).toInt())
            it.draw(c)
        }
        postInvalidateOnAnimation()
    }
}

/** Titik status yang berdenyut. */
class PulseDot(ctx: Context, private val color: Int) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = this@PulseDot.color }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((12 * d).toInt(), (12 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val k = (Fx.time() * 1.1f) % 1f
        val cx = width / 2f
        val cy = height / 2f
        ringPaint.color = Fx.alpha(color, ((1f - k) * 170f).toInt().coerceIn(0, 255))
        c.drawCircle(cx, cy, (2.5f + 3.5f * k) * d, ringPaint)
        c.drawCircle(cx, cy, 2.5f * d, corePaint)
        postInvalidateOnAnimation()
    }
}

/** Tiga titik bergelombang untuk indikator "sedang berpikir". */
class WaveDots(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val cols = intArrayOf(Fx.CYAN, Fx.VIOLET, Fx.PINK)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((40 * d).toInt(), (20 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val t = Fx.time()
        val cy = height / 2f
        for (i in 0..2) {
            val ph = t * 5.5f - i * 0.9f
            val s = sin(ph)
            val x = width * (0.2f + 0.3f * i)
            val y = cy - s * 4.5f * d
            val k = 0.5f + 0.5f * s
            p.color = Fx.alpha(cols[i], (40 + 50 * k).toInt())
            c.drawCircle(x, y, 6.5f * d, p)
            p.color = Fx.alpha(cols[i], (150 + 105 * k).toInt().coerceIn(0, 255))
            c.drawCircle(x, y, (3f + 0.8f * k) * d, p)
        }
        postInvalidateOnAnimation()
    }
}

/** Pembuat background dan komponen kecil untuk panel. */
object PanelUi {
    private fun radii(tl: Float, tr: Float, br: Float, bl: Float) =
        floatArrayOf(tl, tl, tr, tr, br, br, bl, bl)

    fun aiBubble(ctx: Context): CutDrawable {
        val r = Ui.dp(ctx, 16).toFloat()
        val s = Ui.dp(ctx, 4).toFloat()
        return CutDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xE6461624.toInt(), 0xE6331218.toInt())
        ).apply {
            cornerRadii = radii(s, r, r, r)
            setStroke(Ui.dp(ctx, 1), 0x55FF2537)
        }
    }

    fun userBubble(ctx: Context): CutDrawable {
        val r = Ui.dp(ctx, 16).toFloat()
        val s = Ui.dp(ctx, 4).toFloat()
        return CutDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xFFFF4D82.toInt(), 0xFFE81A2B.toInt())
        ).apply { cornerRadii = radii(r, s, r, r) }
    }

    fun errorBubble(ctx: Context): CutDrawable = CutDrawable().apply {
        setColor(0x33FF843D)
        cornerRadius = Ui.dp(ctx, 16).toFloat()
        setStroke(Ui.dp(ctx, 1), Fx.PINK)
    }

    fun fieldBg(ctx: Context, focused: Boolean): CutDrawable = CutDrawable().apply {
        setColor(0xFF401522.toInt())
        cornerRadius = Ui.dp(ctx, 22).toFloat()
        setStroke(Ui.dp(ctx, 2), if (focused) Fx.CYAN else 0x66FF5C8D)
    }

    fun iconBtn(ctx: Context, iconRes: Int, tint: Int, onClick: () -> Unit): ImageView =
        ImageView(ctx).apply {
            setImageResource(iconRes)
            setColorFilter(tint, PorterDuff.Mode.SRC_IN)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            val p = Ui.dp(ctx, 9)
            setPadding(p, p, p, p)
            background = Ui.rounded(0x2AFF5C8D, Ui.dp(ctx, 12), 0x44FF2537, Ui.dp(ctx, 1))
            isClickable = true
            setOnClickListener { onClick() }
            Ui.pressable(this)
        }

    fun chipBg(ctx: Context, tint: Int, active: Boolean): CutDrawable =
        CutDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            if (active) intArrayOf(Fx.alpha(tint, 0x88), Fx.alpha(Fx.VIOLET, 0x66))
            else intArrayOf(Fx.alpha(tint, 0x2A), Fx.alpha(Fx.VIOLET, 0x22))
        ).apply {
            cornerRadius = Ui.dp(ctx, 16).toFloat()
            setStroke(Ui.dp(ctx, if (active) 2 else 1), Fx.alpha(tint, if (active) 0xFF else 0x99))
        }

    fun chip(
        ctx: Context, iconRes: Int, label: String, tint: Int,
        compact: Boolean = false, onClick: () -> Unit
    ): LinearLayout =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = chipBg(ctx, tint, false)
            if (compact) setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 9), Ui.dp(ctx, 9), Ui.dp(ctx, 9))
            else setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 9), Ui.dp(ctx, 14), Ui.dp(ctx, 9))
            val icon = Ui.dp(ctx, if (compact) 14 else 16)
            addView(ImageView(ctx).apply {
                setImageResource(iconRes)
                setColorFilter(tint, PorterDuff.Mode.SRC_IN)
            }, LinearLayout.LayoutParams(icon, icon))
            addView(TextView(ctx).apply {
                text = label
                setTextColor(tint)
                textSize = if (compact) 11.5f else 12f
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.02f
                maxLines = 1
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { leftMargin = Ui.dp(ctx, if (compact) 5 else 7) })
            isClickable = true
            setOnClickListener { onClick() }
            Ui.pressable(this)
        }
}
