package com.example.aiassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View
import kotlin.math.min
import kotlin.math.sin

/**
 * Animasi "sedang berpikir" (siklus 4 detik), terinspirasi video logo neon:
 *  1. garis neon menggambar segi delapan dari satu titik ke dua arah
 *  2. inti robot muncul membal (pop) dengan cincin kilat
 *  3. sinar pelangi menyembur ke atas, makhluk pixel melayang di dalamnya,
 *     garis inti berganti warna pelangi
 *  4. sinar surut, inti memudar, lalu mengulang
 */
class MorphLoader(ctx: Context) : View(ctx) {
    companion object {
        private const val CYCLE = 4.0f
        private val RAINBOW = intArrayOf(
            0xFFFF3B30.toInt(), 0xFFFF9500.toInt(), 0xFFFFE600.toInt(), 0xFF34D96B.toInt(),
            0xFF22D3EE.toInt(), 0xFF3B82F6.toInt(), 0xFFA855F7.toInt(), 0xFFFF3B30.toInt()
        )
        private val SPRITE_COLS = intArrayOf(0xFF101A44.toInt(), 0xFF7A0F1A.toInt(), 0xFF0B3B6F.toInt())
        private val ALIEN = arrayOf(".X...X.", "..XXX..", ".XXXXX.", "XX.X.XX", "X.XXX.X")
        private val BOT = arrayOf("..XXX..", ".XXXXX.", "XX.X.XX", ".XXXXX.", "X.X.X.X")
    }

    private val d = resources.displayMetrics.density
    private val icon: Drawable? = ctx.getDrawable(R.drawable.ic_robot_bubble)?.mutate()

    private val octP = Path()
    private val seg = Path()
    private val beamP = Path()
    private val pm = PathMeasure()
    private val pos = FloatArray(2)
    private val hsv = FloatArray(3)
    private val mat = Matrix()
    private val rect = RectF()

    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val beamPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val maskPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    private val pxP = Paint()
    private val rainbow = LinearGradient(0f, 0f, 0f, 44f * d, RAINBOW, null, Shader.TileMode.REPEAT)
    private var maskShader: Shader? = null

    private var cx = 0f
    private var cy = 0f
    private var r = 0f
    private var y0 = 0f
    private var y1 = 0f

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((92 * d).toInt(), (74 * d).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f
        r = 16f * d
        cy = h - r - 5f * d
        y0 = cy - r * 0.55f
        y1 = 2f * d
        maskShader = LinearGradient(0f, y0, 0f, y1, 0xFFFFFFFF.toInt(), 0x14FFFFFF, Shader.TileMode.CLAMP)
    }

    private fun clamp01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x
    private fun smooth(x: Float) = x * x * (3f - 2f * x)
    private fun easeOut(x: Float): Float { val k = 1f - x; return 1f - k * k * k }
    private fun backOut(x: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        val k = x - 1f
        return 1f + c3 * k * k * k + c1 * k * k
    }
    private fun a255(x: Float) = (x * 255f).toInt().coerceIn(0, 255)
    private fun lerpColor(a: Int, b: Int, k: Float): Int {
        val ar = Color.red(a); val ag = Color.green(a); val ab = Color.blue(a)
        val br = Color.red(b); val bg = Color.green(b); val bb = Color.blue(b)
        return Color.rgb(
            (ar + (br - ar) * k).toInt(), (ag + (bg - ag) * k).toInt(), (ab + (bb - ab) * k).toInt()
        )
    }

    /** Garis neon tiga lapis (cahaya lebar, sedang, inti tajam). */
    private fun neon(c: Canvas, p: Path, col: Int, oa: Float) {
        lineP.color = Fx.alpha(col, a255(0.13f * oa)); lineP.strokeWidth = 7f * d; c.drawPath(p, lineP)
        lineP.color = Fx.alpha(col, a255(0.35f * oa)); lineP.strokeWidth = 3.6f * d; c.drawPath(p, lineP)
        lineP.color = Fx.alpha(col, a255(oa)); lineP.strokeWidth = 1.6f * d; c.drawPath(p, lineP)
    }

    private fun drawBeam(c: Canvas, t: Float, w: Float, h: Float, beamK: Float) {
        val yTop = y0 - (y0 - y1) * beamK
        val half0 = r * 0.5f
        val halfTop = half0 + ((w / 2f - 4f * d) - half0) * beamK

        beamP.rewind()
        beamP.moveTo(cx - half0, y0)
        beamP.lineTo(cx + half0, y0)
        beamP.lineTo(cx + halfTop, yTop + 4f * d)
        beamP.quadTo(cx, yTop - 5f * d, cx - halfTop, yTop + 4f * d)
        beamP.close()

        val sc = c.saveLayer(0f, 0f, w, h, null)
        mat.setTranslate(0f, y0 - ((t * 46f * d) % (44f * d)))
        rainbow.setLocalMatrix(mat)
        beamPaint.shader = rainbow
        beamPaint.style = Paint.Style.FILL
        beamPaint.alpha = a255(0.92f * beamK)
        c.drawPath(beamP, beamPaint)
        beamPaint.style = Paint.Style.STROKE
        beamPaint.strokeWidth = 5f * d
        beamPaint.alpha = a255(0.28f * beamK)
        c.drawPath(beamP, beamPaint)
        maskPaint.shader = maskShader
        c.drawRect(0f, 0f, w, h, maskPaint)
        c.restoreToCount(sc)

        // makhluk pixel melayang naik di dalam sinar
        if (y0 - yTop < 10f * d) return
        for (i in 0 until 5) {
            val prog = (t * 0.5f + i * 0.2f) % 1f
            val y = y0 - prog * (y0 - yTop - 6f * d)
            val frac = (y0 - y) / (y0 - yTop)
            val halfAt = half0 + (halfTop - half0) * frac
            val x = cx + sin(t * 2.0f + i * 1.9f) * halfAt * 0.5f
            val cell = (1.0f + 1.4f * prog) * d
            val a = a255(beamK * (1f - prog * prog * prog))
            if (a < 6) continue
            val sprite = if (i % 2 == 0) ALIEN else BOT
            pxP.color = Fx.alpha(SPRITE_COLS[i % SPRITE_COLS.size], a)
            val ox = x - 3.5f * cell
            val oy = y - 2.5f * cell
            for (row in 0 until 5) {
                for (col in 0 until 7) {
                    if (sprite[row][col] == 'X') {
                        c.drawRect(
                            ox + col * cell, oy + row * cell,
                            ox + (col + 1) * cell, oy + (row + 1) * cell, pxP
                        )
                    }
                }
            }
        }
    }

    override fun onDraw(c: Canvas) {
        val t = Fx.time()
        val u = (t % CYCLE) / CYCLE
        val w = width.toFloat()
        val h = height.toFloat()

        val trace = if (u < 0.20f) easeOut(u / 0.20f) else 1f
        val pop = clamp01((u - 0.20f) / 0.07f)
        val fade = 1f - clamp01((u - 0.88f) / 0.12f)
        val coreA = if (u < 0.20f) 0f else min(pop, fade)
        val beamK = smooth(clamp01((u - 0.27f) / 0.06f)) * (1f - smooth(clamp01((u - 0.72f) / 0.08f)))
        val sCore = 0.6f + 0.4f * backOut(pop)

        octP.oct(cx, cy, r)
        pm.setPath(octP, true)
        val len = pm.length

        // 1) sinar pelangi (di belakang inti)
        if (beamK > 0.02f) drawBeam(c, t, w, h, beamK)

        // 2) inti: isi segi delapan + robot, membal saat muncul
        if (coreA > 0.01f) {
            fillP.color = Fx.alpha(0xFF2E0B15.toInt(), a255(coreA))
            c.save()
            c.scale(sCore, sCore, cx, cy)
            c.drawPath(octP, fillP)
            icon?.let { ic ->
                val s = r * 1.5f
                ic.setBounds((cx - s / 2f).toInt(), (cy - s / 2f).toInt(), (cx + s / 2f).toInt(), (cy + s / 2f).toInt())
                ic.alpha = a255(coreA)
                ic.draw(c)
            }
            c.restore()
        }

        // 3) busur berputar saat inti diam (tanpa sinar)
        val arcA = coreA * (1f - beamK)
        if (arcA > 0.02f) {
            rect.set(cx - r - 4f * d, cy - r - 4f * d, cx + r + 4f * d, cy + r + 4f * d)
            lineP.strokeWidth = 2f * d
            lineP.color = Fx.alpha(Fx.CYAN, a255(arcA))
            c.drawArc(rect, (t * 200f) % 360f, 80f, false, lineP)
            lineP.color = Fx.alpha(Fx.PINK, a255(arcA))
            c.drawArc(rect, (t * 200f + 180f) % 360f, 55f, false, lineP)
        }

        // 4) garis neon: putih hangat, berubah warna pelangi saat sinar menyembur
        hsv[0] = (t * 140f) % 360f
        hsv[1] = 0.8f
        hsv[2] = 1f
        val col = lerpColor(0xFFFFF1E8.toInt(), Color.HSVToColor(hsv), beamK)
        val oa = if (u < 0.88f) 1f else fade
        if (trace < 0.999f) {
            val half = len * trace / 2f
            seg.rewind(); pm.getSegment(0f, half, seg, true); neon(c, seg, col, oa)
            seg.rewind(); pm.getSegment(len - half, len, seg, true); neon(c, seg, col, oa)
            fillP.color = Fx.alpha(Fx.PINK, 90)
            pm.getPosTan(half, pos, null)
            c.drawCircle(pos[0], pos[1], 5.5f * d, fillP)
            pm.getPosTan(len - half, pos, null)
            c.drawCircle(pos[0], pos[1], 5.5f * d, fillP)
            fillP.color = Color.WHITE
            pm.getPosTan(half, pos, null)
            c.drawCircle(pos[0], pos[1], 2.2f * d, fillP)
            pm.getPosTan(len - half, pos, null)
            c.drawCircle(pos[0], pos[1], 2.2f * d, fillP)
        } else {
            neon(c, octP, col, oa)
        }

        // 5) cincin kilat saat inti muncul
        if (u in 0.20f..0.34f) {
            val k = (u - 0.20f) / 0.14f
            lineP.strokeWidth = 1.5f * d
            lineP.color = Fx.alpha(Fx.PINK, a255((1f - k) * 0.65f))
            c.drawPath(octP.oct(cx, cy, r * (1f + k * 0.9f)), lineP)
        }

        postInvalidateOnAnimation()
    }
}
