package com.example.aiassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Bubble bulat melayang: halo bernapas, cincin neon gradasi yang berputar,
 * riak keluar, percikan mengorbit, robot yang "bernapas", dan ping hijau saat balasan datang.
 * Saat sibuk: warna jadi pink dan semua bergerak lebih cepat.
 */
class BubbleView(ctx: Context) : View(ctx) {
    private val octP = android.graphics.Path()
    private val d = resources.displayMetrics.density
    private val icon: Drawable? = ctx.getDrawable(R.drawable.ic_robot_bubble)

    private val discP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val rippleP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val sparkP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val sweepM = Matrix()

    private var glowIdle: RadialGradient? = null
    private var glowBusy: RadialGradient? = null
    private var sweep: SweepGradient? = null

    var busy = false
    private var pingAt = -10f
    private var spin = 0f
    private var lastT = Fx.time()

    /** Dipanggil saat balasan AI datang. */
    fun ping() {
        pingAt = Fx.time()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val cx = w / 2f
        val cy = h / 2f
        val big = min(cx, cy)
        val r = big - 12f * d
        discP.shader = RadialGradient(
            cx, cy - r * 0.25f, r * 1.25f,
            intArrayOf(0xFF80233F.toInt(), 0xFF330C18.toInt(), 0xFF1C060D.toInt()),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        glowIdle = RadialGradient(
            cx, cy, big,
            intArrayOf(Fx.alpha(Fx.CYAN, 110), Fx.alpha(Fx.CYAN, 40), Fx.clear(Fx.CYAN)),
            floatArrayOf(0.55f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        glowBusy = RadialGradient(
            cx, cy, big,
            intArrayOf(Fx.alpha(Fx.PINK, 120), Fx.alpha(Fx.PINK, 45), Fx.clear(Fx.PINK)),
            floatArrayOf(0.55f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        sweep = SweepGradient(
            cx, cy,
            intArrayOf(Fx.clear(Fx.CYAN), Fx.CYAN, Fx.PINK, Fx.clear(Fx.PINK), Fx.clear(Fx.CYAN)),
            floatArrayOf(0f, 0.35f, 0.6f, 0.75f, 1f)
        )
    }

    override fun onDraw(c: Canvas) {
        val t = Fx.time()
        val dt = (t - lastT).coerceIn(0f, 0.1f)
        lastT = t
        spin = (spin + dt * (if (busy) 420f else 120f)) % 360f

        val cx = width / 2f
        val cy = height / 2f
        val big = min(cx, cy)
        val r = big - 12f * d
        val breathe = 0.5f + 0.5f * sin(t * 2.2f)
        val col = if (busy) Fx.PINK else Fx.CYAN

        // halo
        glowP.shader = if (busy) glowBusy else glowIdle
        glowP.alpha = (160 + 95 * breathe).toInt().coerceIn(0, 255)
        c.drawCircle(cx, cy, big, glowP)

        // riak keluar
        for (i in 0 until 2) {
            val ph = ((t * (if (busy) 0.9f else 0.45f)) + i * 0.5f) % 1f
            rippleP.strokeWidth = 1.5f * d
            rippleP.color = Fx.alpha(col, ((1f - ph) * 90).toInt())
            c.drawPath(octP.oct(cx, cy, r + ph * (big - r)), rippleP)
        }

        // badan
        c.drawPath(octP.oct(cx, cy, r), discP)

        // cincin gradasi berputar
        sweepM.setRotate(spin, cx, cy)
        sweep?.setLocalMatrix(sweepM)
        ringP.shader = sweep
        ringP.strokeWidth = 3f * d
        c.drawPath(octP.oct(cx, cy, r - 1.5f * d), ringP)

        // busur ungu tipis berputar berlawanan
        ringP.shader = null
        ringP.strokeWidth = 1.2f * d
        ringP.color = Fx.alpha(Fx.VIOLET, 170)
        rect.set(cx - r + 5f * d, cy - r + 5f * d, cx + r - 5f * d, cy + r - 5f * d)
        c.drawArc(rect, -spin * 1.6f, 70f, false, ringP)
        c.drawArc(rect, -spin * 1.6f + 180f, 40f, false, ringP)

        // percikan mengorbit
        val ang = t * (if (busy) 6f else 2.4f)
        val sx = cx + cos(ang) * (r + 3f * d)
        val sy = cy + sin(ang) * (r + 3f * d)
        sparkP.color = Fx.alpha(Color.WHITE, 90)
        c.drawCircle(sx, sy, 4.5f * d, sparkP)
        sparkP.color = Color.WHITE
        c.drawCircle(sx, sy, 1.9f * d, sparkP)

        // robot (naik turun + denyut kecil)
        icon?.let {
            val s = r * 1.5f
            val bob = sin(t * 2.0f) * 1.2f * d
            val sc = 1f + 0.03f * sin(t * 4.4f)
            c.save()
            c.scale(sc, sc, cx, cy + bob)
            it.setBounds(
                (cx - s / 2f).toInt(), (cy + bob - s / 2f).toInt(),
                (cx + s / 2f).toInt(), (cy + bob + s / 2f).toInt()
            )
            it.draw(c)
            c.restore()
        }

        // ping hijau saat balasan datang
        val pp = (t - pingAt) / 0.9f
        if (pp in 0f..1f) {
            rippleP.strokeWidth = (3f - 2f * pp) * d
            rippleP.color = Fx.alpha(Fx.GREEN, ((1f - pp) * 220).toInt())
            c.drawPath(octP.oct(cx, cy, r + pp * (big - r + 6f * d)), rippleP)
        }

        if (isAttachedToWindow) postInvalidateOnAnimation()
    }
}
