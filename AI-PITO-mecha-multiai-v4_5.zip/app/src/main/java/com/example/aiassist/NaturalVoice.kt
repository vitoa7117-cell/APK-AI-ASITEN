package com.example.aiassist

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.LinkedBlockingQueue

/**
 * Suara natural lewat Gemini TTS, memakai key Gemini (AIza...) yang sama dengan chat.
 * Pilih suara: tambahkan  voice=Puck  di kolom API key (pilihan: Kore, Puck, Zephyr, Leda,
 * Aoede, Charon, Fenrir, Orus). Kalau tidak diisi, dipakai Kore.
 * Kalau gagal (limit, offline, dll) pemanggil otomatis pindah ke suara bawaan HP.
 *
 * Nama model "preview" sering berganti. Kalau tidak ditemukan, cukup ganti daftar MODELS.
 */
object NaturalVoice {
    private val MODELS = listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")
    private const val RATE = 24000
    private const val STYLE = "Ucapkan dengan hangat, natural, dan santai seperti ngobrol dengan teman: "

    @Volatile private var gen = 0
    @Volatile private var track: AudioTrack? = null
    @Volatile private var goodModel: String? = null

    private class Item(val data: ByteArray?, val err: String?)

    private fun keys(ctx: Context): List<String> =
        Prefs.apiKey(ctx).split(Regex("[,;\\s]+")).filter { it.startsWith("AIza") }.distinct()

    private fun voiceName(ctx: Context): String =
        Regex("voice=([A-Za-z]+)").find(Prefs.apiKey(ctx))?.groupValues?.get(1) ?: "Kore"

    fun available(ctx: Context): Boolean = keys(ctx).isNotEmpty()

    fun stop() {
        gen++
        val t = track
        track = null
        if (t != null) runCatching { t.pause(); t.flush(); t.release() }
    }

    /** Dipanggil dari thread mana saja. onFail / onDone dipanggil dari thread latar. */
    fun speak(ctx: Context, text: String, onFail: () -> Unit, onDone: () -> Unit) {
        stop()
        val my = gen
        val parts = chunks(text)
        val q = LinkedBlockingQueue<Item>()
        val app = ctx.applicationContext

        // produsen: minta suara per potongan kalimat
        Thread {
            for (p in parts) {
                if (gen != my) return@Thread
                try {
                    q.put(Item(fetch(app, p), null))
                } catch (e: Exception) {
                    q.put(Item(null, e.message ?: e.toString()))
                    return@Thread
                }
            }
            q.put(Item(ByteArray(0), null))
        }.start()

        // konsumen: putar begitu potongan pertama siap
        Thread {
            var played = 0L
            var tr: AudioTrack? = null
            try {
                while (gen == my) {
                    val it = q.take()
                    if (it.err != null) {
                        if (tr == null) { if (gen == my) onFail(); return@Thread }
                        break
                    }
                    val d = it.data ?: break
                    if (d.isEmpty()) break
                    if (tr == null) {
                        val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                        tr = AudioTrack.Builder()
                            .setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                            )
                            .setAudioFormat(
                                AudioFormat.Builder()
                                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                    .setSampleRate(RATE)
                                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                            )
                            .setBufferSizeInBytes(maxOf(min * 2, RATE * 2))
                            .setTransferMode(AudioTrack.MODE_STREAM)
                            .build()
                        track = tr
                        tr.play()
                    }
                    tr.write(d, 0, d.size)
                    played += d.size / 2
                }
                if (tr != null && gen == my) {
                    tr.stop()
                    var waited = 0
                    while (gen == my && tr.playbackHeadPosition < played && waited < 600) {
                        Thread.sleep(50)
                        waited++
                    }
                }
            } catch (e: Exception) {
                // diam saja, lanjut ke onDone
            } finally {
                runCatching { tr?.release() }
                if (track === tr) track = null
            }
            if (gen == my) onDone()
        }.start()
    }

    /** Pecah per kalimat. Potongan pertama pendek supaya suara cepat mulai. */
    private fun chunks(t: String): List<String> {
        val sentences = t.split(Regex("(?<=[.!?])\\s+")).filter { it.isNotBlank() }
        val out = mutableListOf<String>()
        var cur = StringBuilder()
        for (s in sentences) {
            val lim = if (out.isEmpty()) 160 else 300
            if (cur.isNotEmpty() && cur.length + s.length + 1 > lim) {
                out.add(cur.toString())
                cur = StringBuilder()
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(s)
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    private fun fetch(ctx: Context, text: String): ByteArray {
        val voice = voiceName(ctx)
        var last: Exception? = null
        val models = goodModel?.let { listOf(it) + MODELS.filter { m -> m != it } } ?: MODELS
        for (k in keys(ctx)) {
            for (m in models) {
                try {
                    val r = call(k, m, voice, text)
                    goodModel = m
                    return r
                } catch (e: Exception) {
                    last = e
                }
            }
        }
        throw last ?: Exception("tidak ada key Gemini")
    }

    private fun call(key: String, model: String, voice: String, text: String): ByteArray {
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", STYLE + text)))))
                .put(
                    "generationConfig", JSONObject()
                        .put("responseModalities", JSONArray().put("AUDIO"))
                        .put(
                            "speechConfig", JSONObject().put(
                                "voiceConfig", JSONObject().put(
                                    "prebuiltVoiceConfig", JSONObject().put("voiceName", voice)
                                )
                            )
                        )
                )
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw Exception("TTS $code: ${resp.take(160)}")
            val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            for (i in 0 until parts.length()) {
                val inl = parts.getJSONObject(i).optJSONObject("inlineData")
                if (inl != null) return Base64.decode(inl.getString("data"), Base64.DEFAULT)
            }
            throw Exception("respons tanpa audio")
        } finally {
            conn.disconnect()
        }
    }
}
