package com.example.aiassist

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.text.StaticLayout
import android.text.TextPaint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.random.Random

/**
 * Pembuat gambar ala bot Raiden, semuanya digambar langsung pakai Canvas (tanpa internet).
 *  iqc      -> chat iPhone (menu tekan lama)
 *  tqc      -> chat TikTok
 *  wq       -> kutipan Windows Media Player
 *  fakecall -> tampilan panggilan WhatsApp iOS
 */
object QuoteGen {

    // ---------- alat bantu ----------
    private fun tp(color: Int, size: Float, bold: Boolean = false) =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    private fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        this.color = color
    }

    private fun stroke(color: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        this.color = color
        strokeWidth = w
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private fun lay(text: String, p: TextPaint, w: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, w).setLineSpacing(0f, 1.12f).build()

    private fun rr(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, p: Paint) =
        c.drawRoundRect(RectF(l, t, r, b), rad, rad, p)

    private fun nowHm(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    private fun nowHms(): String = SimpleDateFormat("HH.mm.ss", Locale.getDefault()).format(Date())

    /** Teks rata tengah (horizontal dan vertikal) di titik cx, cy. */
    private fun ctext(c: Canvas, s: String, cx: Float, cy: Float, p: Paint) {
        p.textAlign = Paint.Align.CENTER
        c.drawText(s, cx, cy - (p.ascent() + p.descent()) / 2f, p)
    }

    /** Teks rata kiri, titik tengah vertikal di cy. */
    private fun ltext(c: Canvas, s: String, x: Float, cy: Float, p: Paint) {
        p.textAlign = Paint.Align.LEFT
        c.drawText(s, x, cy - (p.ascent() + p.descent()) / 2f, p)
    }

    private fun coverRect(b: Bitmap, ratio: Float): Rect {
        val br = b.width.toFloat() / b.height
        return if (br > ratio) {
            val nw = (b.height * ratio).toInt()
            val x = (b.width - nw) / 2
            Rect(x, 0, x + nw, b.height)
        } else {
            val nh = (b.width / ratio).toInt()
            val y = (b.height - nh) / 2
            Rect(0, y, b.width, y + nh)
        }
    }

    private fun drawImg(c: Canvas, b: Bitmap, dst: RectF, rad: Float) {
        val save = c.save()
        val path = Path().apply { addRoundRect(dst, rad, rad, Path.Direction.CW) }
        c.clipPath(path)
        c.drawBitmap(b, coverRect(b, dst.width() / dst.height()), dst, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restoreToCount(save)
    }

    private fun drawCircleImg(c: Canvas, b: Bitmap?, cx: Float, cy: Float, r: Float, letter: String, bg: Int) {
        if (b != null) {
            val save = c.save()
            val path = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
            c.clipPath(path)
            c.drawBitmap(b, coverRect(b, 1f), RectF(cx - r, cy - r, cx + r, cy + r), Paint(Paint.FILTER_BITMAP_FLAG))
            c.restoreToCount(save)
        } else {
            c.drawCircle(cx, cy, r, fill(bg))
            ctext(c, letter.take(1).uppercase(), cx, cy, tp(Color.WHITE, r * 1.0f, true))
        }
    }

    // =====================================================================
    //  IQC : chat iPhone
    // =====================================================================
    fun iqc(text: String, img: Bitmap?): Bitmap {
        val w = 1080
        val bubbleMaxW = 720
        val pad = 34
        val tPaint = tp(Color.WHITE, 54f)
        val timePaint = tp(0xFF8E8E93.toInt(), 38f)
        val timeStr = nowHm()
        val tl = if (text.isNotBlank()) lay(text, tPaint, bubbleMaxW - 2 * pad) else null
        var contentW = 0f
        if (tl != null) for (i in 0 until tl.lineCount) contentW = max(contentW, tl.getLineWidth(i))
        val timeW = timePaint.measureText(timeStr)

        val imgW = bubbleMaxW - 28
        val imgH = if (img != null) (imgW * img.height.toFloat() / img.width).toInt().coerceIn(300, 1000) else 0
        val bubbleW = if (img != null) bubbleMaxW.toFloat()
        else max(max(contentW, timeW) + 2 * pad, 260f)
        var bubbleH = 0f
        if (img != null) bubbleH += 14 + imgH
        if (tl != null) bubbleH += (if (img != null) 22 else 24) + tl.height
        bubbleH += 62f

        val pillTop = 150f
        val bubbleTop = pillTop + 130f + 22f
        val bubbleBottom = bubbleTop + bubbleH
        val menuTop = bubbleBottom + 56f
        val rowH = 132f
        val menuBottom = menuTop + rowH * 5
        val moreTop = menuBottom + 26f
        val total = (moreTop + rowH + 140f).toInt()

        val bmp = Bitmap.createBitmap(w, total, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.BLACK)

        // baris reaksi
        rr(c, 60f, pillTop, 760f, pillTop + 130f, 65f, fill(0xFF2A2A2C.toInt()))
        val emo = listOf("😂", "😍", "😡", "🤍", "😭", "😔")
        val ep = tp(Color.WHITE, 72f)
        emo.forEachIndexed { i, e -> ctext(c, e, 128f + i * 98f, pillTop + 65f, ep) }
        ctext(c, "+", 708f, pillTop + 65f, tp(0xFF8E8E93.toInt(), 64f))

        // balon pesan
        rr(c, 60f, bubbleTop, 60f + bubbleW, bubbleBottom, 44f, fill(0xFF262628.toInt()))
        var y = bubbleTop
        if (img != null) {
            drawImg(c, img, RectF(74f, y + 14f, 74f + imgW, y + 14f + imgH), 30f)
            y += 14f + imgH
        }
        if (tl != null) {
            y += if (img != null) 22f else 24f
            val save = c.save()
            c.translate(60f + pad, y)
            tl.draw(c)
            c.restoreToCount(save)
        }
        timePaint.textAlign = Paint.Align.RIGHT
        c.drawText(timeStr, 60f + bubbleW - 30f, bubbleBottom - 20f, timePaint)

        // menu
        val menuL = 50f
        val menuR = 865f
        rr(c, menuL, menuTop, menuR, menuBottom, 50f, fill(0xFF1C1C1E.toInt()))
        val items = listOf("Beri Bintang" to "☆", "Balas" to "↩", "Teruskan" to "↪", "Salin" to "❐", "Hapus" to "🗑")
        val sep = fill(0xFF38383A.toInt())
        items.forEachIndexed { i, (label, icon) ->
            val cy = menuTop + rowH * i + rowH / 2
            val red = label == "Hapus"
            val col = if (red) 0xFFFF453A.toInt() else Color.WHITE
            ltext(c, label, 96f, cy, tp(col, 58f))
            ctext(c, icon, 770f, cy, tp(col, 62f))
            if (i > 0) c.drawRect(menuL, menuTop + rowH * i - 1f, menuR, menuTop + rowH * i + 1f, sep)
        }
        rr(c, menuL, moreTop, menuR, moreTop + rowH, 50f, fill(0xFF1C1C1E.toInt()))
        ltext(c, "Lainnya...", 96f, moreTop + rowH / 2, tp(Color.WHITE, 58f))
        return bmp
    }

    // =====================================================================
    //  TQC : chat TikTok
    // =====================================================================
    fun tqc(name: String, text: String, avatar: Bitmap?): Bitmap {
        val w = 1080
        val bg = 0xFFF6F4FA.toInt()
        val ink = 0xFF161823.toInt()
        val tPaint = tp(ink, 50f)
        val tl = lay(text.ifBlank { "..." }, tPaint, 640)
        var contentW = 0f
        for (i in 0 until tl.lineCount) contentW = max(contentW, tl.getLineWidth(i))
        val bubbleW = contentW + 70f
        val bubbleH = tl.height + 56f

        val pillTop = 300f
        val bubbleTop = pillTop + 150f + 50f
        val menuTop = bubbleTop + bubbleH + 40f
        val rowH = 96f
        val menuBottom = menuTop + rowH * 6
        val total = (menuBottom + 220f).toInt()

        val bmp = Bitmap.createBitmap(w, total, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(bg)

        // bar atas
        ltext(c, "‹", 40f, 100f, tp(ink, 110f))
        drawCircleImg(c, avatar, 210f, 100f, 48f, name, 0xFF8A7CC0.toInt())
        ltext(c, name, 290f, 100f, tp(ink, 54f, true))
        ltext(c, "•••", 900f, 96f, tp(ink, 56f, true))

        // baris reaksi
        val shadow = fill(0x14000000)
        rr(c, 112f, pillTop + 6f, 962f, pillTop + 156f, 75f, shadow)
        rr(c, 110f, pillTop, 960f, pillTop + 150f, 75f, fill(Color.WHITE))
        listOf("❤️", "😂", "😭", "👍", "😡", "🤔").forEachIndexed { i, e ->
            ctext(c, e, 195f + i * 135f, pillTop + 75f, tp(ink, 84f))
        }

        // balon pesan
        drawCircleImg(c, avatar, 85f, bubbleTop + bubbleH / 2, 50f, name, 0xFF8A7CC0.toInt())
        rr(c, 160f, bubbleTop, 160f + bubbleW, bubbleTop + bubbleH, 44f, fill(Color.WHITE))
        val save = c.save()
        c.translate(160f + 35f, bubbleTop + 28f)
        tl.draw(c)
        c.restoreToCount(save)

        // menu
        val menuL = 90f
        val menuR = 90f + 660f
        rr(c, menuL, menuTop, menuR, menuBottom, 44f, fill(Color.WHITE))
        val items = listOf(
            "Balas" to "↩", "Teruskan" to "↪", "Salin" to "❐",
            "Terjemahkan" to "A文", "Hapus untuk saya" to "🗑", "Laporkan" to "⚑"
        )
        items.forEachIndexed { i, (label, icon) ->
            val cy = menuTop + rowH * i + rowH / 2
            val col = if (label == "Laporkan") 0xFFE0372B.toInt() else ink
            ctext(c, icon, menuL + 85f, cy, tp(col, if (icon == "A文") 36f else 52f, icon == "A文"))
            ltext(c, label, menuL + 170f, cy, tp(col, 50f))
        }
        return bmp
    }

    // =====================================================================
    //  WQ : Windows Media Player quote
    // =====================================================================
    fun wq(text: String): Bitmap {
        val w = 1200
        val h = 1060
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        // latar biru kabur
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(),
            Paint().apply { shader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xFFD7E0F5.toInt(), 0xFF5F7FD0.toInt(), Shader.TileMode.CLAMP) })

        val L = 50f
        val T = 90f
        val R = 1150f
        val B = 1000f
        // bayangan + bingkai biru
        rr(c, L + 6f, T + 14f, R + 6f, B + 14f, 28f, fill(0x44000000))
        val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, T, 0f, T + 100f, 0xFF2F72F2.toInt(), 0xFF0A4FD6.toInt(), Shader.TileMode.CLAMP)
        }
        rr(c, L, T, R, B, 28f, frame)
        c.drawRect(L, T + 60f, R, B, fill(0xFF0A4FD6.toInt()))

        // logo + judul
        val logoCx = L + 62f
        val logoCy = T + 46f
        c.drawCircle(logoCx, logoCy, 34f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = SweepGradient(logoCx, logoCy, intArrayOf(0xFFE8452C.toInt(), 0xFFF2B01E.toInt(), 0xFF3FA535.toInt(), 0xFF2D6FE0.toInt(), 0xFFE8452C.toInt()), null)
        })
        c.drawCircle(logoCx, logoCy, 22f, fill(Color.WHITE))
        c.drawPath(Path().apply {
            moveTo(logoCx - 7f, logoCy - 12f); lineTo(logoCx + 13f, logoCy); lineTo(logoCx - 7f, logoCy + 12f); close()
        }, fill(0xFF1E5AD8.toInt()))
        ltext(c, "Windows Media Player", L + 120f, T + 46f, tp(Color.WHITE, 46f, true))

        // tombol jendela
        val bw = 72f
        val by = T + 18f
        listOf(R - 250f, R - 170f, R - 90f).forEachIndexed { i, x ->
            val close = i == 2
            rr(c, x, by, x + bw, by + 56f, 12f, fill(if (close) 0xFFE0502F.toInt() else 0xFF3D7CF4.toInt()))
            rr(c, x, by, x + bw, by + 56f, 12f, stroke(Color.WHITE, 3f))
            val ip = stroke(Color.WHITE, 7f)
            when (i) {
                0 -> c.drawLine(x + 22f, by + 40f, x + 46f, by + 40f, ip)
                1 -> c.drawRect(x + 20f, by + 14f, x + 52f, by + 40f, ip)
                else -> {
                    c.drawLine(x + 22f, by + 14f, x + 50f, by + 42f, ip)
                    c.drawLine(x + 50f, by + 14f, x + 22f, by + 42f, ip)
                }
            }
        }

        // menu
        val ix = L + 12f
        val ir = R - 12f
        c.drawRect(ix, T + 90f, ir, T + 160f, fill(0xFFF4F4F0.toInt()))
        val mp = tp(Color.BLACK, 36f)
        var mx = ix + 24f
        for (m in listOf("File", "View", "Play", "Tools", "Help")) {
            ltext(c, m, mx, T + 125f, mp)
            val fw = mp.measureText(m.take(1))
            c.drawLine(mx, T + 148f, mx + fw, T + 148f, stroke(Color.BLACK, 2.5f))
            mx += mp.measureText(m) + 62f
        }

        // bar visualisasi
        c.drawRect(ix, T + 172f, ir, T + 220f, fill(0xFFC6CBDD.toInt()))
        c.drawRect(ix + 640f, T + 172f, ir, T + 220f, fill(0xFF1F5CE0.toInt()))

        // area putih
        val cl = ix
        val ct = T + 228f
        val cr = ir
        val cb = B - 170f
        c.drawRect(cl, ct, cr, cb, fill(Color.WHITE))

        // teks otomatis menyesuaikan
        val body = text.ifBlank { "..." }
        val areaW = 540
        val areaH = (cb - ct - 60f).toInt()
        var size = 120f
        val p = tp(0xFF111111.toInt(), size, true)
        var layout = lay(body, p, areaW)
        while (layout.height > areaH && size > 28f) {
            size -= 4f
            p.textSize = size
            layout = lay(body, p, areaW)
        }
        val save = c.save()
        c.translate(cl + 60f, ct + (cb - ct - layout.height) / 2f)
        layout.draw(c)
        c.restoreToCount(save)

        drawFigure(c, 905f, ct + 40f)

        // panel kontrol
        val ctl = B - 160f
        c.drawRect(ix, ctl, ir, B - 12f, Paint().apply {
            shader = LinearGradient(0f, ctl, 0f, B, 0xFF3C74E8.toInt(), 0xFF1239B8.toInt(), Shader.TileMode.CLAMP)
        })
        // tombol play
        val py = ctl + 85f
        c.drawCircle(150f, py, 58f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, py - 58f, 0f, py + 58f, 0xFFFFFFFF.toInt(), 0xFFA9B4D8.toInt(), Shader.TileMode.CLAMP)
        })
        c.drawPath(Path().apply {
            moveTo(132f, py - 24f); lineTo(176f, py); lineTo(132f, py + 24f); close()
        }, fill(0xFF1239B8.toInt()))
        c.drawCircle(258f, py + 6f, 38f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, py - 32f, 0f, py + 44f, 0xFFFFFFFF.toInt(), 0xFFA9B4D8.toInt(), Shader.TileMode.CLAMP)
        })
        c.drawRect(246f, py - 6f, 270f, py + 18f, fill(0xFF1239B8.toInt()))
        // slider
        rr(c, 340f, ctl + 36f, 1100f, ctl + 52f, 8f, fill(0xFF1B3FB0.toInt()))
        rr(c, 366f, ctl + 14f, 400f, ctl + 76f, 8f, fill(0xFFEFF3F0.toInt()))
        rr(c, 372f, ctl + 42f, 394f, ctl + 70f, 6f, fill(0xFF3FB04A.toInt()))
        // prev / next
        listOf(332f, 440f).forEach { x ->
            rr(c, x, ctl + 100f, x + 90f, ctl + 140f, 20f, fill(0xFFC9D4F2.toInt()))
        }
        // mute + volume
        rr(c, 700f, ctl + 98f, 790f, ctl + 142f, 22f, fill(0xFFC9D4F2.toInt()))
        c.drawPath(Path().apply {
            moveTo(830f, ctl + 128f); lineTo(1000f, ctl + 112f); lineTo(1000f, ctl + 134f); lineTo(830f, ctl + 134f); close()
        }, fill(0xFF3FB04A.toInt()))
        rr(c, 980f, ctl + 96f, 1020f, ctl + 148f, 8f, fill(0xFFEFF3F0.toInt()))
        return bmp
    }

    /** Boneka 3D abu-abu yang angkat bahu. */
    private fun drawFigure(c: Canvas, cx: Float, top: Float) {
        fun grad(x0: Float, x1: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(x0, 0f, x1, 0f, 0xFFF4F4F7.toInt(), 0xFFA9A9B6.toInt(), Shader.TileMode.CLAMP)
        }
        // bayangan
        c.drawOval(RectF(cx - 150f, top + 400f, cx + 150f, top + 440f), fill(0x22000000))
        // kaki
        rr(c, cx - 70f, top + 250f, cx - 6f, top + 400f, 30f, grad(cx - 70f, cx - 6f))
        rr(c, cx + 6f, top + 250f, cx + 70f, top + 400f, 30f, grad(cx + 6f, cx + 70f))
        c.drawOval(RectF(cx - 100f, top + 380f, cx - 6f, top + 425f), grad(cx - 100f, cx - 6f))
        c.drawOval(RectF(cx + 6f, top + 380f, cx + 100f, top + 425f), grad(cx + 6f, cx + 100f))
        // badan
        rr(c, cx - 78f, top + 130f, cx + 78f, top + 300f, 70f, grad(cx - 78f, cx + 78f))
        // lengan
        val armL = Path().apply { moveTo(cx - 62f, top + 160f); lineTo(cx - 130f, top + 235f); lineTo(cx - 205f, top + 200f) }
        val armR = Path().apply { moveTo(cx + 62f, top + 160f); lineTo(cx + 130f, top + 235f); lineTo(cx + 205f, top + 200f) }
        val ap = stroke(0xFFC9C9D3.toInt(), 46f)
        c.drawPath(armL, ap)
        c.drawPath(armR, ap)
        c.drawOval(RectF(cx - 260f, top + 168f, cx - 190f, top + 215f), fill(0xFFDADAE2.toInt()))
        c.drawOval(RectF(cx + 190f, top + 168f, cx + 260f, top + 215f), fill(0xFFDADAE2.toInt()))
        // kepala
        c.drawCircle(cx, top + 70f, 78f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = android.graphics.RadialGradient(cx - 24f, top + 44f, 100f, 0xFFFFFFFF.toInt(), 0xFFB4B4C2.toInt(), Shader.TileMode.CLAMP)
        })
    }

    // =====================================================================
    //  FAKECALL : panggilan WhatsApp iOS
    // =====================================================================
    fun fakecall(name: String, time: String, photo: Bitmap?): Bitmap {
        val w = 1080
        val h = 2340
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(0xFF0A0A0A.toInt())

        // corak doodle samar
        val rnd = Random(7)
        val dp = stroke(0xFF1F1F1F.toInt(), 4f)
        for (i in 0 until 170) {
            val x = rnd.nextInt(w).toFloat()
            val y = rnd.nextInt(h).toFloat()
            val s = 22f + rnd.nextInt(46)
            when (rnd.nextInt(4)) {
                0 -> c.drawCircle(x, y, s / 2, dp)
                1 -> rr(c, x, y, x + s * 1.4f, y + s, 10f, dp)
                2 -> c.drawLine(x, y, x + s, y + s * 0.4f, dp)
                else -> c.drawArc(RectF(x, y, x + s, y + s), 20f, 250f, false, dp)
            }
        }

        // atas
        val white = Color.WHITE
        ctext(c, name.ifBlank { "Kontak" }, w / 2f, 130f, tp(white, 64f, true))
        ctext(c, time.ifBlank { nowHms() }, w / 2f, 205f, tp(0xFFB5B5B5.toInt(), 48f))
        val ip = stroke(white, 8f)
        // ikon perkecil
        c.drawLine(70f, 100f, 112f, 142f, ip)
        c.drawLine(70f, 100f, 70f, 124f, ip)
        c.drawLine(70f, 100f, 94f, 100f, ip)
        c.drawLine(112f, 142f, 112f, 118f, ip)
        c.drawLine(112f, 142f, 88f, 142f, ip)
        // ikon tambah orang
        c.drawCircle(965f, 105f, 17f, fill(white))
        c.drawArc(RectF(932f, 128f, 998f, 188f), 180f, 180f, true, fill(white))
        ctext(c, "+", 1010f, 160f, tp(white, 40f, true))

        // foto bulat
        val pcx = w / 2f
        val pcy = 1020f
        val pr = 310f
        c.drawCircle(pcx, pcy, pr + 12f, fill(0xFFDEDEEA.toInt()))
        drawCircleImg(c, photo, pcx, pcy, pr, name.ifBlank { "K" }, 0xFF3A3A3C.toInt())

        // tombol bawah
        val by = 2100f
        val r = 82f
        val xs = listOf(173f, 357f, 540f, 722f, 905f)
        val gray = 0xFF3A3A3C.toInt()
        xs.forEachIndexed { i, x ->
            val col = when (i) {
                2 -> Color.WHITE
                4 -> 0xFFFF2D55.toInt()
                else -> gray
            }
            c.drawCircle(x, by, r, fill(col))
        }
        // ... (lainnya)
        listOf(-30f, 0f, 30f).forEach { dx -> c.drawCircle(xs[0] + dx, by, 8f, fill(white)) }
        // video
        rr(c, xs[1] - 32f, by - 22f, xs[1] + 12f, by + 22f, 10f, fill(white))
        c.drawPath(Path().apply {
            moveTo(xs[1] + 16f, by - 8f); lineTo(xs[1] + 36f, by - 20f); lineTo(xs[1] + 36f, by + 20f); lineTo(xs[1] + 16f, by + 8f); close()
        }, fill(white))
        // speaker
        val dark = 0xFF111111.toInt()
        val sx = xs[2] - 10f
        c.drawPath(Path().apply {
            moveTo(sx - 26f, by - 12f); lineTo(sx - 8f, by - 12f); lineTo(sx + 14f, by - 30f)
            lineTo(sx + 14f, by + 30f); lineTo(sx - 8f, by + 12f); lineTo(sx - 26f, by + 12f); close()
        }, fill(dark))
        val sp = stroke(dark, 6f)
        c.drawArc(RectF(sx + 8f, by - 20f, sx + 36f, by + 20f), -50f, 100f, false, sp)
        c.drawArc(RectF(sx + 8f, by - 34f, sx + 52f, by + 34f), -50f, 100f, false, sp)
        // mic dicoret
        val mx = xs[3]
        rr(c, mx - 12f, by - 34f, mx + 12f, by + 6f, 12f, fill(white))
        c.drawArc(RectF(mx - 26f, by - 22f, mx + 26f, by + 26f), 0f, 180f, false, stroke(white, 6f))
        c.drawLine(mx, by + 26f, mx, by + 40f, stroke(white, 6f))
        c.drawLine(mx - 32f, by - 34f, mx + 32f, by + 36f, stroke(gray, 16f))
        c.drawLine(mx - 32f, by - 34f, mx + 32f, by + 36f, stroke(white, 6f))
        // akhiri panggilan
        val ex = xs[4]
        c.drawArc(RectF(ex - 50f, by - 28f, ex + 50f, by + 52f), 200f, 140f, false, stroke(white, 24f))

        // indikator home
        rr(c, 394f, 2290f, 686f, 2302f, 6f, fill(0xFFEAEAEA.toInt()))
        return bmp
    }
}
