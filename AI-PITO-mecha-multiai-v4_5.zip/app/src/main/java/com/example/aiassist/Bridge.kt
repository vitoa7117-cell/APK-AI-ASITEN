package com.example.aiassist

import android.graphics.Bitmap

/** Jembatan sederhana antar Activity/Service. */
object Bridge {
    var onImage: ((Bitmap) -> Unit)? = null
    var onCancel: (() -> Unit)? = null
    var onMic: ((Boolean) -> Unit)? = null
    var onPick: ((List<Pair<java.io.File, String>>) -> Unit)? = null
}
