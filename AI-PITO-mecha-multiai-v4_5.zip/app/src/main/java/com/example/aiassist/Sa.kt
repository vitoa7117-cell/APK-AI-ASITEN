package com.example.aiassist

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.media.ExifInterface
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer

/** Perakit WebP animasi dari beberapa WebP diam (tanpa ffmpeg / library tambahan). */
object AnimWebp {
    private fun u24(n: Int) = byteArrayOf(n.toByte(), (n shr 8).toByte(), (n shr 16).toByte())
    private fun u32(n: Int) = byteArrayOf(n.toByte(), (n shr 8).toByte(), (n shr 16).toByte(), (n shr 24).toByte())

    private fun chunk(tag: String, data: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(tag.toByteArray(Charsets.US_ASCII))
        o.write(u32(data.size))
        o.write(data)
        if (data.size % 2 == 1) o.write(0)
        return o.toByteArray()
    }

    /** Ambil chunk ALPH / VP8 / VP8L (lengkap dengan header) dari file WebP diam. */
    private fun frameChunks(webp: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        var p = 12
        while (p + 8 <= webp.size) {
            val tag = String(webp, p, 4, Charsets.US_ASCII)
            val len = (webp[p + 4].toInt() and 255) or ((webp[p + 5].toInt() and 255) shl 8) or
                ((webp[p + 6].toInt() and 255) shl 16) or ((webp[p + 7].toInt() and 255) shl 24)
            val total = 8 + len + (len and 1)
            if (tag == "ALPH" || tag == "VP8 " || tag == "VP8L") o.write(webp, p, minOf(total, webp.size - p))
            p += total
        }
        return o.toByteArray()
    }

    fun mux(stills: List<ByteArray>, w: Int, h: Int, durMs: Int): ByteArray {
        val parts = stills.map { frameChunks(it) }
        val hasAlpha = parts.any { it.size >= 4 && String(it, 0, 4, Charsets.US_ASCII) == "ALPH" }
        val body = ByteArrayOutputStream()
        body.write("WEBP".toByteArray(Charsets.US_ASCII))
        val vp8x = ByteArray(10)
        vp8x[0] = (0x02 or (if (hasAlpha) 0x10 else 0)).toByte()      // bit animasi (+ alpha)
        u24(w - 1).copyInto(vp8x, 4)
        u24(h - 1).copyInto(vp8x, 7)
        body.write(chunk("VP8X", vp8x))
        body.write(chunk("ANIM", ByteArray(6)))                        // latar 0, ulang tanpa batas
        for (f in parts) {
            val d = ByteArrayOutputStream()
            d.write(u24(0)); d.write(u24(0))                           // x, y
            d.write(u24(w - 1)); d.write(u24(h - 1))
            d.write(u24(durMs))
            d.write(0)                                                 // blend + dispose
            d.write(f)
            body.write(chunk("ANMF", d.toByteArray()))
        }
        val out = ByteArrayOutputStream()
        out.write("RIFF".toByteArray(Charsets.US_ASCII))
        out.write(u32(body.size()))
        out.write(body.toByteArray())
        return out.toByteArray()
    }
}

/**
 * Stiker ala .sa bot, versi app:
 *  - video  -> stiker animasi (WebP) + audio video dipisah (m4a)
 *  - foto + audio -> stiker diam + audio
 * Suara TIDAK bisa menempel di dalam stiker lewat app (itu hanya bisa dikirim klien WhatsApp),
 * jadi audionya dikirim terpisah ke WhatsApp.
 */
object SaMaker {
    /**
     * preview/webp/audio = hasil di dalam app. src/srcIsVideo/srcAudio/seconds = file asli,
     * dipakai untuk dikirim ke nara-bot supaya jadi stiker suara asli.
     */
    class Result(
        val preview: Bitmap,
        val webp: ByteArray?,
        val audio: File?,
        val src: File? = null,
        val srcIsVideo: Boolean = false,
        val srcAudio: File? = null,
        val seconds: Int = 0
    )

    fun durationSec(f: File): Int = try {
        val m = MediaMetadataRetriever()
        try {
            m.setDataSource(f.path)
            val ms = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            Math.ceil(ms / 1000.0).toInt().coerceIn(0, 60)
        } finally { runCatching { m.release() } }
    } catch (e: Exception) { 0 }

    private fun square(src: Bitmap): Bitmap {
        val s = minOf(src.width, src.height)
        val out = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
        out.setHasAlpha(false)
        Canvas(out).drawBitmap(
            src,
            Rect((src.width - s) / 2, (src.height - s) / 2, (src.width + s) / 2, (src.height + s) / 2),
            Rect(0, 0, 512, 512),
            Paint(Paint.FILTER_BITMAP_FLAG)
        )
        return out
    }

    fun fromVideo(cacheDir: File, video: File, maxSec: Int = 6): Result {
        val mmr = MediaMetadataRetriever()
        val frames = ArrayList<Bitmap>()
        try {
            mmr.setDataSource(video.path)
            val durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val sec = minOf(durMs / 1000.0, maxSec.toDouble())
            val n = maxOf(1, (sec * 8).toInt())
            for (i in 0 until n) {
                val f = mmr.getFrameAtTime(i * 1_000_000L / 8, MediaMetadataRetriever.OPTION_CLOSEST) ?: continue
                frames.add(square(f))
                f.recycle()
            }
        } finally {
            runCatching { mmr.release() }
        }
        if (frames.isEmpty()) throw Exception("frame video tidak terbaca")

        // Coba beberapa kombinasi fps & kualitas sampai muat di bawah 500 KB.
        val fmt = StickerStore.webpFormat()
        var webp: ByteArray? = null
        for ((fps, q) in listOf(8 to 50, 8 to 35, 8 to 22, 4 to 40, 4 to 25, 4 to 12)) {
            val step = 8 / fps
            val stills = ArrayList<ByteArray>()
            var total = 0
            for ((i, f) in frames.withIndex()) {
                if (i % step != 0) continue
                val bos = ByteArrayOutputStream()
                f.compress(fmt, q, bos)
                stills.add(bos.toByteArray())
                total += bos.size()
                if (total > StickerStore.ANIM_LIMIT) break
            }
            if (total > StickerStore.ANIM_LIMIT) continue
            val out = AnimWebp.mux(stills, 512, 512, 1000 / fps)
            if (out.size <= StickerStore.ANIM_LIMIT) { webp = out; break }
        }
        val preview = frames[0]
        frames.drop(1).forEach { it.recycle() }
        // webp == null: terlalu berat jadi stiker gerak di app, tapi bot tetap bisa memprosesnya.

        val audio = File(cacheDir, "sa_audio.m4a")
        val hasAudio = extractAudio(video, audio, 60)
        return Result(preview, webp, if (hasAudio) audio else null,
            src = video, srcIsVideo = true, seconds = maxOf(1, durationSec(video)))
    }

    fun fromPhoto(photo: File, audio: File?): Result {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(photo.path, o)
        var sample = 1
        while (o.outWidth / sample > 2048 || o.outHeight / sample > 2048) sample *= 2
        var bmp = BitmapFactory.decodeFile(photo.path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw Exception("foto tidak terbaca")
        val deg = runCatching {
            when (ExifInterface(photo.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        }.getOrDefault(0)
        if (deg != 0) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg.toFloat()) }, true)
        return Result(bmp, null, audio, src = photo, srcIsVideo = false, srcAudio = audio,
            seconds = if (audio != null) durationSec(audio) else 0)
    }

    /** Salin jalur audio AAC dari video ke file m4a (tanpa re-encode). false kalau tidak ada / bukan AAC. */
    fun extractAudio(video: File, out: File, maxSec: Int): Boolean {
        val ex = MediaExtractor()
        var mux: MediaMuxer? = null
        return try {
            ex.setDataSource(video.path)
            var idx = -1
            for (i in 0 until ex.trackCount) {
                if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { idx = i; break }
            }
            if (idx < 0) return false
            val fmt = ex.getTrackFormat(idx)
            if (fmt.getString(MediaFormat.KEY_MIME) != "audio/mp4a-latm") return false // muxer MP4 hanya AAC
            ex.selectTrack(idx)
            out.delete()
            val m = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = m
            val t = m.addTrack(fmt)
            m.start()
            val buf = ByteBuffer.allocate(1 shl 20)
            val info = MediaCodec.BufferInfo()
            val limit = maxSec * 1_000_000L
            while (true) {
                val size = ex.readSampleData(buf, 0)
                if (size < 0 || ex.sampleTime > limit) break
                info.set(0, size, ex.sampleTime, ex.sampleFlags)
                m.writeSampleData(t, buf, info)
                ex.advance()
            }
            m.stop()
            true
        } catch (e: Exception) {
            false
        } finally {
            runCatching { mux?.release() }
            runCatching { ex.release() }
        }
    }
}
