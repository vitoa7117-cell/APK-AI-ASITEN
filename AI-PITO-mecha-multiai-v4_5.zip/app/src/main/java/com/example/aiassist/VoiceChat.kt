package com.example.aiassist

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Ngobrol pakai suara:
 *  - mendengar : SpeechRecognizer bawaan Android (bahasa Indonesia)
 *  - bicara    : TextToSpeech bawaan Android (suara Indonesia)
 */
class VoiceChat(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onPartial: (String) -> Unit,
    private val onStatus: (String) -> Unit,
    private val onFail: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeak: String? = null
    private var pendingDone: (() -> Unit)? = null
    private var retries = 0
    @Volatile var active = false

    fun hasMic(): Boolean =
        ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    // ---------- mendengar ----------
    fun listen() {
        if (!hasMic()) { onFail("Izin mikrofon belum diberikan"); return }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onFail("Pengenal suara tidak tersedia di HP ini (butuh aplikasi Google / Layanan Suara)")
            return
        }
        active = true
        main.post {
            if (!active) return@post
            rec?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(ctx)
            rec = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { onStatus("🎤 Mendengarkan...") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onPartialResults(p: Bundle?) {
                    val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) onPartial(t)
                }
                override fun onResults(res: Bundle?) {
                    val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (t.isBlank()) { onError(SpeechRecognizer.ERROR_NO_MATCH); return }
                    retries = 0
                    onText(t)
                }
                override fun onError(e: Int) {
                    if (!active) return
                    when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                            retries++
                            if (retries >= 4) {
                                active = false
                                onFail("Tidak ada suara terdengar, mode suara dimatikan")
                            } else main.postDelayed({ if (active) listen() }, 400)
                        }
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> main.postDelayed({ if (active) listen() }, 800)
                        else -> {
                            active = false
                            onFail("Gagal mendengar (kode $e)")
                        }
                    }
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            }
            r.startListening(i)
        }
    }

    // ---------- bicara ----------
    private fun ensureTts() {
        if (tts != null) return
        tts = TextToSpeech(ctx) { st ->
            val t = tts
            if (st == TextToSpeech.SUCCESS && t != null) {
                var r = t.setLanguage(Locale("id", "ID"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    r = t.setLanguage(Locale.getDefault())
                }
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                t.setSpeechRate(1.05f)
                t.setPitch(1.1f)
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { finishSpeak() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { finishSpeak() }
                })
                val p = pendingSpeak
                pendingSpeak = null
                if (p != null) main.post { doSpeak(p) }
            } else {
                main.post { finishSpeak() }
            }
        }
    }

    private fun finishSpeak() {
        main.post {
            val d = pendingDone
            pendingDone = null
            d?.invoke()
        }
    }

    private fun doSpeak(text: String) {
        val t = tts
        if (t == null || !ttsReady) { finishSpeak(); return }
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "pito")
    }

    /** Bersihkan markdown, kode, link, dan emoji supaya enak didengar. */
    private fun clean(s: String): String {
        var t = s
        t = t.replace(Regex("```[\\s\\S]*?```"), " (ada kode, lihat di layar) ")
        t = t.replace(Regex("https?://\\S+"), " link ")
        t = t.replace(Regex("[*_#`>|~]"), "")
        t = t.replace(Regex("[\\p{So}\\p{Sk}\\uFE0F\\u200D]"), "")
        t = t.replace(Regex("\\s+"), " ").trim()
        if (t.length > 900) {
            val cut = t.substring(0, 900)
            val end = maxOf(cut.lastIndexOf('.'), cut.lastIndexOf('!'), cut.lastIndexOf('?'))
            t = if (end > 300) cut.substring(0, end + 1) else cut
        }
        return t
    }

    fun speak(text: String, done: () -> Unit) {
        val t = clean(text)
        if (t.isEmpty()) { done(); return }
        pendingDone = done
        if (NaturalVoice.available(ctx)) {
            // suara natural (Gemini). Kalau gagal, jatuh ke suara bawaan HP.
            NaturalVoice.speak(
                ctx, t,
                onFail = {
                    main.post {
                        ensureTts()
                        if (ttsReady) doSpeak(t) else pendingSpeak = t
                    }
                },
                onDone = { finishSpeak() }
            )
            return
        }
        ensureTts()
        if (ttsReady) doSpeak(t) else pendingSpeak = t
    }

    // ---------- berhenti ----------
    fun stop() {
        active = false
        pendingDone = null
        pendingSpeak = null
        retries = 0
        main.post {
            rec?.cancel()
            rec?.destroy()
            rec = null
        }
        NaturalVoice.stop()
        tts?.stop()
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
    }
}
