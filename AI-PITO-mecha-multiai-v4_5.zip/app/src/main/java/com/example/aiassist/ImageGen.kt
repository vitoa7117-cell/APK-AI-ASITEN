package com.example.aiassist

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.random.Random

/**
 * Pembuat gambar dari teks.
 *  1) Cloudflare Workers AI (model FLUX) -> hasil terbaik, gratis dengan jatah harian.
 *     Cara pakai: di kolom API key tambahkan  cf=ACCOUNT_ID:API_TOKEN
 *  2) Pollinations -> tanpa key, dipakai sebagai cadangan (bisa lambat / dibatasi).
 */
object ImageGen {
    private const val CF_MODEL = "@cf/black-forest-labs/flux-1-schnell"

    fun cloudflareKeys(raw: String): List<String> =
        raw.split(Regex("[,;\\s]+")).filter { it.startsWith("cf=") && it.length > 4 }.distinct()

    fun generate(ctx: Context, prompt: String): Bitmap {
        val errors = mutableListOf<String>()
        for (k in cloudflareKeys(Prefs.apiKey(ctx))) {
            try {
                return cloudflare(k.removePrefix("cf="), prompt)
            } catch (e: Exception) {
                errors.add("Cloudflare: ${e.message ?: e.toString()}")
            }
        }
        try {
            return pollinations(prompt)
        } catch (e: Exception) {
            errors.add("Pollinations: ${e.message ?: e.toString()}")
        }
        throw Exception(errors.joinToString("\n"))
    }

    private fun readAll(conn: HttpURLConnection): Pair<Int, ByteArray> {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        return code to (stream?.use { it.readBytes() } ?: ByteArray(0))
    }

    private fun decode(bytes: ByteArray): Bitmap? = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)

    private fun cloudflare(spec: String, prompt: String): Bitmap {
        val idx = spec.indexOf(':')
        if (idx <= 0 || idx == spec.length - 1) {
            throw Exception("format key salah. Tulis: cf=ACCOUNT_ID:API_TOKEN")
        }
        val account = spec.substring(0, idx).trim()
        val token = spec.substring(idx + 1).trim()
        val conn = URL("https://api.cloudflare.com/client/v4/accounts/$account/ai/run/$CF_MODEL")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 30000
        conn.readTimeout = 120000
        conn.doOutput = true
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Content-Type", "application/json")
        val body = JSONObject().put("prompt", prompt.take(2000)).put("steps", 8)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val (code, bytes) = readAll(conn)

        // hasil bisa berupa JSON (gambar base64) atau langsung gambar
        if (code in 200..299 && bytes.isNotEmpty() && bytes[0] != '{'.code.toByte()) {
            decode(bytes)?.let { return it }
        }
        val text = String(bytes, Charsets.UTF_8)
        val json = runCatching { JSONObject(text) }.getOrNull()
        if (code in 200..299 && json != null) {
            val b64 = json.optJSONObject("result")?.optString("image") ?: ""
            if (b64.isNotEmpty()) {
                val raw = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                decode(raw)?.let { return it }
            }
        }
        val msg = json?.optJSONArray("errors")?.optJSONObject(0)?.optString("message")
            ?: text.take(200)
        throw Exception("HTTP $code: $msg")
    }

    private fun pollinations(prompt: String): Bitmap {
        val q = URLEncoder.encode(prompt.take(700), "UTF-8").replace("+", "%20")
        val seed = Random.nextInt(1, 999999)
        val url = "https://image.pollinations.ai/prompt/$q?width=1024&height=1024&model=flux&nologo=true&seed=$seed"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 30000
        conn.readTimeout = 150000
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) AI-PITO")
        val (code, bytes) = readAll(conn)
        if (code in 200..299) {
            decode(bytes)?.let { return it }
            throw Exception("balasan bukan gambar")
        }
        throw Exception("HTTP $code (server gambar gratis sedang sibuk/dibatasi)")
    }
}
