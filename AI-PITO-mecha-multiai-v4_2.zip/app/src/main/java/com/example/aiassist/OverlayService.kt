package com.example.aiassist

import android.animation.Animator
import android.animation.ValueAnimator
import android.animation.ObjectAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.content.ContentValues
import android.graphics.Outline
import android.provider.MediaStore
import android.view.ViewOutlineProvider
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: BubbleView? = null
    private var bubbleBg: CutDrawable? = null
    private val bubbleAnims = mutableListOf<Animator>()

    private var panel: View? = null
    private var panelShown = false
    private var panelAttached = false

    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var preview: TextView
    private lateinit var sendBtn: ImageView
    private lateinit var micBtn: ImageView
    private var voiceMode = false
    private var cropNext = false
    private var accHintShown = false
    private var cropView: View? = null
    private val voice by lazy {
        VoiceChat(
            this,
            onText = { t ->
                handler.post {
                    if (voiceMode) {
                        input.setText(t)
                        send()
                        if (!busy) setVoice(false)
                    }
                }
            },
            onPartial = { t -> handler.post { input.hint = "🎤 $t" } },
            onStatus = { t -> handler.post { input.hint = t } },
            onFail = { msg ->
                handler.post {
                    setVoice(false)
                    addMsg("⚠️ $msg", user = false, error = true)
                }
            }
        )
    }

    private val history = JSONArray()
    private var pendingImage: Bitmap? = null
    private var busy = false

    private var thinkingView: View? = null
    private var suggestionsView: View? = null
    private var imageMode = false
    private var imageChip: View? = null
    private var mp3Mode = false
    private var mp3Btn: View? = null
    private var revealRunnable: Runnable? = null

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startFg()
        buildPanel()
        buildBubble()

        Bridge.onImage = { bmp ->
            handler.post {
                if (cropNext) { cropNext = false; showCrop(bmp) }
                else { setPending(bmp); showPanel() }
            }
        }
        Bridge.onCancel = { handler.post { cropNext = false; showPanel() } }
        Bridge.onPick = { files -> handler.post { showPanel(); handleSa(files) } }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("overlay", "Bubble AI", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "overlay")
            .setContentTitle("AI PITO aktif")
            .setContentText("Ketuk bubble untuk bertanya")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ================= Bubble =================

    private fun buildBubble() {
        Sfx.init(this)
        val size = dp(76)
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels

        val v = BubbleView(this)

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW - size
            y = screenH / 3
        }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        var snap: ValueAnimator? = null
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    snap?.cancel()
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                    view.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + dx; lp.y = sy + dy
                        wm.updateViewLayout(view, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator(3f)).start()
                    if (!moved) {
                        if (panelShown) hidePanel() else showPanel()
                    } else {
                        val target = if (lp.x + size / 2 < screenW / 2) 0 else screenW - size
                        snap = ValueAnimator.ofInt(lp.x, target).apply {
                            duration = 380
                            interpolator = OvershootInterpolator(1.6f)
                            addUpdateListener {
                                lp.x = it.animatedValue as Int
                                runCatching { wm.updateViewLayout(view, lp) }
                            }
                            start()
                        }
                        Sfx.play("ping")
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
                    true
                }
                else -> false
            }
        }
        bubble = v
        wm.addView(v, lp)

        // animasi masuk: membal muncul sambil berputar (napas & denyut diurus BubbleView sendiri)
        v.scaleX = 0f; v.scaleY = 0f; v.rotation = -180f
        v.animate().scaleX(1f).scaleY(1f).rotation(0f)
            .setDuration(750).setInterpolator(OvershootInterpolator(2f)).start()
        Sfx.play("open")
    }

    private fun setBubbleBusy(b: Boolean) {
        bubble?.busy = b
    }

    // ================= Panel chat =================

    private fun buildPanel() {
        val root = object : NeonFrame(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.action == KeyEvent.ACTION_UP) hidePanel()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14), dp(14), dp(14), dp(14))

        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT
        val match = LinearLayout.LayoutParams.MATCH_PARENT

        // ===== header =====
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(MechaFace(this), LinearLayout.LayoutParams(dp(54), dp(54)))

        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        titleBox.addView(ShimmerTitle(this).apply {
            textSize = 17f
            letterSpacing = 0.12f
            gravity = Gravity.START
        })
        val status = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        status.addView(PulseDot(this, Fx.GREEN))
        status.addView(TextView(this).apply {
            text = "NEURAL ASSISTANT • ONLINE"
            setTextColor(Fx.GREEN)
            textSize = 9f
            letterSpacing = 0.12f
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = dp(6) })
        titleBox.addView(status, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(3) })
        header.addView(titleBox, LinearLayout.LayoutParams(0, wrap, 1f))

        val btnLp = { LinearLayout.LayoutParams(dp(36), dp(36)).apply { leftMargin = dp(6) } }
        header.addView(PanelUi.iconBtn(this, R.drawable.ic_trash, Fx.INK) { clearChat() }, btnLp())
        header.addView(PanelUi.iconBtn(this, R.drawable.ic_power, Fx.PINK) { stopSelf() }, btnLp())
        header.addView(PanelUi.iconBtn(this, R.drawable.ic_close, Fx.INK) { hidePanel() }, btnLp())
        root.addView(header)

        // garis pemisah neon
        root.addView(View(this).apply {
            background = CutDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0x00FF2537, 0x99FF2537.toInt(), 0x00FF5C8D)
            )
        }, LinearLayout.LayoutParams(match, dp(1)).apply { topMargin = dp(10) })

        // ===== area chat =====
        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(8))
        }
        scroll = ScrollView(this).apply { addView(messages); isVerticalScrollBarEnabled = false }
        root.addView(scroll, LinearLayout.LayoutParams(match, 0, 1f))

        // ===== lampiran =====
        preview = TextView(this).apply {
            setTextColor(0xFFFF9EAE.toInt())
            textSize = 12f
            background = Ui.rounded(0x22FF0015, dp(10), 0x55FF2537, dp(1))
            setPadding(dp(10), dp(6), dp(10), dp(6))
            visibility = View.GONE
            setOnClickListener { setPending(null) }
        }
        root.addView(preview, LinearLayout.LayoutParams(wrap, wrap).apply { bottomMargin = dp(6) })

        // ===== tombol scan & gambar =====
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(PanelUi.chip(this, R.drawable.ic_phone, "Scan", Fx.CYAN, compact = true) { scanScreen() },
            LinearLayout.LayoutParams(0, wrap, 1f))
        actions.addView(PanelUi.chip(this, R.drawable.ic_camera, "Kamera", Fx.PINK, compact = true) { scanCamera() },
            LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(6) })
        val imgChip = PanelUi.chip(this, R.drawable.ic_sparkle, "Gambar", Fx.GREEN, compact = true) { toggleImageMode() }
        imageChip = imgChip
        actions.addView(imgChip, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(6) })
        val mp3Chip = PanelUi.chip(this, R.drawable.ic_save, "MP3", Fx.VIOLET, compact = true) { toggleMp3Mode() }
        mp3Btn = mp3Chip
        actions.addView(mp3Chip, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(6) })
        actions.addView(PanelUi.chip(this, R.drawable.ic_sparkle, "SA", Fx.PINK, compact = true) { pickSa() },
            LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(6) })
        root.addView(actions)

        // ===== input =====
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Tanya apa saja..."
            setHintTextColor(Ui.MUTED)
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 4
            background = PanelUi.fieldBg(this@OverlayService, false)
            setPadding(dp(16), dp(11), dp(16), dp(11))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setOnFocusChangeListener { v, focused -> v.background = PanelUi.fieldBg(this@OverlayService, focused) }
        }
        row.addView(input, LinearLayout.LayoutParams(0, wrap, 1f))
        micBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_mic)
            setColorFilter(Color.WHITE, android.graphics.PorterDuff.Mode.SRC_IN)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(11), dp(11), dp(11), dp(11))
            background = CutDrawable().apply {
                shape = CutDrawable.OVAL
                setColor(0x33FF2537)
                setStroke(dp(2), 0x66FF2537)
            }
            isClickable = true
            setOnClickListener { toggleVoice() }
            Ui.pressable(this)
        }
        row.addView(micBtn, LinearLayout.LayoutParams(dp(46), dp(46)).apply { leftMargin = dp(8) })
        sendBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_send)
            setColorFilter(Color.WHITE, android.graphics.PorterDuff.Mode.SRC_IN)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(11), dp(11), dp(11), dp(11))
            background = CutDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(Ui.PURPLE, 0xFFD40012.toInt())
            ).apply {
                shape = CutDrawable.OVAL
                setStroke(dp(2), 0x66FF2537)
            }
            isClickable = true
            setOnClickListener { send() }
            Ui.pressable(this)
        }
        row.addView(sendBtn, LinearLayout.LayoutParams(dp(46), dp(46)).apply { leftMargin = dp(8) })
        root.addView(row, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(10) })

        // latar video mecha + percikan api di belakang isi panel, dipotong mengikuti bingkai bersudut
        val frame = android.widget.FrameLayout(this)
        val full = android.widget.FrameLayout.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT
        )
        frame.addView(VideoBackground(this), full)
        frame.addView(View(this).apply { setBackgroundColor(0x77080204) }, android.widget.FrameLayout.LayoutParams(full))
        frame.addView(EmberView(this, 22), android.widget.FrameLayout.LayoutParams(full))
        frame.addView(root, android.widget.FrameLayout.LayoutParams(full))
        frame.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, outline: android.graphics.Outline) {
                val k = dp(18).toFloat()
                val w = v.width.toFloat()
                val h = v.height.toFloat()
                val path = android.graphics.Path()
                path.moveTo(k, 0f); path.lineTo(w, 0f); path.lineTo(w, h - k)
                path.lineTo(w - k, h); path.lineTo(0f, h); path.lineTo(0f, k); path.close()
                outline.setConvexPath(path)
            }
        }
        frame.clipToOutline = true
        panel = frame
        addWelcome()
    }

    private fun addWelcome() {
        addMsg("Halo! Aku AI PITO 🤖\nTanya apa saja, minta bantuan coding, atau scan layar (atur kotak ke soalnya, langsung dijawab).\n\nFitur gambar: .iqc  .tqc  .wq  .fakecall (ketik perintahnya untuk lihat contoh)\nStiker: .sa (pilih video, atau foto + voice note). Stiker suara asli via bot: .sabot (cek) .satoken .sato\nNgobrol pakai suara: ketuk tombol mic 🎤", user = false)
        addSuggestions()
    }

    /** Saran pertanyaan cepat, hilang begitu pengguna mulai chat. */
    private fun addSuggestions() {
        val ideas = listOf(
            "Ajari aku dasar coding" to "Ajari aku dasar coding dari nol, singkat dan jelas.",
            "Ide konten kreatif" to "Kasih 5 ide konten kreatif yang lagi tren.",
            "Buat gambar AI" to "Buatkan gambar kucing astronaut melayang di luar angkasa, gaya sinematik.",
            "Tips lebih produktif" to "Kasih 5 tips supaya aku lebih produktif."
        )
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ideas.forEachIndexed { i, (label, prompt) ->
            val chip = PanelUi.chip(this, R.drawable.ic_sparkle, label, 0xFFFF9CBA.toInt()) {
                if (!busy) {
                    input.setText(prompt)
                    send()
                }
            }
            box.addView(chip, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) })
            Ui.enter(chip, 350L + i * 120L, dp(12).toFloat())
        }
        messages.addView(box, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.START })
        suggestionsView = box
    }

    private fun removeSuggestions() {
        suggestionsView?.let { messages.removeView(it) }
        suggestionsView = null
    }

    private fun clearChat() {
        if (busy) return
        revealRunnable?.let { handler.removeCallbacks(it) }
        revealRunnable = null
        while (history.length() > 0) history.remove(0)
        messages.removeAllViews()
        suggestionsView = null
        setPending(null)
        addWelcome()
    }

    private fun showPanel() {
        val p = panel ?: return
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.94).toInt()
        val h = (dm.heightPixels * 0.62).toInt()
        panelShown = true
        Sfx.play("open")
        if (!panelAttached) {
            val lp = WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = dp(30)
                softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
            }
            wm.addView(p, lp)
            panelAttached = true
        }
        p.animate().cancel()
        p.pivotX = w * 0.92f
        p.pivotY = 0f
        p.alpha = 0f
        p.scaleX = 0.7f
        p.scaleY = 0.7f
        p.translationY = -dp(12).toFloat()
        p.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(320).setInterpolator(OvershootInterpolator(1.1f)).start()
    }

    private fun hidePanel() {
        val p = panel ?: return
        if (!panelShown) return
        panelShown = false
        Sfx.play("close")
        p.animate().cancel()
        p.animate().alpha(0f).scaleX(0.85f).scaleY(0.85f).translationY(-dp(8).toFloat())
            .setDuration(180).setInterpolator(DecelerateInterpolator())
            .withEndAction {
                if (!panelShown && panelAttached) {
                    runCatching { wm.removeView(p) }
                    panelAttached = false
                }
            }.start()
    }

    private fun setPending(bmp: Bitmap?) {
        pendingImage = bmp
        if (bmp != null) {
            preview.text = "Gambar terlampir • ketuk untuk menghapus"
            preview.visibility = View.VISIBLE
        } else {
            preview.visibility = View.GONE
        }
    }

    // ================= Pesan =================

    private fun scrollDown(smooth: Boolean = true) {
        scroll.post {
            if (smooth) scroll.smoothScrollTo(0, messages.height) else scroll.scrollTo(0, messages.height)
        }
    }

    private fun addMsg(text: String, user: Boolean, error: Boolean = false): TextView {
        if (error) Sfx.play("error")
        val maxW = (resources.displayMetrics.widthPixels * 0.94 * 0.8).toInt()
        val tv = TextView(this).apply {
            this.text = text
            textSize = 14.5f
            maxWidth = maxW
            setLineSpacing(dp(2).toFloat(), 1f)
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setTextIsSelectable(true)
            background = when {
                error -> PanelUi.errorBubble(this@OverlayService)
                user -> PanelUi.userBubble(this@OverlayService)
                else -> PanelUi.aiBubble(this@OverlayService)
            }
            if (!user && !error) setTextColor(Ui.TEXT)
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = if (user) Gravity.END else Gravity.START
            topMargin = dp(8)
        }
        messages.addView(tv, lp)
        tv.alpha = 0f
        tv.translationY = dp(16).toFloat()
        tv.translationX = if (user) dp(18).toFloat() else -dp(18).toFloat()
        tv.animate().alpha(1f).translationY(0f).translationX(0f)
            .setDuration(300).setInterpolator(DecelerateInterpolator()).start()
        scrollDown()
        return tv
    }

    private fun startThinking(label: String = "sedang berpikir") {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = PanelUi.aiBubble(this@OverlayService)
            setPadding(dp(14), dp(9), dp(16), dp(9))
        }
        row.addView(MorphLoader(this))
        row.addView(TextView(this).apply {
            text = label
            setTextColor(Ui.MUTED)
            textSize = 12f
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { leftMargin = dp(8) })
        messages.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.START
            topMargin = dp(8)
        })
        row.alpha = 0f
        row.animate().alpha(1f).setDuration(220).start()
        thinkingView = row
        scrollDown()
    }

    private fun stopThinking() {
        thinkingView?.let { messages.removeView(it) }
        thinkingView = null
    }

    /** Teks AI muncul bertahap (efek mengetik, dengan kursor titik). */
    private fun reveal(tv: TextView, full: String) {
        bubble?.ping()
        Sfx.play("recv")
        var idx = 0
        val step = max(3, full.length / 90)
        val r = object : Runnable {
            override fun run() {
                idx = minOf(full.length, idx + step)
                tv.text = if (idx < full.length) full.substring(0, idx) + " ●" else full
                scrollDown(false)
                if (idx < full.length) handler.postDelayed(this, 16) else revealRunnable = null
            }
        }
        revealRunnable = r
        handler.post(r)
    }

    // ================= Scan =================

    // ================= Scan hemat token: kotak scan + OCR di HP =================

    private fun removeCrop() {
        cropView?.let { runCatching { wm.removeView(it) } }
        cropView = null
    }

    private fun showCrop(bmp: Bitmap) {
        removeCrop()
        val v = ScanCropView(
            this, bmp,
            onScan = { crop -> handler.post { removeCrop(); showPanel(); quickScan(crop) } },
            onCancel = { handler.post { removeCrop(); showPanel() } }
        )
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(v, lp)
            cropView = v
        } catch (e: Exception) {
            setPending(bmp)
            showPanel()
        }
    }

    /** Baca teks di area terpilih (OCR di HP, gratis), kirim TEKS saja ke AI, jawab langsung. */
    private fun quickScan(crop: Bitmap) {
        if (busy) return
        removeSuggestions()
        val userTv = addMsg("📷 Membaca area layar...", user = true)
        startThinking("membaca layar")
        setBusy(true)
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { r -> askScan(r.text.trim(), crop, userTv) }
            .addOnFailureListener { askScan("", crop, userTv) }
    }

    private fun askScan(text: String, crop: Bitmap, userTv: TextView) {
        val useText = text.length >= 8
        userTv.text = if (useText)
            "📷 " + text.replace("\n", " ").take(140) + (if (text.length > 140) "…" else "")
        else "📷 (teks tidak terbaca, kirim sebagai gambar kecil)"
        Thread {
            var reply: String? = null
            var error: String? = null
            try {
                reply = if (useText) Api.quick(this, text, null) else Api.quick(this, "", crop)
            } catch (e: Exception) {
                error = e.message ?: e.toString()
            }
            handler.post {
                stopThinking()
                if (reply != null) {
                    history.put(JSONObject().put("role", "user").put("content", "[scan layar] " + text.take(600)))
                    history.put(JSONObject().put("role", "assistant").put("content", reply))
                    reveal(addMsg("", user = false), reply)
                    if (voiceMode) voice.speak(reply) { if (voiceMode && !busy) voice.listen() }
                } else {
                    addMsg("⚠️ Error: $error", user = false, error = true)
                }
                setBusy(false)
            }
        }.start()
    }


    private fun scanScreen() {
        cropNext = true
        hidePanel()
        // Jalur utama: screenshot lewat Accessibility, TANPA berbagi layar (Android 11+).
        val acc = ScanAccessibilityService.instance
        if (android.os.Build.VERSION.SDK_INT >= 30 && acc != null) {
            handler.postDelayed({
                acc.shoot { bmp ->
                    if (bmp != null) Bridge.onImage?.invoke(bmp) else Bridge.onCancel?.invoke()
                }
            }, 500)
            return
        }
        // Cadangan: berbagi layar sekali jepret (otomatis berhenti setelah scan).
        if (android.os.Build.VERSION.SDK_INT >= 30 && !accHintShown) {
            accHintShown = true
            android.widget.Toast.makeText(this,
                "Tips: aktifkan \"AI PITO Scan\" di Pengaturan > Aksesibilitas supaya scan tanpa berbagi layar",
                android.widget.Toast.LENGTH_LONG).show()
        }
        val cs = CaptureService.instance
        if (cs != null) {
            handler.postDelayed({ cs.capture() }, 500)
        } else {
            startActivity(Intent(this, ProjectionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun scanCamera() {
        cropNext = true
        hidePanel()
        startActivity(Intent(this, CameraActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ================= Kirim ke AI =================

    private fun stripOldImages() {
        for (i in 0 until history.length()) {
            val content = history.getJSONObject(i).opt("content")
            if (content is JSONArray) {
                for (j in 0 until content.length()) {
                    if (content.getJSONObject(j).optString("type") == "image") {
                        content.put(j, JSONObject().put("type", "text").put("text", "[gambar sebelumnya]"))
                    }
                }
            }
        }
    }

    private fun setBusy(b: Boolean) {
        busy = b
        sendBtn.alpha = if (b) 0.4f else 1f
        setBubbleBusy(b)
    }

    private fun send() {
        if (busy) return
        val q = input.text.toString().trim()
        val img = pendingImage
        if (q.isEmpty() && img == null) return
        if (Regex("^[./](sa|s|stiker|sticker)\\s*$", RegexOption.IGNORE_CASE).matches(q)) {
            input.setText("")
            if (img != null) { setPending(null); addSaMsg(SaMaker.Result(img, null, null)) } else pickSa()
            return
        }
        Regex("^[./](sabot|satoken|sato)(?:\\s+(.*))?$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(q)?.let {
            input.setText("")
            handleBotCmd(it.groupValues[1].lowercase(), it.groupValues[2].trim())
            return
        }
        if (runFx(q, img)) return
        if (img == null) {
            val tt = VideoDl.extractLink(q)
            if (tt != null) {
                sendVideo(tt, mp3Mode || VideoDl.wantsAudio(q))
                return
            }
            val ask = if (imageMode) q.removePrefix("/gambar ").trim() else imageIntent(q)
            if (!ask.isNullOrEmpty()) {
                sendImage(ask)
                return
            }
        }
        if (Prefs.apiKey(this).isBlank()) {
            addMsg("⚠️ API key belum diisi. Buka app AI PITO lalu isi dulu.", user = false, error = true)
            return
        }

        removeSuggestions()
        stripOldImages()
        val content = JSONArray()
        if (img != null) {
            content.put(
                JSONObject().put("type", "image").put(
                    "source", JSONObject()
                        .put("type", "base64")
                        .put("media_type", "image/jpeg")
                        .put("data", Api.toBase64(img))
                )
            )
        }
        val text = if (q.isEmpty()) "Jawab, selesaikan, atau jelaskan isi gambar ini." else q
        content.put(JSONObject().put("type", "text").put("text", text))
        history.put(JSONObject().put("role", "user").put("content", content))

        addMsg((if (img != null) "📎 " else "") + text, user = true)
        startThinking()
        input.setText("")
        setPending(null)
        setBusy(true)

        Thread {
            var reply: String? = null
            var error: String? = null
            try {
                reply = Api.chat(this, history)
            } catch (e: Exception) {
                error = e.message ?: e.toString()
            }
            handler.post {
                stopThinking()
                if (reply != null) {
                    history.put(JSONObject().put("role", "assistant").put("content", reply))
                    reveal(addMsg("", user = false), reply)
                    if (voiceMode) voice.speak(reply) { if (voiceMode && !busy) voice.listen() }
                } else {
                    history.remove(history.length() - 1)
                    addMsg("⚠️ Error: $error", user = false, error = true)
                    if (voiceMode) setVoice(false)
                }
                setBusy(false)
            }
        }.start()
    }

    // ================= Ngobrol pakai suara =================

    private fun setVoice(on: Boolean) {
        voiceMode = on
        micBtn.background = CutDrawable().apply {
            shape = CutDrawable.OVAL
            if (on) {
                setColor(0xFFE9681E.toInt())
                setStroke(dp(2), 0xAAFFAF80.toInt())
            } else {
                setColor(0x33FF2537)
                setStroke(dp(2), 0x66FF2537)
            }
        }
        if (!on) {
            voice.stop()
            updateHint()
        }
    }

    private fun toggleVoice() {
        if (voiceMode) {
            setVoice(false)
            return
        }
        if (!voice.hasMic()) {
            Bridge.onMic = { ok ->
                handler.post {
                    if (ok) startVoice()
                    else addMsg("⚠️ Izin mikrofon ditolak, mode suara tidak bisa dipakai.", user = false, error = true)
                }
            }
            startActivity(Intent(this, MicPermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        startVoice()
    }

    private fun startVoice() {
        removeSuggestions()
        setVoice(true)
        if (!busy) voice.listen()
    }

    // ================= Fitur gambar ala bot Raiden =================

    private val fxRegex = Regex("^[./](iqc|tqc|wq|fakecall)(?:\\s+(.*))?$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

    private fun fxHelp(cmd: String): String = when (cmd) {
        "iqc" -> "Contoh: .iqc biar apa? biarin\n(lampirkan gambar dulu kalau mau chat dengan foto)"
        "tqc" -> "Contoh: .tqc Raiden|kenapa yhh??\n(lampirkan gambar untuk foto profil)"
        "wq" -> "Contoh: .wq just friend kok cemburu 🤓"
        else -> "Contoh: .fakecall bubub|08.55.09\n(lampirkan gambar untuk foto penelepon)"
    }

    /** Menangani .iqc .tqc .wq .fakecall. Mengembalikan true kalau pesan ini perintah fitur. */
    private fun runFx(q: String, img: Bitmap?): Boolean {
        val m = fxRegex.find(q) ?: return false
        val cmd = m.groupValues[1].lowercase()
        val arg = m.groupValues[2].trim()
        if (busy) return true
        if (arg.isEmpty() && !(cmd == "fakecall" || (cmd == "iqc" && img != null))) {
            removeSuggestions()
            addMsg(fxHelp(cmd), user = false)
            return true
        }
        removeSuggestions()
        addMsg((if (img != null) "📎 " else "") + q, user = true)
        startThinking("sedang membuat")
        input.setText("")
        setPending(null)
        setBusy(true)
        Thread {
            var bmp: Bitmap? = null
            var error: String? = null
            try {
                val parts = arg.split("|", limit = 2).map { it.trim() }
                bmp = when (cmd) {
                    "iqc" -> QuoteGen.iqc(arg, img)
                    "tqc" -> if (parts.size == 2) QuoteGen.tqc(parts[0].ifBlank { "Teman" }, parts[1], img)
                             else QuoteGen.tqc("Teman", arg, img)
                    "wq" -> QuoteGen.wq(arg)
                    else -> QuoteGen.fakecall(parts.getOrElse(0) { "" }, parts.getOrElse(1) { "" }, img)
                }
            } catch (e: Throwable) {
                error = e.message ?: e.toString()
            }
            handler.post {
                stopThinking()
                if (bmp != null) addImageMsg(bmp, "", "", canRegen = false)
                else addMsg("⚠️ Gagal membuat gambar: $error", user = false, error = true)
                setBusy(false)
            }
        }.start()
        return true
    }

    // ================= Unduh video TikTok =================

    private fun sendVideo(link: String, audio: Boolean = false) {
        if (busy) return
        removeSuggestions()
        addMsg(link, user = true)
        startThinking(if (audio) "mengambil audio" else "mengunduh video")
        input.setText("")
        setBusy(true)

        Thread {
            var saved: VideoDl.Saved? = null
            var title = ""
            var error: String? = null
            try {
                var info = VideoDl.resolve(this, link, audio, hq = true)
                title = listOf(info.author, info.title).filter { it.isNotBlank() }.joinToString(" - ")
                saved = try {
                    VideoDl.download(this, info)
                } catch (e: Exception) {
                    if (audio) throw e
                    info = VideoDl.resolve(this, link, audio, hq = false)
                    VideoDl.download(this, info)
                }
            } catch (e: Exception) {
                error = e.message ?: e.toString()
            }
            handler.post {
                stopThinking()
                if (saved != null) {
                    val t = if (title.isNotBlank()) "\n$title" else ""
                    val res = if (saved!!.width > 0) "\n🎞 Resolusi: ${saved!!.width}×${saved!!.height}" else ""
                    val head = if (audio) "🎵 MP3 tersimpan" else "✅ Tersimpan"
                    addMsg("$head$t$res\n📁 ${saved!!.location}", user = false)
                    bubble?.ping()
                    Sfx.play("recv")
                    Toast.makeText(
                        this, if (audio) "Audio tersimpan di folder Musik" else "Video tersimpan di galeri",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    addMsg("⚠️ Gagal mengunduh ${if (audio) "audio" else "video"}:\n$error", user = false, error = true)
                }
                setBusy(false)
            }
        }.start()
    }

    // ================= Gambar AI =================

    private fun toggleImageMode() {
        imageMode = !imageMode
        imageChip?.background = PanelUi.chipBg(this, Fx.GREEN, imageMode)
        if (imageMode && mp3Mode) {
            mp3Mode = false
            mp3Btn?.background = PanelUi.chipBg(this, Fx.VIOLET, false)
        }
        updateHint()
    }

    /** Mode MP3: link video apa pun hanya diambil audionya (MP3). */
    private fun toggleMp3Mode() {
        mp3Mode = !mp3Mode
        mp3Btn?.background = PanelUi.chipBg(this, Fx.VIOLET, mp3Mode)
        if (mp3Mode && imageMode) {
            imageMode = false
            imageChip?.background = PanelUi.chipBg(this, Fx.GREEN, false)
        }
        updateHint()
    }

    private fun updateHint() {
        input.hint = when {
            imageMode -> "Deskripsikan gambar yang mau dibuat..."
            mp3Mode -> "Tempel link video, aku ambil MP3-nya..."
            else -> "Tanya apa saja..."
        }
    }

    /** Mendeteksi permintaan seperti "buatkan gambar kucing" atau "/gambar kucing". */
    private fun imageIntent(q: String): String? {
        val t = q.trim()
        for (p in listOf("/gambar ", "/img ", "/image ")) {
            if (t.startsWith(p, ignoreCase = true)) return t.substring(p.length).trim()
        }
        val re = Regex(
            "^(tolong\\s+)?(buatkan|buatin|bikinin|bikin|buat|gambarkan|gambarin|lukiskan|generate|create|draw|make)\\s+" +
                "(\\S+\\s+)?(gambar|foto|ilustrasi|image|picture|lukisan|wallpaper|logo|poster)\\b",
            RegexOption.IGNORE_CASE
        )
        return if (re.containsMatchIn(t)) t else null
    }

    private fun sendImage(prompt: String, enhanced: String? = null, showUser: Boolean = true) {
        if (busy) return
        removeSuggestions()
        if (showUser) addMsg(prompt, user = true)
        startThinking("sedang melukis")
        input.setText("")
        setBusy(true)

        Thread {
            var bmp: Bitmap? = null
            var error: String? = null
            var used = enhanced ?: prompt
            try {
                if (enhanced == null) {
                    used = runCatching { Api.imagePrompt(this, prompt) }.getOrDefault(prompt)
                }
                bmp = ImageGen.generate(this, used)
            } catch (e: Exception) {
                error = e.message ?: e.toString()
            }
            handler.post {
                stopThinking()
                if (bmp != null) {
                    if (showUser) {
                        history.put(JSONObject().put("role", "user").put("content", "Buatkan gambar: $prompt"))
                        history.put(JSONObject().put("role", "assistant").put("content", "(gambar sudah dibuat)"))
                    }
                    addImageMsg(bmp, prompt, used)
                } else {
                    addMsg("⚠️ Gagal membuat gambar:\n$error", user = false, error = true)
                }
                setBusy(false)
            }
        }.start()
    }

    private fun addImageMsg(bmp: Bitmap, prompt: String, used: String, canRegen: Boolean = true) {
        bubble?.ping()
        Sfx.play("recv")
        val maxW = (resources.displayMetrics.widthPixels * 0.94 * 0.8).toInt()
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = PanelUi.aiBubble(this@OverlayService)
            setPadding(dp(6), dp(6), dp(6), dp(8))
        }
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
                }
            }
            clipToOutline = true
        }
        card.addView(iv, LinearLayout.LayoutParams(maxW - dp(12), wrap))

        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btns.addView(PanelUi.chip(this, R.drawable.ic_save, "Simpan", Fx.CYAN, compact = true) { saveToGallery(bmp) },
            LinearLayout.LayoutParams(0, wrap, 1f))
        btns.addView(PanelUi.chip(this, R.drawable.ic_sparkle, "Stiker", Fx.GREEN, compact = true) { addSticker(bmp) },
            LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(6) })
        if (canRegen) btns.addView(PanelUi.chip(this, R.drawable.ic_bolt, "Buat ulang", Fx.PINK, compact = true) {
            if (!busy) sendImage(prompt, used, showUser = false)
        }, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(6) })
        card.addView(btns, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, wrap).apply { topMargin = dp(6) })

        messages.addView(card, LinearLayout.LayoutParams(wrap, wrap).apply {
            gravity = Gravity.START
            topMargin = dp(8)
        })
        card.alpha = 0f
        card.translationY = dp(16).toFloat()
        card.animate().alpha(1f).translationY(0f).setDuration(300).setInterpolator(DecelerateInterpolator()).start()
        scrollDown()
    }

    /** Jadikan stiker WhatsApp (diam): simpan ke pack, kalau sudah >= 3 langsung buka WhatsApp. */
    private fun addSticker(bmp: Bitmap) = saveSticker(Pack.STATIC) { StickerStore.add(this, bmp) }

    private fun saveSticker(pack: Pack, make: () -> Int) {
        Thread {
            val n = try {
                make()
            } catch (e: Exception) {
                handler.post { Toast.makeText(this, "Gagal bikin stiker: ${e.message}", Toast.LENGTH_LONG).show() }
                return@Thread
            }
            handler.post {
                if (n < StickerStore.MIN) {
                    Toast.makeText(this,
                        "Stiker tersimpan ($n/${StickerStore.MIN}). Buat ${StickerStore.MIN - n} lagi, lalu bisa dimasukkan ke WhatsApp",
                        Toast.LENGTH_LONG).show()
                } else if (!StickerStore.openWhatsApp(this, pack)) {
                    Toast.makeText(this, "Stiker tersimpan ($n), tapi WhatsApp tidak ditemukan", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ================= .sa : video / foto + suara jadi stiker WhatsApp =================

    private fun pickSa() {
        if (busy) return
        hidePanel()
        startActivity(Intent(this, PickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun handleSa(files: List<Pair<java.io.File, String>>) {
        val video = files.firstOrNull { it.second.startsWith("video/") }?.first
        val image = files.firstOrNull { it.second.startsWith("image/") }?.first
        val audio = files.firstOrNull { it.second.startsWith("audio/") }?.first
        if (video == null && image == null) {
            addMsg("Pilih 1 video (bersuara), atau 1 foto + 1 audio/voice note sekaligus.", user = false)
            return
        }
        if (busy) return
        removeSuggestions()
        addMsg(if (video != null) "🎞️ Video jadi stiker..." else "🖼️ Foto + suara jadi stiker...", user = true)
        startThinking("membuat stiker")
        setBusy(true)
        Thread {
            var r: SaMaker.Result? = null
            var error: String? = null
            try {
                r = if (video != null) SaMaker.fromVideo(cacheDir, video) else SaMaker.fromPhoto(image!!, audio)
            } catch (e: Throwable) {
                error = e.message ?: e.toString()
            }
            handler.post {
                stopThinking()
                if (r != null) addSaMsg(r) else addMsg("⚠️ Gagal: $error", user = false, error = true)
                setBusy(false)
            }
        }.start()
    }

    private fun addSaMsg(r: SaMaker.Result) {
        bubble?.ping()
        Sfx.play("recv")
        val maxW = (resources.displayMetrics.widthPixels * 0.94 * 0.8).toInt()
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = PanelUi.aiBubble(this@OverlayService)
            setPadding(dp(6), dp(6), dp(6), dp(8))
        }
        val iv = ImageView(this).apply {
            setImageBitmap(r.preview)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
                }
            }
            clipToOutline = true
        }
        card.addView(iv, LinearLayout.LayoutParams(maxW - dp(12), wrap))

        val note = TextView(this).apply {
            setTextColor(Ui.MUTED)
            textSize = 11f
            text = when {
                r.srcIsVideo && r.webp == null -> "Video terlalu berat jadi stiker gerak di app. Pakai tombol bot untuk stiker suara asli."
                else -> (if (r.webp != null) "Stiker gerak" else "Stiker diam") +
                    (if (r.audio != null) " + suara (di app, suara dikirim terpisah)" else "")
            }
            setPadding(dp(4), dp(6), dp(4), 0)
        }
        card.addView(note, LinearLayout.LayoutParams(maxW - dp(12), wrap))

        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        if (!(r.srcIsVideo && r.webp == null)) {
            btns.addView(PanelUi.chip(this, R.drawable.ic_sparkle, "Stiker WA", Fx.GREEN, compact = true) {
                if (r.webp != null) saveSticker(Pack.ANIM) { StickerStore.addAnimated(this, r.webp, r.preview) }
                else addSticker(r.preview)
            }, LinearLayout.LayoutParams(0, wrap, 1f))
        }
        r.audio?.let { a ->
            btns.addView(PanelUi.chip(this, R.drawable.ic_mic, "Suara ke WA", Fx.CYAN, compact = true) { shareAudio(a) },
                LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(6) })
        }
        if (btns.childCount > 0) {
            card.addView(btns, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, wrap).apply { topMargin = dp(6) })
        }
        if (r.src != null && (r.srcIsVideo || r.srcAudio != null)) {
            card.addView(PanelUi.chip(this, R.drawable.ic_rocket, "Stiker suara asli (bot)", Fx.VIOLET, compact = true) { sendViaBot(r) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, wrap).apply { topMargin = dp(6) })
        }

        messages.addView(card, LinearLayout.LayoutParams(wrap, wrap).apply {
            gravity = Gravity.START
            topMargin = dp(8)
        })
        card.alpha = 0f
        card.translationY = dp(16).toFloat()
        card.animate().alpha(1f).translationY(0f).setDuration(300).setInterpolator(DecelerateInterpolator()).start()
        scrollDown()
    }

    private val botOffHelp =
        "Bot tidak ketemu (belum jalan, atau versi lama tanpa jembatan).\n" +
        "Buka Termux lalu ketik:\ncd nara-bot\npm2 start index.js --name nara-bot\n" +
        "(tanpa pm2: node index.js). Pakai nara-bot fix31 atau lebih baru. Setelah jalan, ketik .sabot untuk cek."

    /** Kirim ke nara-bot supaya jadi stiker suara asli. */
    private fun sendViaBot(r: SaMaker.Result) {
        val src = r.src ?: return
        if (busy) return
        if (Prefs.saToken(this).isBlank()) {
            addMsg("Token bot belum diisi. Jalankan bot di Termux, lihat baris \"TOKEN: ...\" di lognya (pm2 logs nara-bot), lalu ketik:\n.satoken <token>", user = false)
            return
        }
        removeSuggestions()
        addMsg("📤 Kirim ke bot...", user = true)
        startThinking("bot membuat stiker suara")
        setBusy(true)
        Thread {
            val st = BotBridge.ping(this)
            val err: String = when {
                !st.reachable -> "OFF"
                st.error != null -> st.error
                !st.connected -> "Bot nyala, tapi WhatsApp-nya belum tersambung. Cek log bot."
                else -> BotBridge.sendSa(this, src, r.srcIsVideo, r.srcAudio, r.seconds)
            }
            handler.post {
                stopThinking()
                when {
                    err.isEmpty() -> {
                        val to = Prefs.saTo(this)
                        addMsg("✅ Stiker suara dikirim bot ke " +
                            (if (to.isBlank()) "nomor bot sendiri (chat \"Kirim pesan ke diri sendiri\"). Atur tujuan: .sato 628xxxx" else to) + ". Cek WhatsApp.",
                            user = false)
                    }
                    err == "OFF" -> addMsg(botOffHelp, user = false, error = true)
                    else -> addMsg("⚠️ $err", user = false, error = true)
                }
                setBusy(false)
            }
        }.start()
    }

    /** .sabot (cek bot) | .satoken <token> | .sato <nomor|kosong> */
    private fun handleBotCmd(cmd: String, arg: String) {
        removeSuggestions()
        when (cmd) {
            "satoken" -> {
                Prefs.setSaToken(this, arg)
                addMsg(if (arg.isBlank()) "Token dihapus." else "Token tersimpan. Ketik .sabot untuk cek bot.", user = false)
            }
            "sato" -> {
                var n = arg.filter { it.isDigit() }
                if (n.startsWith("0")) n = "62" + n.drop(1)
                Prefs.setSaTo(this, n)
                addMsg(if (n.isEmpty()) "Tujuan dikosongkan: stiker dikirim ke nomor bot sendiri." else "Tujuan stiker suara: $n", user = false)
            }
            else -> {
                if (busy) return
                startThinking("mengecek bot")
                setBusy(true)
                Thread {
                    val st = BotBridge.ping(this)
                    handler.post {
                        stopThinking()
                        val to = Prefs.saTo(this).ifBlank { "nomor bot sendiri" }
                        when {
                            !st.reachable -> addMsg("Bot: ❌ tidak jalan / tidak ketemu\n\n$botOffHelp", user = false, error = true)
                            st.error != null -> addMsg("Bot: nyala, tapi ${st.error}", user = false, error = true)
                            !st.connected -> addMsg("Bot: nyala ✅, WhatsApp belum tersambung ❌ (cek log bot)", user = false, error = true)
                            else -> addMsg("Bot: nyala ✅ WhatsApp tersambung (${st.me})\nTujuan stiker suara: $to", user = false)
                        }
                        setBusy(false)
                    }
                }.start()
            }
        }
    }

    private fun shareAudio(f: java.io.File) {
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "audio/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = android.content.ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
                try {
                    startActivity(Intent(i).setPackage(pkg))
                    return
                } catch (_: Exception) {
                }
            }
            startActivity(Intent.createChooser(i, "Kirim suara").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal kirim suara: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveToGallery(bmp: Bitmap) {
        try {
            val name = "AI_PITO_${System.currentTimeMillis()}.png"
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI PITO")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: throw Exception("gagal membuat file")
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                Toast.makeText(this, "Tersimpan di galeri (Pictures/AI PITO)", Toast.LENGTH_LONG).show()
            } else {
                val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES) ?: filesDir
                val f = File(dir, name)
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                Toast.makeText(this, "Tersimpan di ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menyimpan: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        Bridge.onImage = null
        Bridge.onCancel = null
        Bridge.onMic = null
        Bridge.onPick = null
        removeCrop()
        runCatching { voice.shutdown() }
        handler.removeCallbacksAndMessages(null)
        bubbleAnims.forEach { it.cancel() }
        panel?.let { if (panelAttached) runCatching { wm.removeView(it) } }
        panelAttached = false
        bubble?.let { runCatching { wm.removeView(it) } }
        stopService(Intent(this, CaptureService::class.java))
        super.onDestroy()
    }
}
