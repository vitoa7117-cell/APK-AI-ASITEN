# AI PITO – UI Redesign

Prototype tampilan baru AI PITO (robot mecha, HUD neon, aurora, card glass).

- `index.html` – satu file, tanpa dependency. Buka di browser.
- `preview.png` – screenshot full layar.

## GitHub Pages
Settings → Pages → Branch `main` / root → buka link yang muncul.

## Catatan
Ini prototype web. Untuk dipasang ke APK Android (`com.example.aiassist`) tampilan perlu ditulis ulang native di Kotlin.
