package com.example.aiassist

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.TextView

/** Helper tampilan: warna, background, animasi kecil. */
object Ui {
    val BG_TOP = 0xFF0B0720.toInt()
    val BG_MID = 0xFF1A1033.toInt()
    val BG_BOT = 0xFF0F172A.toInt()
    val CARD = 0xFF241A45.toInt()
    val FIELD = 0xFF2E2358.toInt()
    val CYAN = 0xFF00E5FF.toInt()
    val PURPLE = 0xFF7C4DFF.toInt()
    val PINK = 0xFFFF4081.toInt()
    val TEXT = 0xFFEAEAF5.toInt()
    val MUTED = 0xFF9A93B8.toInt()
    val STROKE = 0x3300E5FF

    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radius: Int, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeW > 0) setStroke(strokeW, strokeColor)
        }

    fun gradient(
        c1: Int, c2: Int, radius: Int,
        orientation: GradientDrawable.Orientation = GradientDrawable.Orientation.LEFT_RIGHT
    ): GradientDrawable = GradientDrawable(orientation, intArrayOf(c1, c2)).apply {
        cornerRadius = radius.toFloat()
    }

    /** Efek tekan: mengecil sedikit lalu balik. */
    fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).start()
                MotionEvent.ACTION_UP -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    Sfx.init(view.context)
                    Sfx.play("tap")
                }
                MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
    }

    fun pill(
        ctx: Context, label: String, bg: Drawable, color: Int,
        sizeSp: Float = 13f, onClick: () -> Unit
    ): TextView = TextView(ctx).apply {
        text = label
        setTextColor(color)
        textSize = sizeSp
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = bg
        setPadding(dp(ctx, 14), dp(ctx, 9), dp(ctx, 14), dp(ctx, 9))
        isClickable = true
        setOnClickListener { onClick() }
        pressable(this)
    }

    /** Muncul: fade + naik dari bawah. */
    fun enter(v: View, delay: Long, dy: Float) {
        v.alpha = 0f
        v.translationY = dy
        v.animate().alpha(1f).translationY(0f)
            .setStartDelay(delay).setDuration(520)
            .setInterpolator(DecelerateInterpolator()).start()
    }
}
