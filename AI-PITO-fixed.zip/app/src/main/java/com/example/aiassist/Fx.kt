package com.example.aiassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Warna + waktu bersama untuk semua efek visual. */
object Fx {
    val BG = 0xFF03040C.toInt()
    val CYAN = 0xFF25E8FF.toInt()
    val VIOLET = 0xFF8A5CFF.toInt()
    val PINK = 0xFFFF3D9A.toInt()
    val GREEN = 0xFF2DFFA0.toInt()
    val INK = 0xFFEAF6FF.toInt()
    val MUTE = 0xFF8A93B8.toInt()

    private val t0 = SystemClock.uptimeMillis()
    fun time(): Float = (SystemClock.uptimeMillis() - t0) / 1000f

    fun alpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)
    fun clear(color: Int): Int = color and 0x00FFFFFF

    fun sp(ctx: Context, v: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, ctx.resources.displayMetrics)
}

/* ====================================================================== */
/*  LATAR: aurora bergerak + lantai grid ala synthwave + partikel cahaya   */
/* ====================================================================== */
class AuroraBackground(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val base = Paint().apply { color = Fx.BG }
    private val blobP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d }
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val vignP = Paint()

    private class Blob(val cx: Float, val cy: Float, val rw: Float, val color: Int, val sp: Float)

    private val blobs = listOf(
        Blob(0.10f, 0.06f, 0.95f, 0xB02B6BFF.toInt(), 0.35f),
        Blob(0.95f, 0.30f, 0.90f, 0xA08A2BFF.toInt(), 0.28f),
        Blob(0.40f, 0.64f, 1.00f, 0x7000D5FF.toInt(), 0.22f),
        Blob(0.95f, 0.97f, 0.70f, 0x70FF3D9A.toInt(), 0.30f)
    )
    private var blobShaders: List<Shader> = emptyList()

    private val n = 28
    private val rnd = java.util.Random(7)
    private val px = FloatArray(n) { rnd.nextFloat() }
    private val ps = FloatArray(n) { 0.04f + rnd.nextFloat() * 0.07f }
    private val po = FloatArray(n) { rnd.nextFloat() }
    private val pz = FloatArray(n) { 0.8f + rnd.nextFloat() * 1.6f }
    private val pk = BooleanArray(n) { rnd.nextFloat() > 0.72f }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        blobShaders = blobs.map {
            RadialGradient(0f, 0f, it.rw * w, it.color, Fx.clear(it.color), Shader.TileMode.CLAMP)
        }
        val y0 = h * 0.66f
        gridP.shader = LinearGradient(
            0f, y0, 0f, h.toFloat(),
            Fx.alpha(Fx.CYAN, 0), Fx.alpha(Fx.CYAN, 120), Shader.TileMode.CLAMP
        )
        vignP.shader = RadialGradient(
            w / 2f, h * 0.30f, max(w, h) * 0.85f,
            intArrayOf(0x00000008, 0x00000008, 0xCC000008.toInt()),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = Fx.time()
        c.drawRect(0f, 0f, w, h, base)

        // aurora
        for (i in blobs.indices) {
            if (i >= blobShaders.size) break
            val b = blobs[i]
            val x = w * (b.cx + 0.12f * sin(t * b.sp + i))
            val y = h * (b.cy + 0.06f * sin(t * b.sp * 0.8f + i * 1.7f))
            blobP.shader = blobShaders[i]
            c.save()
            c.translate(x, y)
            c.drawCircle(0f, 0f, b.rw * w, blobP)
            c.restore()
        }

        // lantai grid
        val y0 = h * 0.66f
        for (i in -10..10) {
            c.drawLine(w / 2f + i * w * 0.012f, y0, w / 2f + i * w * 0.16f, h, gridP)
        }
        val ph = (t * 0.5f) % 1f
        for (k in 0 until 10) {
            val f = (k + ph) / 10f
            val y = y0 + (h - y0) * f * f
            c.drawLine(0f, y, w, y, gridP)
        }

        // partikel
        for (i in 0 until n) {
            val fr = (t * ps[i] + po[i]) % 1f
            val x = px[i] * w + sin(t * 0.7f + i) * 12f * d
            val y = h - fr * h * 1.05f
            val a = (sin(PI.toFloat() * fr) * 230f).toInt().coerceIn(0, 255)
            val col = if (pk[i]) Fx.PINK else Fx.CYAN
            dotP.color = Fx.alpha(col, a / 4)
            c.drawCircle(x, y, pz[i] * d * 3f, dotP)
            dotP.color = Fx.alpha(col, a)
            c.drawCircle(x, y, pz[i] * d, dotP)
        }

        c.drawRect(0f, 0f, w, h, vignP)
        postInvalidateOnAnimation()
    }
}

/* ====================================================================== */
/*  ROBOT: mecha berpelindung visor, sirip V, inti reaktor, cincin HUD     */
/* ====================================================================== */
class RobotView(ctx: Context) : View(ctx) {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val gl = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val maskP = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    private val haloP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val coreP = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun poly(vararg v: Float): Path {
        val p = Path()
        p.moveTo(v[0], v[1])
        var i = 2
        while (i < v.size) { p.lineTo(v[i], v[i + 1]); i += 2 }
        p.close()
        return p
    }

    private fun pline(vararg v: Float): Path {
        val p = Path()
        p.moveTo(v[0], v[1])
        var i = 2
        while (i < v.size) { p.lineTo(v[i], v[i + 1]); i += 2 }
        return p
    }

    private fun circle(x: Float, y: Float, r: Float): Path {
        val p = Path()
        p.addCircle(x, y, r, Path.Direction.CW)
        return p
    }

    // ---- shader (koordinat lokal 300 x 310) ----
    private val armorS = LinearGradient(
        40f, 60f, 150f, 270f,
        intArrayOf(0xFFFFFFFF.toInt(), 0xFFCFDCF5.toInt(), 0xFF7F8FC4.toInt()),
        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
    )
    private val darkS = LinearGradient(0f, 120f, 0f, 200f, 0xFF3B4580.toInt(), 0xFF12163A.toInt(), Shader.TileMode.CLAMP)
    private val blueS = LinearGradient(40f, 190f, 120f, 230f, 0xFF5AA0FF.toInt(), 0xFF2A3BD8.toInt(), Shader.TileMode.CLAMP)
    private val finS = LinearGradient(
        130f, 68f, 70f, 4f,
        intArrayOf(0xFFFFFFFF.toInt(), 0xFF9EEFFF.toInt(), 0xFF25E8FF.toInt()),
        floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
    )
    private val crestS = LinearGradient(0f, 62f, 0f, 84f, 0xFFFF7AB8.toInt(), 0xFFD4146F.toInt(), Shader.TileMode.CLAMP)
    private val visorS = LinearGradient(0f, 90f, 0f, 124f, 0xFF0B1236.toInt(), 0xFF02030F.toInt(), Shader.TileMode.CLAMP)
    private val haloS = RadialGradient(
        150f, 130f, 150f,
        intArrayOf(0x8C25E8FF.toInt(), 0x2E4A5CFF, 0x004A5CFF),
        floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
    )
    private val coreS = RadialGradient(
        0f, 0f, 26f,
        intArrayOf(0xFFFFFFFF.toInt(), 0xFF7FF6FF.toInt(), 0x001AB8FF),
        floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP
    )
    private val fadeS = LinearGradient(0f, 225f, 0f, 285f, 0xFFFFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)

    // ---- bentuk setengah badan (dicerminkan) ----
    private val finA = poly(131f, 68f, 80f, 4f, 93f, 2f, 143f, 56f)
    private val finB = poly(123f, 72f, 66f, 38f, 72f, 30f, 131f, 62f)
    private val helmet = poly(150f, 60f, 128f, 63f, 111f, 78f, 106f, 112f, 110f, 138f, 124f, 160f, 150f, 168f)
    private val helmetEdge = pline(150f, 60f, 128f, 63f, 111f, 78f, 106f, 112f)
    private val fore = poly(150f, 70f, 130f, 72f, 120f, 84f, 150f, 90f)
    private val crest = poly(150f, 62f, 138f, 66f, 143f, 82f, 150f, 84f)
    private val cheek = poly(108f, 118f, 122f, 124f, 124f, 150f, 112f, 138f)
    private val vents = pline(113f, 128f, 120f, 131f).also {
        it.moveTo(114f, 134f); it.lineTo(121f, 137f)
        it.moveTo(115f, 140f); it.lineTo(121f, 143f)
    }
    private val chin = poly(150f, 132f, 128f, 134f, 132f, 156f, 150f, 164f)
    private val chinLines = pline(141f, 138f, 141f, 158f).also {
        it.moveTo(135f, 139f); it.lineTo(135f, 154f)
    }
    private val chinTop = pline(150f, 132f, 128f, 134f)
    private val neck = poly(150f, 168f, 136f, 166f, 134f, 194f, 150f, 196f)
    private val neckLines = pline(135f, 174f, 150f, 174f).also {
        it.moveTo(134.5f, 182f); it.lineTo(150f, 182f)
        it.moveTo(134f, 189f); it.lineTo(150f, 189f)
    }
    private val shoulder = poly(120f, 196f, 66f, 188f, 38f, 208f, 33f, 246f, 66f, 262f, 116f, 244f)
    private val shoulderEdge = pline(66f, 188f, 38f, 208f, 33f, 246f)
    private val shoulderBlue = poly(112f, 200f, 70f, 194f, 48f, 210f, 46f, 226f, 112f, 224f)
    private val shoulderGlow = pline(46f, 226f, 112f, 224f)
    private val shoulderLines = pline(48f, 238f, 108f, 236f).also {
        it.moveTo(62f, 250f); it.lineTo(112f, 240f)
    }
    private val pinkDot = circle(58f, 216f, 4f)
    private val chest = poly(126f, 198f, 150f, 202f, 150f, 270f, 118f, 266f, 108f, 236f)
    private val chestTop = pline(126f, 198f, 150f, 202f)
    private val chestLines = pline(122f, 212f, 150f, 216f).also {
        it.moveTo(116f, 238f); it.lineTo(150f, 242f)
    }

    // ---- wajah ----
    private val visor = poly(150f, 92f, 124f, 90f, 111f, 100f, 113f, 118f, 150f, 124f, 187f, 118f, 189f, 100f, 176f, 90f)
    private val eyeL = poly(146f, 103f, 127f, 99f, 118f, 106f, 123f, 112f, 146f, 113f)
    private val eyeR = poly(154f, 103f, 173f, 99f, 182f, 106f, 177f, 112f, 154f, 113f)
    private val eyeHiL = pline(144f, 104.5f, 128f, 101.5f, 121f, 106f)
    private val eyeHiR = pline(156f, 104.5f, 172f, 101.5f, 179f, 106f)
    private val visorBar = pline(126f, 86f, 174f, 86f)
    private val coreRing = circle(150f, 232f, 13f)
    private val coreTicks = pline(150f, 212f, 150f, 218f).also {
        it.moveTo(150f, 246f); it.lineTo(150f, 252f)
        it.moveTo(130f, 232f); it.lineTo(136f, 232f)
        it.moveTo(164f, 232f); it.lineTo(170f, 232f)
    }

    // ---- HUD ----
    private val ringDot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1f; color = Fx.alpha(Fx.CYAN, 90)
        pathEffect = DashPathEffect(floatArrayOf(2f, 7f), 0f)
    }
    private val ringMain = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f; color = Fx.CYAN; strokeCap = Paint.Cap.ROUND
        pathEffect = DashPathEffect(floatArrayOf(38f, 14f, 6f, 14f), 0f)
    }
    private val ringMainGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 7f; color = Fx.alpha(Fx.CYAN, 40); strokeCap = Paint.Cap.ROUND
        pathEffect = DashPathEffect(floatArrayOf(38f, 14f, 6f, 14f), 0f)
    }
    private val ringPurple = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.4f; color = Fx.alpha(Fx.VIOLET, 230)
        pathEffect = DashPathEffect(floatArrayOf(3f, 5f), 0f)
    }
    private val arcP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.4f; color = Fx.alpha(Color.WHITE, 215); strokeCap = Paint.Cap.ROUND
    }
    private val arcGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 8f; color = Fx.alpha(Fx.CYAN, 50); strokeCap = Paint.Cap.ROUND
    }
    private val tickP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.2f; color = Fx.alpha(Fx.CYAN, 140)
    }
    private val arcRect = RectF(22f, 2f, 278f, 258f)
    private val wedge = Path().apply {
        moveTo(150f, 130f); lineTo(150f, 16f)
        arcTo(RectF(36f, 16f, 264f, 244f), -90f, 40f)
        close()
    }
    private val triTop = poly(150f, 14f, 156f, 24f, 144f, 24f)
    private val triBot = poly(150f, 246f, 156f, 236f, 144f, 236f)
    private val ticks = floatArrayOf(
        150f, -2f, 150f, 6f, 150f, 254f, 150f, 262f, 18f, 130f, 26f, 130f, 274f, 130f, 282f, 130f,
        56f, 36f, 61f, 41f, 244f, 36f, 239f, 41f, 56f, 224f, 61f, 219f, 244f, 224f, 239f, 219f
    )
    private val holoA = poly(0f, 0f, 46f, 0f, 54f, 8f, 54f, 44f, 8f, 44f, 0f, 36f)
    private val holoALines = pline(8f, 12f, 40f, 12f).also {
        it.moveTo(8f, 20f); it.lineTo(30f, 20f)
        it.moveTo(8f, 28f); it.lineTo(36f, 28f)
    }
    private val holoB = poly(8f, 0f, 54f, 0f, 54f, 36f, 46f, 44f, 0f, 44f, 0f, 8f)
    private val holoBChart = pline(10f, 34f, 18f, 24f, 25f, 29f, 34f, 14f, 44f, 20f)

    // ---- helper gambar ----
    private fun solid(c: Canvas, p: Path, color: Int) {
        fill.shader = null; fill.color = color; c.drawPath(p, fill)
    }

    private fun shaded(c: Canvas, p: Path, s: Shader) {
        fill.shader = s; fill.color = Color.WHITE; c.drawPath(p, fill)
    }

    private fun line(c: Canvas, p: Path, color: Int, w: Float) {
        ln.color = color; ln.strokeWidth = w; c.drawPath(p, ln)
    }

    private fun glowLine(c: Canvas, p: Path, color: Int, w: Float, k: Float = 1f) {
        gl.color = color
        gl.strokeWidth = w * 5f; gl.alpha = (30 * k).toInt(); c.drawPath(p, gl)
        gl.strokeWidth = w * 2.6f; gl.alpha = (70 * k).toInt(); c.drawPath(p, gl)
        gl.strokeWidth = w; gl.alpha = (255 * k).toInt().coerceIn(0, 255); c.drawPath(p, gl)
    }

    private fun glowFill(c: Canvas, p: Path, color: Int, k: Float = 1f) {
        gl.color = color
        gl.strokeWidth = 7f; gl.alpha = (30 * k).toInt(); c.drawPath(p, gl)
        gl.strokeWidth = 3.5f; gl.alpha = (70 * k).toInt(); c.drawPath(p, gl)
        fill.shader = null; fill.color = color; fill.alpha = (255 * k).toInt().coerceIn(0, 255)
        c.drawPath(p, fill)
    }

    private fun drawHalf(c: Canvas) {
        shaded(c, finA, finS); glowLine(c, finA, Fx.CYAN, 1f, 0.45f)
        shaded(c, finB, finS)
        shaded(c, helmet, armorS)
        line(c, helmetEdge, Fx.alpha(Color.WHITE, 230), 1.2f)
        shaded(c, fore, blueS)
        shaded(c, crest, crestS); glowLine(c, crest, Fx.PINK, 1f, 0.5f)
        shaded(c, cheek, darkS)
        line(c, vents, Fx.alpha(Fx.CYAN, 230), 1.4f)
        shaded(c, chin, darkS)
        line(c, chinLines, Fx.alpha(Fx.CYAN, 165), 1.3f)
        line(c, chinTop, Fx.alpha(Color.WHITE, 150), 1f)
        shaded(c, neck, darkS)
        line(c, neckLines, Fx.alpha(Fx.CYAN, 128), 1f)
        shaded(c, shoulder, armorS)
        line(c, shoulderEdge, Fx.alpha(Color.WHITE, 230), 1.2f)
        shaded(c, shoulderBlue, blueS)
        glowLine(c, shoulderGlow, Fx.CYAN, 1.8f)
        line(c, shoulderLines, Fx.alpha(0xFF7F8FC4.toInt(), 200), 1.2f)
        glowFill(c, pinkDot, Fx.PINK)
        shaded(c, chest, armorS)
        line(c, chestTop, Fx.alpha(Color.WHITE, 230), 1.2f)
        line(c, chestLines, Fx.alpha(Fx.CYAN, 190), 1.3f)
    }

    private fun ring(c: Canvas, r: Float, p: Paint, angle: Float) {
        c.save()
        c.rotate(angle, 150f, 130f)
        c.drawCircle(150f, 130f, r, p)
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        val t = Fx.time()
        val s = min(width / 300f, height / 310f)
        c.save()
        c.translate((width - 300f * s) / 2f, (height - 310f * s) / 2f)
        c.scale(s, s)

        // halo
        haloP.shader = haloS
        haloP.alpha = (215 + 40 * sin(t * 2.2f)).toInt().coerceIn(0, 255)
        c.drawCircle(150f, 130f, 150f, haloP)

        // cincin HUD
        ring(c, 140f, ringDot, t * 13f)
        ring(c, 128f, ringMainGlow, t * 12.8f)
        ring(c, 128f, ringMain, t * 12.8f)
        ring(c, 114f, ringPurple, -t * 20f)
        c.save()
        c.rotate(-t * 20f, 150f, 130f)
        solid(c, triTop, Fx.PINK)
        solid(c, triBot, Fx.PINK)
        c.restore()
        c.save()
        c.rotate(-t * 40f, 150f, 130f)
        c.drawArc(arcRect, -90f, 80f, false, arcGlow)
        c.drawArc(arcRect, -90f, 80f, false, arcP)
        c.restore()
        c.save()
        c.rotate(t * 106f, 150f, 130f)
        solid(c, wedge, Fx.alpha(Fx.CYAN, 24))
        c.restore()
        c.drawLines(ticks, tickP)

        // panel holo melayang
        val hk = 0.5f + 0.5f * sin(t * 1.65f)
        c.save()
        c.translate(6f, 86f - 5f * hk)
        solid(c, holoA, Fx.alpha(Fx.CYAN, 26))
        glowLine(c, holoA, Fx.CYAN, 1f, 0.55f + 0.45f * hk)
        line(c, holoALines, Fx.alpha(Fx.CYAN, 200), 1.6f)
        solid(c, circle(44f, 30f, 2.2f), Fx.GREEN)
        c.restore()
        val hk2 = 0.5f + 0.5f * sin(t * 1.65f + PI.toFloat())
        c.save()
        c.translate(238f, 70f - 5f * hk2)
        solid(c, holoB, Fx.alpha(Fx.PINK, 26))
        glowLine(c, holoB, Fx.PINK, 1f, 0.55f + 0.45f * hk2)
        line(c, holoBChart, 0xFFFF7AB8.toInt(), 1.8f)
        solid(c, circle(44f, 20f, 2.2f), Color.WHITE)
        c.restore()

        // ===== badan =====
        c.save()
        c.translate(0f, -4f * sin(t * 1.37f))
        c.rotate(1.2f * sin(t * 0.9f), 150f, 170f)
        val layer = c.saveLayer(0f, -20f, 300f, 310f, null)

        drawHalf(c)
        c.save()
        c.scale(-1f, 1f, 150f, 0f)
        drawHalf(c)
        c.restore()

        // visor
        shaded(c, visor, visorS)
        line(c, visor, Fx.alpha(Fx.CYAN, 180), 1f)
        glowLine(c, visorBar, Fx.CYAN, 1.6f, 0.9f)

        c.save()
        c.clipPath(visor)
        val glance = 1.6f * sin(t * 0.6f)
        c.translate(glance, 0f)
        val pulse = 0.85f + 0.15f * sin(t * 2.6f)
        glowFill(c, eyeL, 0xFF7FF6FF.toInt(), pulse)
        glowFill(c, eyeR, 0xFF7FF6FF.toInt(), pulse)
        line(c, eyeHiL, Color.WHITE, 1.6f)
        line(c, eyeHiR, Color.WHITE, 1.6f)
        c.translate(-glance, 0f)
        // kedip
        val bp = t % 5.5f
        if (bp > 5.2f) {
            val q = (bp - 5.2f) / 0.3f
            val lid = 1f - abs(2f * q - 1f)
            fill.shader = null; fill.color = 0xFF02030F.toInt()
            c.drawRect(108f, 107f - 14f * lid, 192f, 107f + 14f * lid, fill)
        }
        // scan visor
        val sp = (t % 3.2f) / 3.2f
        fill.shader = null
        fill.color = Fx.alpha(Fx.CYAN, (230 * sin(PI.toFloat() * sp)).toInt().coerceIn(0, 255))
        val sy = 90f + 34f * sp
        c.drawRect(108f, sy, 192f, sy + 2.4f, fill)
        c.restore()

        // inti reaktor di dada
        c.save()
        val cp = 1f + 0.18f * (0.5f + 0.5f * sin(t * 3.5f))
        c.translate(150f, 232f)
        c.scale(cp, cp)
        coreP.shader = coreS
        c.drawCircle(0f, 0f, 26f, coreP)
        c.restore()
        solid(c, coreRing, 0xFF0A1030.toInt())
        glowLine(c, coreRing, Fx.CYAN, 2f)
        line(c, coreTicks, Fx.CYAN, 1.6f)
        fill.shader = null
        fill.color = Fx.alpha(Color.WHITE, 40); c.drawCircle(150f, 232f, 10f, fill)
        fill.color = Fx.alpha(Color.WHITE, 110); c.drawCircle(150f, 232f, 8f, fill)
        fill.color = Color.WHITE; c.drawCircle(150f, 232f, 6f, fill)

        // pudar di bawah
        maskP.shader = fadeS
        c.drawRect(0f, -20f, 300f, 310f, maskP)
        c.restoreToCount(layer)
        c.restore()

        c.restore()
        postInvalidateOnAnimation()
    }
}

/* ====================================================================== */
/*  CARD HUD: sudut dipotong, border gradien berputar, kaca gelap          */
/* ====================================================================== */
class HudCard(ctx: Context) : LinearLayout(ctx) {
    private val d = resources.displayMetrics.density
    private val cut = 16f * d
    private val path = Path()
    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d }
    private val borderGlowP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f * d; alpha = 45
    }
    private var sweep: SweepGradient? = null
    private val m = Matrix()

    init {
        orientation = VERTICAL
        setWillNotDraw(false)
        val p = (18 * d).toInt()
        setPadding(p, p, p, p)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val i = 0.75f * d
        val wf = w.toFloat()
        val hf = h.toFloat()
        path.reset()
        path.moveTo(cut, i)
        path.lineTo(wf - i, i)
        path.lineTo(wf - i, hf - cut)
        path.lineTo(wf - cut, hf - i)
        path.lineTo(i, hf - i)
        path.lineTo(i, cut)
        path.close()
        bgP.shader = LinearGradient(0f, 0f, wf, hf, 0xF2171B47.toInt(), 0xF2070920.toInt(), Shader.TileMode.CLAMP)
        glowP.shader = RadialGradient(0f, 0f, wf * 0.8f, 0x2625E8FF, 0x0025E8FF, Shader.TileMode.CLAMP)
        sweep = SweepGradient(
            wf / 2f, hf / 2f,
            intArrayOf(Fx.CYAN, 0x558A5CFF, Fx.PINK, 0x558A5CFF, Fx.CYAN),
            floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f)
        )
    }

    override fun onDraw(c: Canvas) {
        c.drawPath(path, bgP)
        c.save()
        c.clipPath(path)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), glowP)
        c.restore()
        val sg = sweep
        if (sg != null) {
            m.setRotate((Fx.time() * 51f) % 360f, width / 2f, height / 2f)
            sg.setLocalMatrix(m)
            borderP.shader = sg
            borderGlowP.shader = sg
            borderGlowP.alpha = 45
            c.drawPath(path, borderGlowP)
            c.drawPath(path, borderP)
        }
        super.onDraw(c)
        postInvalidateOnAnimation()
    }
}

/* ====================================================================== */
/*  TOMBOL: gradien mengalir + kilatan + denyut (primary) / outline neon   */
/* ====================================================================== */
class GlowButton(ctx: Context, private val label: String, iconRes: Int, private val kind: Int) : View(ctx) {
    companion object {
        const val PRIMARY = 0
        const val CYAN = 1
        const val PINK = 2
    }

    private val d = resources.displayMetrics.density
    private val pad = 8f * d
    private val rad = (if (kind == PRIMARY) 20f else 16f) * d
    private val icon: Drawable? = ctx.getDrawable(iconRes)?.mutate()
    private val accent = if (kind == PINK) Fx.PINK else Fx.CYAN
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        letterSpacing = 0.12f
        textSize = Fx.sp(ctx, if (kind == PRIMARY) 15f else 12.5f)
        color = if (kind == PRIMARY) Color.WHITE else accent
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val shinePath = Path()
    private val clipP = Path()
    private val rect = RectF()
    private val m = Matrix()
    private var grad: LinearGradient? = null

    init { isClickable = true }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        rect.set(pad, pad, w - pad, h - pad)
        clipP.reset()
        clipP.addRoundRect(rect, rad, rad, Path.Direction.CW)
        grad = LinearGradient(
            0f, 0f, w * 1.5f, 0f,
            intArrayOf(0xFF6A4DFF.toInt(), 0xFF25A8FF.toInt(), 0xFF25E8FF.toInt(), 0xFF8A5CFF.toInt(), 0xFF6A4DFF.toInt()),
            null, Shader.TileMode.MIRROR
        )
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = Fx.time()

        if (kind == PRIMARY) {
            // glow luar
            strokeP.shader = null
            strokeP.color = Fx.alpha(Fx.CYAN, 22); strokeP.strokeWidth = 12f * d
            c.drawRoundRect(rect, rad, rad, strokeP)
            strokeP.color = Fx.alpha(Fx.CYAN, 40); strokeP.strokeWidth = 6f * d
            c.drawRoundRect(rect, rad, rad, strokeP)
            // gradien mengalir
            val g = grad
            if (g != null) {
                m.setTranslate(((t * 0.16f) % 1f) * w * 3f, 0f)
                g.setLocalMatrix(m)
                fillP.shader = g
                c.drawRoundRect(rect, rad, rad, fillP)
            }
            // kilatan
            val p = (t % 3.2f) / 3.2f
            if (p < 0.55f) {
                val x = -60f * d + (p / 0.55f) * (w + 120f * d)
                shinePath.reset()
                shinePath.moveTo(x + 20f * d, 0f)
                shinePath.lineTo(x + 70f * d, 0f)
                shinePath.lineTo(x + 50f * d, h)
                shinePath.lineTo(x, h)
                shinePath.close()
                c.save()
                c.clipPath(clipP)
                fillP.shader = null
                fillP.color = Fx.alpha(Color.WHITE, 85)
                c.drawPath(shinePath, fillP)
                c.restore()
            }
            // rim terang
            strokeP.color = Fx.alpha(Color.WHITE, 70); strokeP.strokeWidth = d
            c.drawRoundRect(rect, rad, rad, strokeP)
            // ring denyut
            val q = (t % 2.2f) / 2.2f
            val grow = q * pad
            strokeP.color = Fx.alpha(Fx.CYAN, ((1f - q) * 200f).toInt().coerceIn(0, 255))
            strokeP.strokeWidth = 2f * d
            c.drawRoundRect(
                rect.left - grow, rect.top - grow, rect.right + grow, rect.bottom + grow,
                rad + grow, rad + grow, strokeP
            )
        } else {
            fillP.shader = null
            fillP.color = Fx.alpha(accent, 36)
            c.drawRoundRect(rect, rad, rad, fillP)
            strokeP.shader = null
            strokeP.color = Fx.alpha(accent, 40); strokeP.strokeWidth = 6f * d
            c.drawRoundRect(rect, rad, rad, strokeP)
            strokeP.color = Fx.alpha(accent, 210); strokeP.strokeWidth = 1.2f * d
            c.drawRoundRect(rect, rad, rad, strokeP)
        }

        // ikon + teks di tengah
        val iconSize = 20f * d
        val gap = 10f * d
        val tw = txt.measureText(label)
        val total = iconSize + gap + tw
        val sx = (w - total) / 2f
        val cy = h / 2f
        val ic = icon
        if (ic != null) {
            ic.setBounds(sx.toInt(), (cy - iconSize / 2f).toInt(), (sx + iconSize).toInt(), (cy + iconSize / 2f).toInt())
            ic.setTint(if (kind == PRIMARY) Color.WHITE else accent)
            ic.draw(c)
        }
        c.drawText(label, sx + iconSize + gap, cy - (txt.descent() + txt.ascent()) / 2f, txt)

        if (kind == PRIMARY) postInvalidateOnAnimation()
    }
}

/* ====================================================================== */
/*  JUDUL: gradien berkilau + glitch sesekali                              */
/* ====================================================================== */
class ShimmerTitle(ctx: Context) : TextView(ctx) {
    private var shader: LinearGradient? = null
    private val m = Matrix()

    init {
        text = "AI PITO"
        textSize = 42f
        typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        letterSpacing = 0.14f
        gravity = android.view.Gravity.CENTER
        setTextColor(Color.WHITE)
        setShadowLayer(14f * resources.displayMetrics.density, 0f, 0f, 0x8825E8FF.toInt())
        includeFontPadding = false
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        shader = LinearGradient(
            0f, 0f, w.toFloat(), 0f,
            intArrayOf(0xFF9B6BFF.toInt(), Fx.CYAN, Color.WHITE, Fx.PINK, 0xFF9B6BFF.toInt()),
            null, Shader.TileMode.REPEAT
        )
    }

    override fun onDraw(c: Canvas) {
        val sh = shader
        if (sh != null) {
            m.setTranslate(((Fx.time() * 0.2f) % 1f) * width, 0f)
            sh.setLocalMatrix(m)
            paint.shader = sh
        }
        val ph = (Fx.time() % 6f)
        if (ph < 0.14f) {
            val off = 4f * resources.displayMetrics.density
            c.save()
            c.clipRect(0f, 0f, width.toFloat(), height * 0.5f)
            c.translate(-off, 0f)
            super.onDraw(c)
            c.restore()
            c.save()
            c.clipRect(0f, height * 0.5f, width.toFloat(), height.toFloat())
            c.translate(off, 0f)
            super.onDraw(c)
            c.restore()
        } else {
            super.onDraw(c)
        }
        postInvalidateOnAnimation()
    }
}
