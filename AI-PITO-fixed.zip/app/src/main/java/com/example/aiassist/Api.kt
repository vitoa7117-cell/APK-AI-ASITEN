package com.example.aiassist

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Dukung banyak penyedia sekaligus. Di kolom API key boleh isi BEBERAPA key,
 * dipisah koma. Penyedia dikenali otomatis dari awalan key:
 *  - "sk-ant..." -> Anthropic (Claude, berbayar)
 *  - "gsk_..."   -> Groq (Llama, ada jatah gratis)
 *  - "sk-or-..." -> OpenRouter (model berlabel :free)
 *  - selain itu  -> Google Gemini (ada jatah gratis)
 *
 * Key dicoba berurutan sesuai urutan penulisan. Kalau satu kena limit (429),
 * error server (5xx), atau gagal koneksi, otomatis pindah ke key berikutnya.
 * Riwayat chat disimpan dalam format Anthropic, lalu diubah ke format tiap penyedia saat kirim.
 */
object Api {
    private const val SYSTEM =
        "Kamu asisten AI serbaguna di HP bernama AI PITO. Jawab pertanyaan apa pun dan bantu coding. " +
        "Kalau ada gambar/screenshot, baca isinya lalu jawab atau selesaikan. " +
        "Balas dalam bahasa yang dipakai pengguna. Jawaban jelas dan tidak bertele-tele. " +
        "Tulis tanpa format markdown berat karena tampil sebagai teks biasa."

    // Nama model sering berubah. Kalau ada yang tidak ditemukan, cukup ganti daftar ini.
    private val GEMINI_MODELS = listOf("gemini-2.5-flash", "gemini-3.5-flash", "gemini-2.5-flash-lite")
    private const val CLAUDE_DEFAULT = "claude-sonnet-5-5"
    private val GROQ_TEXT = listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant")
    private val GROQ_VISION = listOf("meta-llama/llama-4-scout-17b-16e-instruct")
    private val OPENROUTER_TEXT = listOf("meta-llama/llama-3.3-70b-instruct:free", "google/gemma-3-27b-it:free")
    private val OPENROUTER_VISION = listOf("google/gemma-3-27b-it:free")

    // key yang barusan kena limit dilewati dulu selama beberapa saat
    private val cooldown = ConcurrentHashMap<String, Long>()
    private const val COOLDOWN_MS = 60_000L

    private class ApiError(val code: Int, message: String) : Exception(message)

    fun toBase64(src: Bitmap, max: Int = 1568, quality: Int = 85): String {
        val scale = minOf(1f, max.toFloat() / maxOf(src.width, src.height))
        val bmp = if (scale < 1f)
            Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
        else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /** Ubah permintaan gambar (bahasa apa pun) jadi prompt Inggris yang detail supaya hasilnya bagus. */
    fun imagePrompt(ctx: Context, request: String): String {
        val msgs = JSONArray().put(
            JSONObject().put("role", "user").put(
                "content",
                "Ubah permintaan gambar berikut menjadi SATU prompt bahasa Inggris untuk generator gambar AI (FLUX). " +
                    "Jelaskan subjek, suasana, pencahayaan, sudut kamera, dan gaya (misalnya photorealistic, cinematic lighting, " +
                    "highly detailed, sharp focus) supaya hasilnya bagus. Maksimal 80 kata. " +
                    "Balas HANYA dengan prompt-nya, tanpa tanda kutip atau penjelasan.\n\nPermintaan: $request"
            )
        )
        val r = chat(ctx, msgs).trim().trim('"')
        return if (r.isBlank() || r.length > 1200) request else r
    }

    private fun parseKeys(raw: String): List<String> =
        raw.split(Regex("[,;\\s]+")).map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("cf=") && !it.startsWith("cobalt=") && !it.startsWith("cobaltkey=") && !it.startsWith("voice=") }.distinct()

    private fun providerOf(key: String): String = when {
        key.startsWith("sk-ant") -> "Claude"
        key.startsWith("gsk_") -> "Groq"
        key.startsWith("sk-or-") -> "OpenRouter"
        else -> "Gemini"
    }

    private fun hasImage(messages: JSONArray): Boolean {
        for (i in 0 until messages.length()) {
            val c = messages.getJSONObject(i).opt("content")
            if (c is JSONArray) {
                for (j in 0 until c.length()) {
                    if (c.getJSONObject(j).optString("type") == "image") return true
                }
            }
        }
        return false
    }

    private const val QUICK_SYSTEM =
        "Kamu AI PITO. Pengguna men-scan sebagian layar HP-nya. Teks bisa berasal dari OCR sehingga mungkin ada typo atau sisa tampilan aplikasi, abaikan yang tidak relevan. " +
        "Kalau isinya soal pilihan ganda: tulis opsi yang benar (huruf dan isinya) lalu alasan maksimal 1 kalimat. " +
        "Kalau soal isian atau hitungan: langsung beri jawaban akhir dengan langkah sangat singkat. " +
        "Kalau bukan soal: jelaskan atau ringkas isinya maksimal 3 kalimat. " +
        "Pakai bahasa pengguna, tanpa pembuka dan penutup, tanpa format markdown."

    /** Jawab cepat dan hemat token: tanpa riwayat chat, jawaban pendek. Teks (hasil OCR) lebih murah daripada gambar. */
    fun quick(ctx: Context, text: String, img: Bitmap?): String {
        val content = JSONArray()
        if (img != null) {
            content.put(
                JSONObject().put("type", "image").put(
                    "source", JSONObject().put("type", "base64").put("media_type", "image/jpeg")
                        .put("data", toBase64(img, 900, 70))
                )
            )
            content.put(JSONObject().put("type", "text").put("text", "Jawab sesuai isi gambar ini."))
        } else {
            content.put(JSONObject().put("type", "text").put("text", text.take(3000)))
        }
        val msgs = JSONArray().put(JSONObject().put("role", "user").put("content", content))
        return chat(ctx, msgs, QUICK_SYSTEM, 500)
    }

    fun chat(ctx: Context, messages: JSONArray, system: String = SYSTEM, maxTokens: Int = 4096): String {
        val keys = parseKeys(Prefs.apiKey(ctx))
        if (keys.isEmpty()) throw Exception("API key belum diisi.")

        val image = hasImage(messages)
        val now = System.currentTimeMillis()
        // key yang sedang cooldown dicoba paling akhir
        val ready = keys.filter { (cooldown[it] ?: 0L) <= now }
        val order = ready + keys.filter { it !in ready }

        val errors = mutableListOf<String>()
        for (key in order) {
            val name = providerOf(key)
            try {
                return when (name) {
                    "Claude" -> anthropic(ctx, key, messages, system, maxTokens)
                    "Groq" -> openAiCompat(
                        "https://api.groq.com/openai/v1/chat/completions",
                        key, modelsFor("Groq", key, image), messages, system, maxTokens
                    )
                    "OpenRouter" -> openAiCompat(
                        "https://openrouter.ai/api/v1/chat/completions",
                        key, modelsFor("OpenRouter", key, image), messages, system, maxTokens
                    )
                    else -> gemini(ctx, key, messages, system)
                }
            } catch (e: ApiError) {
                if (e.code == 429 || e.code >= 500) cooldown[key] = System.currentTimeMillis() + COOLDOWN_MS
                val hint = if (name == "Gemini" && key.startsWith("AQ.") && e.code == 401)
                    " (Key berawalan AQ. dari AI Studio memang sering ditolak API Gemini. Andalkan Groq/OpenRouter.)"
                else ""
                errors.add("$name: ${e.message}$hint")
            } catch (e: Exception) {
                // gagal koneksi / jawaban kosong -> coba key berikutnya
                errors.add("$name: ${e.message ?: e.toString()}")
            }
        }
        throw Exception(
            if (errors.size == 1) errors[0]
            else "Semua API key gagal dipakai:\n" + errors.joinToString("\n")
        )
    }

    // ---------- Daftar model otomatis (nama model sering berubah) ----------
    private val modelCache = ConcurrentHashMap<String, Pair<Long, List<String>>>()
    private const val MODEL_CACHE_MS = 6 * 60 * 60 * 1000L

    private fun httpGet(url: String, headers: Map<String, String>): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return code to text
    }

    private fun rank(ids: List<String>, prefs: List<String>): List<String> =
        ids.sortedBy { id ->
            val i = prefs.indexOfFirst { p -> id.contains(p, ignoreCase = true) }
            if (i < 0) prefs.size else i
        }.take(4)

    private fun modelsFor(provider: String, key: String, image: Boolean): List<String> {
        val cacheKey = "$provider:$image:${key.takeLast(8)}"
        val now = System.currentTimeMillis()
        val cached = modelCache[cacheKey]
        if (cached != null && now - cached.first < MODEL_CACHE_MS && cached.second.isNotEmpty()) return cached.second
        val found = runCatching {
            if (provider == "Groq") discoverGroq(key, image) else discoverOpenRouter(key, image)
        }.getOrDefault(emptyList())
        if (found.isNotEmpty()) {
            modelCache[cacheKey] = now to found
            return found
        }
        return if (provider == "Groq") (if (image) GROQ_VISION else GROQ_TEXT)
        else (if (image) OPENROUTER_VISION else OPENROUTER_TEXT)
    }

    private fun discoverGroq(key: String, image: Boolean): List<String> {
        val (code, text) = httpGet("https://api.groq.com/openai/v1/models", mapOf("Authorization" to "Bearer $key"))
        if (code !in 200..299) return emptyList()
        val arr = JSONObject(text).optJSONArray("data") ?: return emptyList()
        val skip = listOf("whisper", "tts", "guard", "embed", "playai", "orpheus", "safeguard", "compound")
        val ids = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("id")
            if (id.isBlank() || !o.optBoolean("active", true)) continue
            if (skip.any { w -> id.contains(w, ignoreCase = true) }) continue
            ids.add(id)
        }
        return if (image) {
            val vis = ids.filter { id -> listOf("scout", "maverick", "vision").any { w -> id.contains(w, ignoreCase = true) } }
            rank(vis, listOf("maverick", "scout", "vision"))
        } else {
            rank(ids, listOf("llama-3.3-70b", "gpt-oss-120b", "maverick", "qwen", "kimi", "llama-3.1-8b", "gpt-oss-20b", "scout"))
        }
    }

    private fun discoverOpenRouter(key: String, image: Boolean): List<String> {
        val (code, text) = httpGet("https://openrouter.ai/api/v1/models", mapOf("Authorization" to "Bearer $key"))
        if (code !in 200..299) return emptyList()
        val arr = JSONObject(text).optJSONArray("data") ?: return emptyList()
        val ids = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("id")
            if (id.isBlank()) continue
            val pricing = o.optJSONObject("pricing")
            val free = id.endsWith(":free") ||
                (pricing != null && pricing.optString("prompt") == "0" && pricing.optString("completion") == "0")
            if (!free) continue
            val arch = o.optJSONObject("architecture")
            val inputs = arch?.optJSONArray("input_modalities")
            val outputs = arch?.optJSONArray("output_modalities")
            fun has(a: JSONArray?, what: String): Boolean {
                if (a == null) return false
                for (j in 0 until a.length()) if (a.optString(j) == what) return true
                return false
            }
            if (outputs != null && !has(outputs, "text")) continue
            if (image && !has(inputs, "image")) continue
            if (id.contains("embed", ignoreCase = true)) continue
            ids.add(id)
        }
        return rank(ids, listOf("llama-3.3-70b", "gpt-oss-120b", "qwen", "gemma", "deepseek", "mistral", "llama"))
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 30000
        conn.readTimeout = 180000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return code to text
    }

    private fun errMsg(code: Int, text: String): String {
        val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
            .getOrDefault(text.take(300))
        return when (code) {
            429 -> "Jatah habis / terlalu cepat (HTTP 429). $msg"
            401, 403 -> "API key ditolak (HTTP $code). Cek lagi key-nya. $msg"
            400 -> "HTTP 400: $msg"
            else -> "HTTP $code: $msg"
        }
    }

    // ---------- Anthropic ----------
    private fun anthropic(ctx: Context, key: String, messages: JSONArray, system: String, maxTokens: Int): String {
        var model = Prefs.model(ctx)
        if (!model.startsWith("claude")) model = CLAUDE_DEFAULT
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", maxTokens)
            .put("system", system)
            .put("messages", messages)
        val (code, text) = post(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"),
            body
        )
        if (code !in 200..299) throw ApiError(code, errMsg(code, text))
        val arr = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.getString("text"))
        }
        return sb.toString().trim()
    }

    // ---------- Gemini ----------
    private fun toGemini(messages: JSONArray): JSONArray {
        val out = JSONArray()
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            val role = if (m.getString("role") == "assistant") "model" else "user"
            val parts = JSONArray()
            val c = m.opt("content")
            if (c is JSONArray) {
                for (j in 0 until c.length()) {
                    val b = c.getJSONObject(j)
                    when (b.optString("type")) {
                        "image" -> parts.put(
                            JSONObject().put(
                                "inline_data", JSONObject()
                                    .put("mime_type", "image/jpeg")
                                    .put("data", b.getJSONObject("source").getString("data"))
                            )
                        )
                        "text" -> parts.put(JSONObject().put("text", b.getString("text")))
                    }
                }
            } else {
                parts.put(JSONObject().put("text", c?.toString() ?: ""))
            }
            out.put(JSONObject().put("role", role).put("parts", parts))
        }
        return out
    }

    private fun gemini(ctx: Context, key: String, messages: JSONArray, system: String): String {
        var model = Prefs.model(ctx)
        if (!model.startsWith("gemini")) model = GEMINI_MODELS[0]

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", toGemini(messages))

        val candidates = LinkedHashSet<String>()
        candidates.add(model)
        candidates.addAll(GEMINI_MODELS)

        var last = ApiError(0, "Gagal menghubungi Gemini")
        for (m in candidates) {
            val (code, text) = post(
                "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                mapOf("x-goog-api-key" to key),
                body
            )
            if (code in 200..299) return parseGemini(text)
            last = ApiError(code, errMsg(code, text))
            // Jatah Gemini dihitung per model, jadi model lain masih bisa jalan
            // kalau modelnya tidak ada (404), kena limit (429), atau server sibuk (5xx).
            if (code != 404 && code != 429 && code < 500) break
        }
        throw last
    }

    private fun parseGemini(text: String): String {
        val root = JSONObject(text)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
            throw Exception("Gemini tidak memberi jawaban. $reason".trim())
        }
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw Exception("Jawaban kosong dari Gemini")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        val r = sb.toString().trim()
        if (r.isEmpty()) throw Exception("Jawaban kosong dari Gemini")
        return r
    }

    // ---------- Groq & OpenRouter (format OpenAI) ----------
    private fun toOpenAi(messages: JSONArray, system: String): JSONArray {
        val out = JSONArray()
        out.put(JSONObject().put("role", "system").put("content", system))
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            val role = m.getString("role")
            val c = m.opt("content")
            if (c is JSONArray) {
                val parts = JSONArray()
                var images = 0
                val texts = StringBuilder()
                for (j in 0 until c.length()) {
                    val b = c.getJSONObject(j)
                    when (b.optString("type")) {
                        "image" -> {
                            images++
                            val data = b.getJSONObject("source").getString("data")
                            parts.put(
                                JSONObject().put("type", "image_url").put(
                                    "image_url", JSONObject().put("url", "data:image/jpeg;base64,$data")
                                )
                            )
                        }
                        "text" -> {
                            texts.append(b.getString("text"))
                            parts.put(JSONObject().put("type", "text").put("text", b.getString("text")))
                        }
                    }
                }
                // tanpa gambar, kirim teks biasa supaya cocok dengan model teks saja
                out.put(JSONObject().put("role", role).put("content", if (images == 0) texts.toString() else parts))
            } else {
                out.put(JSONObject().put("role", role).put("content", c?.toString() ?: ""))
            }
        }
        return out
    }

    private fun openAiCompat(url: String, key: String, models: List<String>, messages: JSONArray, system: String, maxTokens: Int): String {
        val msgs = toOpenAi(messages, system)
        var last = ApiError(0, "Gagal menghubungi server")
        for (m in models) {
            val body = JSONObject().put("model", m).put("messages", msgs).put("max_tokens", maxTokens)
            val (code, text) = post(url, mapOf("Authorization" to "Bearer $key"), body)
            if (code in 200..299) {
                val choices = JSONObject(text).optJSONArray("choices")
                val reply = choices?.optJSONObject(0)?.optJSONObject("message")?.optString("content", "")?.trim() ?: ""
                if (reply.isNotEmpty()) return reply
                last = ApiError(code, "Jawaban kosong dari $m")
                continue
            }
            last = ApiError(code, errMsg(code, text))
            // key ditolak (401/403) -> model lain pun pasti ditolak, berhenti di sini
            if (code != 400 && code != 404 && code != 429 && code < 500) break
        }
        throw last
    }
}
