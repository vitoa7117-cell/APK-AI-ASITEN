# AI PITO

Asisten AI melayang (bubble di pinggir layar) + scan layar + scan kamera.

## Build APK lewat GitHub
1. Upload semua isi folder ini ke repo GitHub (pastikan folder `.github` ikut).
2. Buka tab **Actions** -> workflow **Build APK** -> tunggu hijau (3-6 menit).
3. Klik run-nya, scroll ke **Artifacts**, download `AiAssist-APK`, extract, install `app-debug.apk`.

## Tampilan
Intro animasi robot, bubble melayang, panel chat dengan efek mengetik.

## Pakai
Buka app, isi API key (console.anthropic.com), Simpan, Aktifkan bubble.
