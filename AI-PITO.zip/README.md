# AI PITO

Asisten AI melayang (bubble di pinggir layar) + scan layar + scan kamera.

## Build APK lewat GitHub
1. Upload semua isi folder ini ke repo GitHub (pastikan folder `.github` ikut).
2. Buka tab **Actions** -> workflow **Build APK** -> tunggu hijau (3-6 menit).
3. Klik run-nya, scroll ke **Artifacts**, download `AI-PITO-APK`, extract, install `app-debug.apk`.

## Tampilan
Intro animasi robot, bubble melayang, panel chat dengan efek mengetik.

## Pakai
Buka app, isi API key, Simpan, Aktifkan bubble.

Kolom API key boleh diisi BANYAK key sekaligus, dipisah koma. Penyedia dikenali dari awalan key:
- `AIza...`  -> Google Gemini (aistudio.google.com, ada jatah gratis)
- `gsk_...`  -> Groq (console.groq.com, Llama, ada jatah gratis)
- `sk-or-...` -> OpenRouter (openrouter.ai, model berlabel :free)
- `sk-ant-...` -> Claude (berbayar)

Contoh: `AIzaXXXX, gsk_XXXX, sk-or-XXXX`

Kalau satu key kena limit (HTTP 429) atau error, app otomatis pindah ke key berikutnya.
Urutan = urutan penulisan, jadi taruh yang paling diandalkan di depan.


## Gambar AI
Ketik "buatkan gambar ..." atau "/gambar ...", atau ketuk tombol **Gambar** lalu tulis deskripsinya.
Permintaan otomatis diubah jadi prompt Inggris yang detail supaya hasilnya bagus.

Hasil terbaik (gratis, FLUX lewat Cloudflare Workers AI): tambahkan di kolom API key
`cf=ACCOUNT_ID:API_TOKEN` (dipisah koma dari key lain). Tanpa itu, app memakai Pollinations
(tanpa key, tapi bisa lambat atau dibatasi).
