package com.example.aiassist

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.text.Spannable
import android.text.SpannableString
import android.text.method.PasswordTransformationMethod
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun typewriter(tv: TextView, full: String, delay: Long) {
        tv.text = ""
        var i = 0
        val r = object : Runnable {
            override fun run() {
                i++
                tv.text = full.substring(0, i)
                if (i < full.length) handler.postDelayed(this, 28)
            }
        }
        handler.postDelayed(r, delay)
    }

    private fun lp(
        w: Int = ViewGroup.LayoutParams.MATCH_PARENT,
        h: Int = ViewGroup.LayoutParams.WRAP_CONTENT,
        top: Int = 0
    ) = LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

    // ---------- komponen kecil ----------

    private fun label(t: String) = TextView(this).apply {
        text = t
        setTextColor(0xFF9FB0E6.toInt())
        textSize = 12.5f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        letterSpacing = 0.04f
        setPadding(dp(2), dp(14), 0, dp(7))
    }

    private fun fieldBg(): StateListDrawable {
        val focused = GradientDrawable().apply {
            setColor(0xFF060A1E.toInt()); cornerRadius = dp(14).toFloat(); setStroke(dp(2), Fx.CYAN)
        }
        val normal = GradientDrawable().apply {
            setColor(0xFF060A1E.toInt()); cornerRadius = dp(14).toFloat(); setStroke(dp(1), 0x446E82FF)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    private fun edit(hintText: String, value: String, secret: Boolean): EditText = EditText(this).apply {
        setText(value)
        hint = hintText
        setHintTextColor(0xFF5B6490.toInt())
        setTextColor(Fx.INK)
        textSize = 15f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setSingleLine()
        background = fieldBg()
        setPadding(dp(16), dp(14), dp(48), dp(14))
        if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    /** Kotak field + ikon di kanan. [trailing] dipasang ke ImageView yang dikembalikan lewat callback. */
    private fun fieldBox(input: EditText, iconRes: Int, onIcon: (() -> Unit)?): FrameLayout {
        val box = FrameLayout(this)
        box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        val ic = ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Fx.MUTE)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            if (onIcon != null) setOnClickListener { onIcon() }
        }
        box.addView(ic, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = dp(12)
        })
        return box
    }

    private fun iconBox(res: Int, color: Int, size: Int, radius: Int): ImageView = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(color)
        val pad = dp(size / 4)
        setPadding(pad, pad, pad, pad)
        background = GradientDrawable().apply {
            cornerRadius = dp(radius).toFloat()
            setColor(Fx.alpha(color, 48))
            setStroke(dp(1), Fx.alpha(color, 150))
        }
    }

    private fun header(iconRes: Int, title: String, sub: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(iconBox(iconRes, Fx.CYAN, 34, 10), LinearLayout.LayoutParams(dp(34), dp(34)))
        addView(TextView(context).apply {
            text = title
            setTextColor(Fx.INK)
            textSize = 14f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            letterSpacing = 0.14f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(11) })
        addView(TextView(context).apply {
            text = sub
            setTextColor(Fx.MUTE)
            textSize = 9f
            letterSpacing = 0.18f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
    }

    private fun tile(iconRes: Int, color: Int, title: String, desc: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(0x14FFFFFF)
            setStroke(dp(1), Fx.alpha(color, 70))
        }
        setPadding(dp(13), dp(14), dp(13), dp(15))
        addView(iconBox(iconRes, color, 38, 12), LinearLayout.LayoutParams(dp(38), dp(38)))
        addView(TextView(context).apply {
            text = title
            setTextColor(Fx.INK)
            textSize = 10.5f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            letterSpacing = 0.08f
        }, lp(top = 11))
        addView(TextView(context).apply {
            text = desc
            setTextColor(0xFFA9B4DE.toInt())
            textSize = 12.5f
            setLineSpacing(0f, 1.1f)
        }, lp(top = 4))
    }

    private fun row(a: View, b: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { rightMargin = dp(6) })
        addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { leftMargin = dp(6) })
    }

    // ---------- layar utama ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Fx.BG
        window.navigationBarColor = Fx.BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(26), dp(18), dp(30))
        }

        // ===== bar atas =====
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val status = TextView(this).apply {
            val s = SpannableString("●  SYSTEM ONLINE")
            s.setSpan(ForegroundColorSpan(Fx.GREEN), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            text = s
            textSize = 10f
            setTextColor(Fx.CYAN)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = 0.18f
            background = Ui.rounded(0x1425E8FF, dp(20), 0x4725E8FF, dp(1))
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        val ver = TextView(this).apply {
            text = "NEURAL CORE v2.0"
            textSize = 9.5f
            setTextColor(Fx.MUTE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = 0.16f
            gravity = Gravity.END
        }
        top.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        top.addView(ver, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(top, lp())
        Ui.enter(top, 100, dp(-16).toFloat())

        // ===== robot =====
        val robot = RobotView(this)
        root.addView(robot, lp(h = dp(300), top = 22))
        robot.alpha = 0f
        robot.scaleX = 0.6f
        robot.scaleY = 0.6f
        robot.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(800)
            .setInterpolator(android.view.animation.OvershootInterpolator(1.4f)).start()

        // ===== judul =====
        val title = ShimmerTitle(this)
        root.addView(title, lp(top = -6))
        Ui.enter(title, 600, dp(24).toFloat())

        val sub = TextView(this).apply {
            setTextColor(0xFFA9B8E8.toInt())
            textSize = 10f
            letterSpacing = 0.12f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            minHeight = dp(20)
        }
        root.addView(sub, lp(top = 8))
        typewriter(sub, "ASISTEN AI SERBAGUNA  •  CODING  •  SCAN LAYAR", 1000)

        // ===== kartu pengaturan =====
        val keyIn = edit("AIza... , gsk_... , sk-or-... (pisah koma)", Prefs.apiKey(this), true)
        val modelIn = edit(Prefs.DEFAULT_MODEL, Prefs.model(this), false)
        var shown = false
        val keyBox = fieldBox(keyIn, R.drawable.ic_eye) {
            shown = !shown
            val sel = keyIn.selectionStart
            keyIn.transformationMethod = if (shown) null else PasswordTransformationMethod.getInstance()
            if (sel >= 0) keyIn.setSelection(sel)
        }
        val modelBox = fieldBox(modelIn, R.drawable.ic_bolt, null)

        val save = GlowButton(this, "SIMPAN", R.drawable.ic_save, GlowButton.CYAN)
        Ui.pressable(save)
        save.setOnClickListener {
            Prefs.save(this, keyIn.text.toString(), modelIn.text.toString())
            Toast.makeText(this, "Tersimpan ✓", Toast.LENGTH_SHORT).show()
        }

        val c1 = HudCard(this)
        c1.addView(header(R.drawable.ic_key, "PENGATURAN", "// CONFIG"), lp())
        c1.addView(label("API key (boleh banyak, pisah koma)"))
        c1.addView(keyBox, lp())
        c1.addView(label("Model (biarkan default kalau bingung)"))
        c1.addView(modelBox, lp())
        c1.addView(save, lp(h = dp(50 + 16), top = 10))
        root.addView(c1, lp(top = 24))
        Ui.enter(c1, 1100, dp(40).toFloat())

        // ===== tombol aksi =====
        val go = GlowButton(this, "AKTIFKAN BUBBLE", R.drawable.ic_rocket, GlowButton.PRIMARY)
        Ui.pressable(go)
        go.setOnClickListener {
            Prefs.save(this, keyIn.text.toString(), modelIn.text.toString())
            startBubble()
        }
        val off = GlowButton(this, "MATIKAN BUBBLE", R.drawable.ic_power, GlowButton.PINK)
        Ui.pressable(off)
        off.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Bubble dimatikan", Toast.LENGTH_SHORT).show()
        }
        val c2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c2.addView(go, lp(h = dp(68 + 16)))
        c2.addView(off, lp(h = dp(54 + 16), top = 0))
        root.addView(c2, lp(top = 14))
        Ui.enter(c2, 1250, dp(40).toFloat())

        // ===== fitur =====
        val c3 = HudCard(this)
        c3.addView(header(R.drawable.ic_sparkle, "BISA APA AJA?", "// SKILLS"), lp())
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        grid.addView(
            row(
                tile(R.drawable.ic_chat, Fx.CYAN, "TANYA APA PUN", "Jawab pertanyaan apa pun & bantu coding"),
                tile(R.drawable.ic_phone, Fx.VIOLET, "SCAN LAYAR", "Scan layar, lalu AI langsung menjawab")
            ), lp()
        )
        grid.addView(
            row(
                tile(R.drawable.ic_camera, Fx.PINK, "FOTO SOAL", "Foto soal atau dokumen, AI yang baca"),
                tile(R.drawable.ic_target, Fx.GREEN, "BUBBLE MELAYANG", "Ketuk bubble di pinggir layar untuk mulai")
            ), lp(top = 12)
        )
        c3.addView(grid, lp(top = 16))
        root.addView(c3, lp(top = 14))
        Ui.enter(c3, 1400, dp(40).toFloat())

        val foot = TextView(this).apply {
            text = "POWERED BY ◆ PITO NEURAL ENGINE"
            textSize = 9f
            setTextColor(0xFF5B6490.toInt())
            letterSpacing = 0.25f
            gravity = Gravity.CENTER
        }
        root.addView(foot, lp(top = 26))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            addView(root)
        }
        val screen = FrameLayout(this)
        screen.addView(AuroraBackground(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        screen.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(screen)
    }

    private fun startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan 'tampil di atas aplikasi lain', lalu balik dan ketuk lagi", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Bubble aktif 🤖", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
