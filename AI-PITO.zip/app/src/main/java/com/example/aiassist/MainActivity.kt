package com.example.aiassist

import android.Manifest
import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.TimeInterpolator
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val anims = mutableListOf<Animator>()

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun loop(
        v: View, prop: String, from: Float, to: Float, dur: Long,
        interp: TimeInterpolator, reverse: Boolean
    ) {
        val a = ObjectAnimator.ofFloat(v, prop, from, to).apply {
            duration = dur
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = if (reverse) ObjectAnimator.REVERSE else ObjectAnimator.RESTART
            interpolator = interp
            start()
        }
        anims.add(a)
    }

    private fun typewriter(tv: TextView, full: String, delay: Long) {
        tv.text = ""
        var i = 0
        val r = object : Runnable {
            override fun run() {
                i++
                tv.text = full.substring(0, i)
                if (i < full.length) handler.postDelayed(this, 32)
            }
        }
        handler.postDelayed(r, delay)
    }

    private fun field(hintText: String, value: String, secret: Boolean): EditText = EditText(this).apply {
        setText(value)
        hint = hintText
        setHintTextColor(Ui.MUTED)
        setTextColor(Ui.TEXT)
        textSize = 14f
        setSingleLine()
        background = Ui.rounded(Ui.FIELD, dp(12))
        setPadding(dp(14), dp(12), dp(14), dp(12))
        if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        setTextColor(Ui.MUTED)
        textSize = 12f
        setPadding(dp(4), dp(12), 0, dp(4))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.rounded(Ui.CARD, dp(20), 0x2600E5FF, dp(1))
        setPadding(dp(16), dp(16), dp(16), dp(16))
    }

    private fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, top: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG_TOP
        window.navigationBarColor = Ui.BG_BOT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(36), dp(20), dp(30))
        }

        // ===== HERO: robot + cincin + glow =====
        val hero = FrameLayout(this)
        val glow = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = dp(100).toFloat()
                setColors(intArrayOf(0x9900E5FF.toInt(), 0x007C4DFF))
            }
        }
        val ring = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), Ui.CYAN, dp(10).toFloat(), dp(8).toFloat())
            }
        }
        val robot = ImageView(this).apply {
            setImageResource(R.drawable.ic_robot)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        hero.addView(glow, FrameLayout.LayoutParams(dp(210), dp(210), Gravity.CENTER))
        hero.addView(ring, FrameLayout.LayoutParams(dp(165), dp(165), Gravity.CENTER))
        hero.addView(robot, FrameLayout.LayoutParams(dp(170), dp(170), Gravity.CENTER))
        root.addView(hero, lp(dp(210), dp(210)))

        // masuk: robot "membal" muncul, cincin & glow menyusul
        glow.alpha = 0f; ring.alpha = 0f
        ring.scaleX = 0.5f; ring.scaleY = 0.5f
        robot.alpha = 0f; robot.scaleX = 0f; robot.scaleY = 0f; robot.rotation = -30f

        glow.animate().alpha(1f).setStartDelay(150).setDuration(700).start()
        ring.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(300).setDuration(700)
            .setInterpolator(OvershootInterpolator(1.4f)).start()
        robot.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f)
            .setStartDelay(100).setDuration(850)
            .setInterpolator(OvershootInterpolator(1.7f))
            .withEndAction {
                loop(robot, "translationY", 0f, -dp(9).toFloat(), 1700, AccelerateDecelerateInterpolator(), true)
            }.start()
        handler.postDelayed({
            loop(ring, "rotation", 0f, 360f, 9000, LinearInterpolator(), false)
            loop(glow, "scaleX", 0.92f, 1.1f, 2000, AccelerateDecelerateInterpolator(), true)
            loop(glow, "scaleY", 0.92f, 1.1f, 2000, AccelerateDecelerateInterpolator(), true)
        }, 1000)

        // ===== Judul gradien =====
        val title = TextView(this).apply {
            text = "AI PITO"
            textSize = 36f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.14f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            val w = paint.measureText(text.toString())
            paint.shader = LinearGradient(
                0f, 0f, w, 0f,
                intArrayOf(Ui.CYAN, Ui.PURPLE, Ui.PINK), null, Shader.TileMode.CLAMP
            )
        }
        root.addView(title, lp(top = 4))
        Ui.enter(title, 650, dp(24).toFloat())

        val sub = TextView(this).apply {
            setTextColor(Ui.MUTED)
            textSize = 13f
            gravity = Gravity.CENTER
            minHeight = dp(20)
        }
        root.addView(sub, lp(top = 4))
        typewriter(sub, "Asisten AI serbaguna  •  coding  •  scan layar", 1100)

        // ===== Kartu pengaturan =====
        val keyIn = field("AIza... (Gemini) atau sk-ant-... (Claude)", Prefs.apiKey(this), true)
        val modelIn = field(Prefs.DEFAULT_MODEL, Prefs.model(this), false)

        val c1 = card()
        c1.addView(TextView(this).apply {
            text = "🔑  Pengaturan"
            setTextColor(Ui.TEXT)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        })
        c1.addView(label("API key (Gemini gratis atau Claude)"))
        c1.addView(keyIn, lp())
        c1.addView(label("Model (biarkan default kalau bingung)"))
        c1.addView(modelIn, lp())
        c1.addView(
            Ui.pill(this, "💾  Simpan", Ui.rounded(0x2200E5FF, dp(14), Ui.CYAN, dp(1)), Ui.CYAN) {
                Prefs.save(this, keyIn.text.toString(), modelIn.text.toString())
                Toast.makeText(this, "Tersimpan ✓", Toast.LENGTH_SHORT).show()
            }, lp(top = 14)
        )
        root.addView(c1, lp(top = 22))
        Ui.enter(c1, 1250, dp(40).toFloat())

        // ===== Tombol aksi =====
        val c2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c2.addView(
            Ui.pill(this, "🚀   Aktifkan bubble", Ui.gradient(Ui.PURPLE, 0xFF00B8D4.toInt(), dp(28)), Color.WHITE, 16f) {
                Prefs.save(this, keyIn.text.toString(), modelIn.text.toString())
                startBubble()
            }, lp(h = dp(54))
        )
        c2.addView(
            Ui.pill(this, "⏻   Matikan bubble", Ui.rounded(0x22FF4081, dp(24), Ui.PINK, dp(1)), Ui.PINK, 14f) {
                stopService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Bubble dimatikan", Toast.LENGTH_SHORT).show()
            }, lp(h = dp(46), top = 10)
        )
        root.addView(c2, lp(top = 16))
        Ui.enter(c2, 1400, dp(40).toFloat())

        // ===== Fitur =====
        val c3 = card()
        c3.addView(TextView(this).apply {
            text = "✨  Bisa apa aja?"
            setTextColor(Ui.TEXT)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        })
        listOf(
            "💬  Jawab pertanyaan apa pun & bantu coding",
            "📱  Scan layar, lalu AI langsung menjawab",
            "📷  Foto soal atau dokumen, AI yang baca",
            "🫧  Ketuk bubble di pinggir layar untuk mulai"
        ).forEach {
            c3.addView(TextView(this).apply {
                text = it
                setTextColor(Ui.MUTED)
                textSize = 13f
                setPadding(0, dp(10), 0, 0)
            })
        }
        root.addView(c3, lp(top = 16))
        Ui.enter(c3, 1550, dp(40).toFloat())

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Ui.BG_TOP, Ui.BG_MID, Ui.BG_BOT)
            )
            addView(root)
        })
    }

    private fun startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan 'tampil di atas aplikasi lain', lalu balik dan ketuk lagi", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Bubble aktif 🤖", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        anims.forEach { it.cancel() }
        super.onDestroy()
    }
}
