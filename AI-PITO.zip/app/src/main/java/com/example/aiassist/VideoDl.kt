package com.example.aiassist

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLEncoder

/**
 * Unduh video dari link https.
 *  - TikTok  -> layanan tikwm.com (tanpa watermark), tidak perlu setup.
 *  - Situs lain (YouTube, Instagram, Facebook, X/Twitter, Pinterest, Reddit, Vimeo, dll)
 *    -> lewat server Cobalt (cobalt.tools). Server Cobalt publik dibatasi, jadi isi
 *    server milikmu di kolom API key:
 *        cobalt=https://alamat-server-cobalt-mu
 *        cobaltkey=API_KEY_JIKA_DIPERLUKAN      (opsional)
 */
object VideoDl {
    class Info(val videoUrl: String, val title: String, val author: String)
    class Saved(val location: String, val width: Int, val height: Int)

    private const val UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"
    private const val TIKWM = "https://www.tikwm.com"

    private val ANY_URL = Regex("https?://\\S+", RegexOption.IGNORE_CASE)

    // Domain yang otomatis dikenali sebagai link video.
    private val TIKTOK_HOSTS = listOf("tiktok.com", "tiktokv.com")
    private val OTHER_HOSTS = listOf(
        "youtube.com", "youtu.be", "instagram.com", "facebook.com", "fb.watch", "fb.com",
        "twitter.com", "x.com", "pinterest.com", "pin.it", "reddit.com", "vimeo.com",
        "twitch.tv", "snapchat.com", "tumblr.com", "bilibili.com", "dailymotion.com",
        "streamable.com", "loom.com", "soundcloud.com", "threads.net", "capcut.com"
    )

    private fun hostOf(url: String): String =
        runCatching { URI(url).host.orEmpty().lowercase().removePrefix("www.") }.getOrDefault("")

    private fun hostMatches(url: String, list: List<String>): Boolean {
        val h = hostOf(url)
        return list.any { h == it || h.endsWith(".$it") }
    }

    private fun isTikTok(url: String) = hostMatches(url, TIKTOK_HOSTS)

    /**
     * Cari link video di teks pesan. Dikenali kalau domainnya ada di daftar,
     * atau kalau pesan diawali "/unduh " (untuk situs lain). Selalu dipaksa https.
     */
    fun extractLink(text: String): String? {
        val t = text.trim()
        val forced = t.startsWith("/unduh ", ignoreCase = true) || t.startsWith("/dl ", ignoreCase = true)
        val m = ANY_URL.find(t) ?: return null
        val url = m.value.trimEnd('.', ',', ')', '!', '?').replaceFirst("http://", "https://")
        return if (forced || hostMatches(url, TIKTOK_HOSTS + OTHER_HOSTS)) url else null
    }

    // ---------- konfigurasi Cobalt dari kolom API key ----------
    private fun cobaltServer(ctx: Context): String? =
        Prefs.apiKey(ctx).split(Regex("[,;\\s]+"))
            .firstOrNull { it.startsWith("cobalt=") && it.length > 10 }
            ?.removePrefix("cobalt=")?.trimEnd('/')

    private fun cobaltKey(ctx: Context): String? =
        Prefs.apiKey(ctx).split(Regex("[,;\\s]+"))
            .firstOrNull { it.startsWith("cobaltkey=") && it.length > 10 }
            ?.removePrefix("cobaltkey=")

    private fun isLocal(url: String): Boolean = hostOf(url).let { it == "127.0.0.1" || it == "localhost" }

    private fun abs(base: String, u: String): String = when {
        u.startsWith("//") -> "https:$u"
        u.startsWith("/") -> base + u
        isLocal(u) -> u
        else -> u.replaceFirst("http://", "https://")
    }

    fun resolve(ctx: Context, link: String): Info {
        var last: Exception? = null
        repeat(3) { attempt ->
            try {
                return if (isTikTok(link)) tikwm(link) else cobalt(ctx, link)
            } catch (e: NoRetry) {
                throw Exception(e.message)
            } catch (e: Exception) {
                last = e
                if (attempt < 2) Thread.sleep(1500L * (attempt + 1))
            }
        }
        throw last ?: Exception("gagal membaca link")
    }

    private class NoRetry(msg: String) : Exception(msg)

    private fun readBody(conn: HttpURLConnection): Pair<Int, String> {
        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
        return code to body
    }

    // ---------- TikTok (tanpa watermark) ----------
    private fun tikwm(link: String): Info {
        val api = "$TIKWM/api/?hd=1&url=" + URLEncoder.encode(link, "UTF-8")
        val conn = URL(api).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.setRequestProperty("User-Agent", UA)
        val (code, body) = readBody(conn)
        if (code !in 200..299) throw Exception("HTTP $code dari server unduh (mungkin sibuk/dibatasi)")
        val json = JSONObject(body)
        if (json.optInt("code", -1) != 0) {
            throw Exception(json.optString("msg").ifBlank { "video tidak ditemukan / akun privat" })
        }
        val d = json.getJSONObject("data")
        val url = d.optString("hdplay").ifBlank { d.optString("play") }
        if (url.isBlank()) throw Exception("video tanpa watermark tidak tersedia (mungkin postingan foto)")
        return Info(
            videoUrl = abs(TIKWM, url),
            title = d.optString("title"),
            author = d.optJSONObject("author")?.optString("nickname").orEmpty()
        )
    }

    // ---------- Situs lain via Cobalt ----------
    private fun cobalt(ctx: Context, link: String): Info {
        val server = cobaltServer(ctx) ?: throw NoRetry(
            "Link ini bukan TikTok, jadi butuh server Cobalt.\n" +
                "Tambahkan di kolom API key:  cobalt=https://alamat-server-cobalt-mu\n" +
                "(kalau servernya pakai key: tambah juga  cobaltkey=KEY_KAMU)"
        )
        if (!server.startsWith("https://") && !(server.startsWith("http://") && isLocal(server))) {
            throw NoRetry("alamat server Cobalt harus https:// (atau http://127.0.0.1:9000 kalau jalan di Termux)")
        }

        val conn = URL("$server/").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 90000
        conn.doOutput = true
        conn.setRequestProperty("User-Agent", UA)
        conn.setRequestProperty("Accept", "application/json")
        conn.setRequestProperty("Content-Type", "application/json")
        cobaltKey(ctx)?.let { conn.setRequestProperty("Authorization", "Api-Key $it") }
        val req = JSONObject().put("url", link).put("videoQuality", "max").put("downloadMode", "auto")
        conn.outputStream.use { it.write(req.toString().toByteArray(Charsets.UTF_8)) }

        val (code, body) = readBody(conn)
        val json = runCatching { JSONObject(body) }.getOrNull()
            ?: throw Exception("HTTP $code: balasan server Cobalt tidak dikenali")
        return when (json.optString("status")) {
            "tunnel", "redirect" -> Info(abs(server, json.getString("url")), json.optString("filename"), "")
            "picker" -> {
                val arr = json.getJSONArray("picker")
                var pick: JSONObject? = null
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optString("type") == "video") { pick = o; break }
                }
                val o = pick ?: throw NoRetry("postingan ini tidak berisi video (hanya foto)")
                Info(abs(server, o.getString("url")), "", "")
            }
            else -> {
                val c = json.optJSONObject("error")?.optString("code").orEmpty()
                val msg = when {
                    c.contains("auth") -> "server Cobalt meminta key. Tambahkan cobaltkey=KEY di kolom API key ($c)"
                    c.contains("content.video.unavailable") || c.contains("fetch") ->
                        "video tidak tersedia / privat / dibatasi umur ($c)"
                    c.contains("link") || c.contains("service") -> "link atau situs ini tidak didukung server Cobalt-mu ($c)"
                    else -> c.ifBlank { "HTTP $code" }
                }
                throw NoRetry(msg)
            }
        }
    }

    // ---------- Simpan ke galeri ----------
    /** Unduh file lalu simpan (video -> Movies/AI PITO, audio -> Music/AI PITO). Mengembalikan lokasinya. */
    fun download(ctx: Context, info: Info, onProgress: (Int) -> Unit = {}): Saved {
        val conn = URL(info.videoUrl).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.setRequestProperty("User-Agent", UA)
        if (conn.responseCode !in 200..299) throw Exception("HTTP ${conn.responseCode} saat mengunduh video")
        val total = conn.contentLength.toLong()
        val ctype = (conn.contentType ?: "video/mp4").substringBefore(';').trim().lowercase()
        val audio = ctype.startsWith("audio/")
        val ext = when {
            audio -> if (ctype.contains("mpeg")) "mp3" else "m4a"
            ctype.contains("webm") -> "webm"
            else -> "mp4"
        }
        val mime = if (audio || ctype.startsWith("video/")) ctype else "video/mp4"
        val name = "AI_PITO_${System.currentTimeMillis()}.$ext"

        fun copy(out: java.io.OutputStream) {
            conn.inputStream.use { input ->
                val buf = ByteArray(32 * 1024)
                var done = 0L
                var lastPct = -1
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                    }
                }
            }
        }

        return if (Build.VERSION.SDK_INT >= 29) {
            val folder = if (audio) "Music/AI PITO" else "Movies/AI PITO"
            val table = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri: Uri = ctx.contentResolver.insert(table, cv)
                ?: throw Exception("gagal membuat file di galeri")
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { copy(it) }
                    ?: throw Exception("gagal menulis file")
                cv.clear()
                cv.put(MediaStore.MediaColumns.IS_PENDING, 0)
                ctx.contentResolver.update(uri, cv, null, null)
            } catch (e: Exception) {
                ctx.contentResolver.delete(uri, null, null)
                throw e
            }
            val (w, h) = if (audio) 0 to 0 else readSize { it.setDataSource(ctx, uri) }
            Saved("$folder/$name", w, h)
        } else {
            val type = if (audio) android.os.Environment.DIRECTORY_MUSIC else android.os.Environment.DIRECTORY_MOVIES
            val dir = ctx.getExternalFilesDir(type) ?: ctx.filesDir
            val f = File(dir, name)
            f.outputStream().use { copy(it) }
            val (w, h) = if (audio) 0 to 0 else readSize { it.setDataSource(f.absolutePath) }
            Saved(f.absolutePath, w, h)
        }
    }

    /** Baca lebar x tinggi video (sudah memperhitungkan rotasi). Gagal -> 0 x 0. */
    private fun readSize(setup: (android.media.MediaMetadataRetriever) -> Unit): Pair<Int, Int> {
        val r = android.media.MediaMetadataRetriever()
        return try {
            setup(r)
            val w = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) h to w else w to h
        } catch (e: Exception) {
            0 to 0
        } finally {
            runCatching { r.release() }
        }
    }
}
