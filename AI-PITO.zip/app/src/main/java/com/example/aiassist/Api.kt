package com.example.aiassist

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Dukung 2 penyedia, otomatis dari awalan key:
 *  - "sk-ant..."  -> Anthropic (Claude, berbayar)
 *  - selain itu   -> Google Gemini (ada jatah gratis)
 * Riwayat chat disimpan dalam format Anthropic, lalu diubah ke format Gemini saat kirim.
 */
object Api {
    private const val SYSTEM =
        "Kamu asisten AI serbaguna di HP bernama AI PITO. Jawab pertanyaan apa pun dan bantu coding. " +
        "Kalau ada gambar/screenshot, baca isinya lalu jawab atau selesaikan. " +
        "Balas dalam bahasa yang dipakai pengguna. Jawaban jelas dan tidak bertele-tele. " +
        "Tulis tanpa format markdown berat karena tampil sebagai teks biasa."

    // dicoba berurutan kalau model yang dipilih tidak ditemukan (404)
    private val GEMINI_FALLBACKS = listOf("gemini-2.5-flash", "gemini-3.5-flash", "gemini-2.5-flash-lite")
    private const val CLAUDE_DEFAULT = "claude-sonnet-5-5"

    fun toBase64(src: Bitmap): String {
        val max = 1568
        val scale = minOf(1f, max.toFloat() / maxOf(src.width, src.height))
        val bmp = if (scale < 1f)
            Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
        else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    fun chat(ctx: Context, messages: JSONArray): String {
        val key = Prefs.apiKey(ctx)
        return if (key.startsWith("sk-ant")) anthropic(ctx, key, messages) else gemini(ctx, key, messages)
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 30000
        conn.readTimeout = 180000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return code to text
    }

    private fun errMsg(code: Int, text: String): String {
        val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
            .getOrDefault(text.take(300))
        return when (code) {
            429 -> "Jatah habis / terlalu cepat (HTTP 429). Tunggu sebentar atau coba lagi nanti. $msg"
            401, 403 -> "API key ditolak (HTTP $code). Cek lagi key-nya. $msg"
            400 -> "HTTP 400: $msg"
            else -> "HTTP $code: $msg"
        }
    }

    // ---------- Anthropic ----------
    private fun anthropic(ctx: Context, key: String, messages: JSONArray): String {
        var model = Prefs.model(ctx)
        if (model.startsWith("gemini")) model = CLAUDE_DEFAULT
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 4096)
            .put("system", SYSTEM)
            .put("messages", messages)
        val (code, text) = post(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"),
            body
        )
        if (code !in 200..299) throw Exception(errMsg(code, text))
        val arr = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.getString("text"))
        }
        return sb.toString().trim()
    }

    // ---------- Gemini ----------
    private fun toGemini(messages: JSONArray): JSONArray {
        val out = JSONArray()
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            val role = if (m.getString("role") == "assistant") "model" else "user"
            val parts = JSONArray()
            val c = m.opt("content")
            if (c is JSONArray) {
                for (j in 0 until c.length()) {
                    val b = c.getJSONObject(j)
                    when (b.optString("type")) {
                        "image" -> parts.put(
                            JSONObject().put(
                                "inline_data", JSONObject()
                                    .put("mime_type", "image/jpeg")
                                    .put("data", b.getJSONObject("source").getString("data"))
                            )
                        )
                        "text" -> parts.put(JSONObject().put("text", b.getString("text")))
                    }
                }
            } else {
                parts.put(JSONObject().put("text", c?.toString() ?: ""))
            }
            out.put(JSONObject().put("role", role).put("parts", parts))
        }
        return out
    }

    private fun gemini(ctx: Context, key: String, messages: JSONArray): String {
        var model = Prefs.model(ctx)
        if (model.startsWith("claude")) model = GEMINI_FALLBACKS[0]

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", toGemini(messages))

        val candidates = LinkedHashSet<String>()
        candidates.add(model)
        candidates.addAll(GEMINI_FALLBACKS)

        var lastErr = "Gagal menghubungi Gemini"
        for (m in candidates) {
            val (code, text) = post(
                "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                mapOf("x-goog-api-key" to key),
                body
            )
            if (code in 200..299) return parseGemini(text)
            lastErr = errMsg(code, text)
            if (code != 404) break // ganti model hanya kalau modelnya tidak ada
        }
        throw Exception(lastErr)
    }

    private fun parseGemini(text: String): String {
        val root = JSONObject(text)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
            throw Exception("Gemini tidak memberi jawaban. $reason".trim())
        }
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw Exception("Jawaban kosong dari Gemini")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        val r = sb.toString().trim()
        if (r.isEmpty()) throw Exception("Jawaban kosong dari Gemini")
        return r
    }
}
