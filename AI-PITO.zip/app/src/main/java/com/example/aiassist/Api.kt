package com.example.aiassist

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object Api {
    private const val SYSTEM =
        "Kamu asisten AI serbaguna di HP. Jawab pertanyaan apa pun dan bantu coding. " +
        "Kalau ada gambar/screenshot, baca isinya lalu jawab atau selesaikan. " +
        "Balas dalam bahasa yang dipakai pengguna. Jawaban jelas dan tidak bertele-tele. " +
        "Tulis tanpa format markdown berat karena tampil sebagai teks biasa."

    fun toBase64(src: Bitmap): String {
        val max = 1568
        val scale = minOf(1f, max.toFloat() / maxOf(src.width, src.height))
        val bmp = if (scale < 1f)
            Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
        else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    fun chat(ctx: Context, messages: JSONArray): String {
        val body = JSONObject()
            .put("model", Prefs.model(ctx))
            .put("max_tokens", 4096)
            .put("system", SYSTEM)
            .put("messages", messages)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 30000
        conn.readTimeout = 180000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", Prefs.apiKey(ctx))
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
                .getOrDefault(text)
            throw Exception("HTTP $code: $msg")
        }
        val arr = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.getString("text"))
        }
        return sb.toString().trim()
    }
}
