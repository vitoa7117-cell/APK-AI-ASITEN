package com.example.aiassist

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Dukung banyak penyedia sekaligus. Di kolom API key boleh isi BEBERAPA key,
 * dipisah koma. Penyedia dikenali otomatis dari awalan key:
 *  - "sk-ant..." -> Anthropic (Claude, berbayar)
 *  - "gsk_..."   -> Groq (Llama, ada jatah gratis)
 *  - "sk-or-..." -> OpenRouter (model berlabel :free)
 *  - selain itu  -> Google Gemini (ada jatah gratis)
 *
 * Key dicoba berurutan sesuai urutan penulisan. Kalau satu kena limit (429),
 * error server (5xx), atau gagal koneksi, otomatis pindah ke key berikutnya.
 * Riwayat chat disimpan dalam format Anthropic, lalu diubah ke format tiap penyedia saat kirim.
 */
object Api {
    private const val SYSTEM =
        "Kamu asisten AI serbaguna di HP bernama AI PITO. Jawab pertanyaan apa pun dan bantu coding. " +
        "Kalau ada gambar/screenshot, baca isinya lalu jawab atau selesaikan. " +
        "Balas dalam bahasa yang dipakai pengguna. Jawaban jelas dan tidak bertele-tele. " +
        "Tulis tanpa format markdown berat karena tampil sebagai teks biasa."

    // Nama model sering berubah. Kalau ada yang tidak ditemukan, cukup ganti daftar ini.
    private val GEMINI_MODELS = listOf("gemini-2.5-flash", "gemini-3.5-flash", "gemini-2.5-flash-lite")
    private const val CLAUDE_DEFAULT = "claude-sonnet-5-5"
    private val GROQ_TEXT = listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant")
    private val GROQ_VISION = listOf("meta-llama/llama-4-scout-17b-16e-instruct")
    private val OPENROUTER_TEXT = listOf("meta-llama/llama-3.3-70b-instruct:free", "google/gemma-3-27b-it:free")
    private val OPENROUTER_VISION = listOf("google/gemma-3-27b-it:free")

    // key yang barusan kena limit dilewati dulu selama beberapa saat
    private val cooldown = ConcurrentHashMap<String, Long>()
    private const val COOLDOWN_MS = 60_000L

    private class ApiError(val code: Int, message: String) : Exception(message)

    fun toBase64(src: Bitmap): String {
        val max = 1568
        val scale = minOf(1f, max.toFloat() / maxOf(src.width, src.height))
        val bmp = if (scale < 1f)
            Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
        else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun parseKeys(raw: String): List<String> =
        raw.split(Regex("[,;\\s]+")).map { it.trim() }.filter { it.isNotEmpty() }.distinct()

    private fun providerOf(key: String): String = when {
        key.startsWith("sk-ant") -> "Claude"
        key.startsWith("gsk_") -> "Groq"
        key.startsWith("sk-or-") -> "OpenRouter"
        else -> "Gemini"
    }

    private fun hasImage(messages: JSONArray): Boolean {
        for (i in 0 until messages.length()) {
            val c = messages.getJSONObject(i).opt("content")
            if (c is JSONArray) {
                for (j in 0 until c.length()) {
                    if (c.getJSONObject(j).optString("type") == "image") return true
                }
            }
        }
        return false
    }

    fun chat(ctx: Context, messages: JSONArray): String {
        val keys = parseKeys(Prefs.apiKey(ctx))
        if (keys.isEmpty()) throw Exception("API key belum diisi.")

        val image = hasImage(messages)
        val now = System.currentTimeMillis()
        // key yang sedang cooldown dicoba paling akhir
        val ready = keys.filter { (cooldown[it] ?: 0L) <= now }
        val order = ready + keys.filter { it !in ready }

        val errors = mutableListOf<String>()
        for (key in order) {
            val name = providerOf(key)
            try {
                return when (name) {
                    "Claude" -> anthropic(ctx, key, messages)
                    "Groq" -> openAiCompat(
                        "https://api.groq.com/openai/v1/chat/completions",
                        key, if (image) GROQ_VISION else GROQ_TEXT, messages
                    )
                    "OpenRouter" -> openAiCompat(
                        "https://openrouter.ai/api/v1/chat/completions",
                        key, if (image) OPENROUTER_VISION else OPENROUTER_TEXT, messages
                    )
                    else -> gemini(ctx, key, messages)
                }
            } catch (e: ApiError) {
                if (e.code == 429 || e.code >= 500) cooldown[key] = System.currentTimeMillis() + COOLDOWN_MS
                errors.add("$name: ${e.message}")
            } catch (e: Exception) {
                // gagal koneksi / jawaban kosong -> coba key berikutnya
                errors.add("$name: ${e.message ?: e.toString()}")
            }
        }
        throw Exception(
            if (errors.size == 1) errors[0]
            else "Semua API key gagal dipakai:\n" + errors.joinToString("\n")
        )
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 30000
        conn.readTimeout = 180000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return code to text
    }

    private fun errMsg(code: Int, text: String): String {
        val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
            .getOrDefault(text.take(300))
        return when (code) {
            429 -> "Jatah habis / terlalu cepat (HTTP 429). $msg"
            401, 403 -> "API key ditolak (HTTP $code). Cek lagi key-nya. $msg"
            400 -> "HTTP 400: $msg"
            else -> "HTTP $code: $msg"
        }
    }

    // ---------- Anthropic ----------
    private fun anthropic(ctx: Context, key: String, messages: JSONArray): String {
        var model = Prefs.model(ctx)
        if (!model.startsWith("claude")) model = CLAUDE_DEFAULT
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 4096)
            .put("system", SYSTEM)
            .put("messages", messages)
        val (code, text) = post(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"),
            body
        )
        if (code !in 200..299) throw ApiError(code, errMsg(code, text))
        val arr = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.getString("text"))
        }
        return sb.toString().trim()
    }

    // ---------- Gemini ----------
    private fun toGemini(messages: JSONArray): JSONArray {
        val out = JSONArray()
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            val role = if (m.getString("role") == "assistant") "model" else "user"
            val parts = JSONArray()
            val c = m.opt("content")
            if (c is JSONArray) {
                for (j in 0 until c.length()) {
                    val b = c.getJSONObject(j)
                    when (b.optString("type")) {
                        "image" -> parts.put(
                            JSONObject().put(
                                "inline_data", JSONObject()
                                    .put("mime_type", "image/jpeg")
                                    .put("data", b.getJSONObject("source").getString("data"))
                            )
                        )
                        "text" -> parts.put(JSONObject().put("text", b.getString("text")))
                    }
                }
            } else {
                parts.put(JSONObject().put("text", c?.toString() ?: ""))
            }
            out.put(JSONObject().put("role", role).put("parts", parts))
        }
        return out
    }

    private fun gemini(ctx: Context, key: String, messages: JSONArray): String {
        var model = Prefs.model(ctx)
        if (!model.startsWith("gemini")) model = GEMINI_MODELS[0]

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", toGemini(messages))

        val candidates = LinkedHashSet<String>()
        candidates.add(model)
        candidates.addAll(GEMINI_MODELS)

        var last = ApiError(0, "Gagal menghubungi Gemini")
        for (m in candidates) {
            val (code, text) = post(
                "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                mapOf("x-goog-api-key" to key),
                body
            )
            if (code in 200..299) return parseGemini(text)
            last = ApiError(code, errMsg(code, text))
            // Jatah Gemini dihitung per model, jadi model lain masih bisa jalan
            // kalau modelnya tidak ada (404), kena limit (429), atau server sibuk (5xx).
            if (code != 404 && code != 429 && code < 500) break
        }
        throw last
    }

    private fun parseGemini(text: String): String {
        val root = JSONObject(text)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
            throw Exception("Gemini tidak memberi jawaban. $reason".trim())
        }
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw Exception("Jawaban kosong dari Gemini")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        val r = sb.toString().trim()
        if (r.isEmpty()) throw Exception("Jawaban kosong dari Gemini")
        return r
    }

    // ---------- Groq & OpenRouter (format OpenAI) ----------
    private fun toOpenAi(messages: JSONArray): JSONArray {
        val out = JSONArray()
        out.put(JSONObject().put("role", "system").put("content", SYSTEM))
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            val role = m.getString("role")
            val c = m.opt("content")
            if (c is JSONArray) {
                val parts = JSONArray()
                var images = 0
                val texts = StringBuilder()
                for (j in 0 until c.length()) {
                    val b = c.getJSONObject(j)
                    when (b.optString("type")) {
                        "image" -> {
                            images++
                            val data = b.getJSONObject("source").getString("data")
                            parts.put(
                                JSONObject().put("type", "image_url").put(
                                    "image_url", JSONObject().put("url", "data:image/jpeg;base64,$data")
                                )
                            )
                        }
                        "text" -> {
                            texts.append(b.getString("text"))
                            parts.put(JSONObject().put("type", "text").put("text", b.getString("text")))
                        }
                    }
                }
                // tanpa gambar, kirim teks biasa supaya cocok dengan model teks saja
                out.put(JSONObject().put("role", role).put("content", if (images == 0) texts.toString() else parts))
            } else {
                out.put(JSONObject().put("role", role).put("content", c?.toString() ?: ""))
            }
        }
        return out
    }

    private fun openAiCompat(url: String, key: String, models: List<String>, messages: JSONArray): String {
        val msgs = toOpenAi(messages)
        var last = ApiError(0, "Gagal menghubungi server")
        for (m in models) {
            val body = JSONObject().put("model", m).put("messages", msgs).put("max_tokens", 4096)
            val (code, text) = post(url, mapOf("Authorization" to "Bearer $key"), body)
            if (code in 200..299) {
                val choices = JSONObject(text).optJSONArray("choices")
                val reply = choices?.optJSONObject(0)?.optJSONObject("message")?.optString("content", "")?.trim() ?: ""
                if (reply.isNotEmpty()) return reply
                last = ApiError(code, "Jawaban kosong dari $m")
                continue
            }
            last = ApiError(code, errMsg(code, text))
            // key ditolak (401/403) -> model lain pun pasti ditolak, berhenti di sini
            if (code != 400 && code != 404 && code != 429 && code < 500) break
        }
        throw last
    }
}
