package com.example.aiassist

import android.animation.Animator
import android.animation.ObjectAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: ImageView? = null
    private var bubbleBg: GradientDrawable? = null
    private val bubbleAnims = mutableListOf<Animator>()

    private var panel: LinearLayout? = null
    private var panelShown = false
    private var panelAttached = false

    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var preview: TextView
    private lateinit var sendBtn: ImageView

    private val history = JSONArray()
    private var pendingImage: Bitmap? = null
    private var busy = false

    private var thinkingView: View? = null
    private var suggestionsView: View? = null
    private var revealRunnable: Runnable? = null

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startFg()
        buildPanel()
        buildBubble()

        Bridge.onImage = { bmp -> handler.post { setPending(bmp); showPanel() } }
        Bridge.onCancel = { handler.post { showPanel() } }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("overlay", "Bubble AI", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "overlay")
            .setContentTitle("AI PITO aktif")
            .setContentText("Ketuk bubble untuk bertanya")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ================= Bubble =================

    private fun buildBubble() {
        val size = dp(58)
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels

        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFF1A1033.toInt())
            setStroke(dp(2), Ui.CYAN)
        }
        bubbleBg = bg

        val v = ImageView(this).apply {
            setImageResource(R.drawable.ic_robot_bubble)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = bg
            elevation = dp(6).toFloat()
        }

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW - size
            y = screenH / 3
        }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + dx; lp.y = sy + dy
                        wm.updateViewLayout(view, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (panelShown) hidePanel() else showPanel()
                    } else {
                        lp.x = if (lp.x + size / 2 < screenW / 2) 0 else screenW - size
                        wm.updateViewLayout(view, lp)
                    }
                    true
                }
                else -> false
            }
        }
        bubble = v
        wm.addView(v, lp)

        // animasi masuk: membal muncul, lalu "bernapas"
        v.scaleX = 0f; v.scaleY = 0f; v.rotation = -90f
        v.animate().scaleX(1f).scaleY(1f).rotation(0f)
            .setDuration(650).setInterpolator(OvershootInterpolator(2f))
            .withEndAction {
                for (p in listOf("scaleX", "scaleY")) {
                    val a = ObjectAnimator.ofFloat(v, p, 1f, 1.08f).apply {
                        duration = 1200
                        repeatCount = ObjectAnimator.INFINITE
                        repeatMode = ObjectAnimator.REVERSE
                        interpolator = AccelerateDecelerateInterpolator()
                        start()
                    }
                    bubbleAnims.add(a)
                }
            }.start()
    }

    private fun setBubbleBusy(b: Boolean) {
        bubbleBg?.setStroke(dp(2), if (b) Ui.PINK else Ui.CYAN)
        bubble?.invalidate()
    }

    // ================= Panel chat =================

    private fun buildPanel() {
        val root = object : NeonFrame(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.action == KeyEvent.ACTION_UP) hidePanel()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14), dp(14), dp(14), dp(14))

        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT
        val match = LinearLayout.LayoutParams.MATCH_PARENT

        // ===== header =====
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(AiOrb(this), LinearLayout.LayoutParams(dp(46), dp(46)))

        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        titleBox.addView(ShimmerTitle(this).apply {
            textSize = 17f
            letterSpacing = 0.12f
            gravity = Gravity.START
        })
        val status = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        status.addView(PulseDot(this, Fx.GREEN))
        status.addView(TextView(this).apply {
            text = "NEURAL ASSISTANT • ONLINE"
            setTextColor(Fx.GREEN)
            textSize = 9f
            letterSpacing = 0.12f
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = dp(6) })
        titleBox.addView(status, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(3) })
        header.addView(titleBox, LinearLayout.LayoutParams(0, wrap, 1f))

        val btnLp = { LinearLayout.LayoutParams(dp(36), dp(36)).apply { leftMargin = dp(6) } }
        header.addView(PanelUi.iconBtn(this, R.drawable.ic_trash, Fx.INK) { clearChat() }, btnLp())
        header.addView(PanelUi.iconBtn(this, R.drawable.ic_power, Fx.PINK) { stopSelf() }, btnLp())
        header.addView(PanelUi.iconBtn(this, R.drawable.ic_close, Fx.INK) { hidePanel() }, btnLp())
        root.addView(header)

        // garis pemisah neon
        root.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0x0025E8FF, 0x9925E8FF.toInt(), 0x008A5CFF)
            )
        }, LinearLayout.LayoutParams(match, dp(1)).apply { topMargin = dp(10) })

        // ===== area chat =====
        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(8))
        }
        scroll = ScrollView(this).apply { addView(messages); isVerticalScrollBarEnabled = false }
        root.addView(scroll, LinearLayout.LayoutParams(match, 0, 1f))

        // ===== lampiran =====
        preview = TextView(this).apply {
            setTextColor(0xFF9ECBFF.toInt())
            textSize = 12f
            background = Ui.rounded(0x2200E5FF, dp(10), 0x5525E8FF, dp(1))
            setPadding(dp(10), dp(6), dp(10), dp(6))
            visibility = View.GONE
            setOnClickListener { setPending(null) }
        }
        root.addView(preview, LinearLayout.LayoutParams(wrap, wrap).apply { bottomMargin = dp(6) })

        // ===== tombol scan =====
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(PanelUi.chip(this, R.drawable.ic_phone, "Scan layar", Fx.CYAN) { scanScreen() },
            LinearLayout.LayoutParams(0, wrap, 1f))
        actions.addView(PanelUi.chip(this, R.drawable.ic_camera, "Kamera", Fx.PINK) { scanCamera() },
            LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(8) })
        root.addView(actions)

        // ===== input =====
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Tanya apa saja..."
            setHintTextColor(Ui.MUTED)
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 4
            background = PanelUi.fieldBg(this@OverlayService, false)
            setPadding(dp(16), dp(11), dp(16), dp(11))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setOnFocusChangeListener { v, focused -> v.background = PanelUi.fieldBg(this@OverlayService, focused) }
        }
        row.addView(input, LinearLayout.LayoutParams(0, wrap, 1f))
        sendBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_send)
            setColorFilter(Color.WHITE, android.graphics.PorterDuff.Mode.SRC_IN)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(11), dp(11), dp(11), dp(11))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(Ui.PURPLE, 0xFF00B8D4.toInt())
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), 0x6625E8FF)
            }
            isClickable = true
            setOnClickListener { send() }
            Ui.pressable(this)
        }
        row.addView(sendBtn, LinearLayout.LayoutParams(dp(46), dp(46)).apply { leftMargin = dp(8) })
        root.addView(row, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(10) })

        panel = root
        addWelcome()
    }

    private fun addWelcome() {
        addMsg("Halo! Aku AI PITO 🤖\nTanya apa saja, minta bantuan coding, atau scan layar/kamera.", user = false)
        addSuggestions()
    }

    /** Saran pertanyaan cepat, hilang begitu pengguna mulai chat. */
    private fun addSuggestions() {
        val ideas = listOf(
            "Ajari aku dasar coding" to "Ajari aku dasar coding dari nol, singkat dan jelas.",
            "Ide konten kreatif" to "Kasih 5 ide konten kreatif yang lagi tren.",
            "Tips lebih produktif" to "Kasih 5 tips supaya aku lebih produktif."
        )
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ideas.forEachIndexed { i, (label, prompt) ->
            val chip = PanelUi.chip(this, R.drawable.ic_sparkle, label, 0xFFB79CFF.toInt()) {
                if (!busy) {
                    input.setText(prompt)
                    send()
                }
            }
            box.addView(chip, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) })
            Ui.enter(chip, 350L + i * 120L, dp(12).toFloat())
        }
        messages.addView(box, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.START })
        suggestionsView = box
    }

    private fun removeSuggestions() {
        suggestionsView?.let { messages.removeView(it) }
        suggestionsView = null
    }

    private fun clearChat() {
        if (busy) return
        revealRunnable?.let { handler.removeCallbacks(it) }
        revealRunnable = null
        while (history.length() > 0) history.remove(0)
        messages.removeAllViews()
        suggestionsView = null
        setPending(null)
        addWelcome()
    }

    private fun showPanel() {
        val p = panel ?: return
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.94).toInt()
        val h = (dm.heightPixels * 0.62).toInt()
        panelShown = true
        if (!panelAttached) {
            val lp = WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = dp(30)
                softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
            }
            wm.addView(p, lp)
            panelAttached = true
        }
        p.animate().cancel()
        p.pivotX = w * 0.92f
        p.pivotY = 0f
        p.alpha = 0f
        p.scaleX = 0.7f
        p.scaleY = 0.7f
        p.translationY = -dp(12).toFloat()
        p.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(320).setInterpolator(OvershootInterpolator(1.1f)).start()
    }

    private fun hidePanel() {
        val p = panel ?: return
        if (!panelShown) return
        panelShown = false
        p.animate().cancel()
        p.animate().alpha(0f).scaleX(0.85f).scaleY(0.85f).translationY(-dp(8).toFloat())
            .setDuration(180).setInterpolator(DecelerateInterpolator())
            .withEndAction {
                if (!panelShown && panelAttached) {
                    runCatching { wm.removeView(p) }
                    panelAttached = false
                }
            }.start()
    }

    private fun setPending(bmp: Bitmap?) {
        pendingImage = bmp
        if (bmp != null) {
            preview.text = "Gambar terlampir • ketuk untuk menghapus"
            preview.visibility = View.VISIBLE
        } else {
            preview.visibility = View.GONE
        }
    }

    // ================= Pesan =================

    private fun scrollDown(smooth: Boolean = true) {
        scroll.post {
            if (smooth) scroll.smoothScrollTo(0, messages.height) else scroll.scrollTo(0, messages.height)
        }
    }

    private fun addMsg(text: String, user: Boolean, error: Boolean = false): TextView {
        val maxW = (resources.displayMetrics.widthPixels * 0.94 * 0.8).toInt()
        val tv = TextView(this).apply {
            this.text = text
            textSize = 14.5f
            maxWidth = maxW
            setLineSpacing(dp(2).toFloat(), 1f)
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setTextIsSelectable(true)
            background = when {
                error -> PanelUi.errorBubble(this@OverlayService)
                user -> PanelUi.userBubble(this@OverlayService)
                else -> PanelUi.aiBubble(this@OverlayService)
            }
            if (!user && !error) setTextColor(Ui.TEXT)
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = if (user) Gravity.END else Gravity.START
            topMargin = dp(8)
        }
        messages.addView(tv, lp)
        tv.alpha = 0f
        tv.translationY = dp(16).toFloat()
        tv.translationX = if (user) dp(18).toFloat() else -dp(18).toFloat()
        tv.animate().alpha(1f).translationY(0f).translationX(0f)
            .setDuration(300).setInterpolator(DecelerateInterpolator()).start()
        scrollDown()
        return tv
    }

    private fun startThinking() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = PanelUi.aiBubble(this@OverlayService)
            setPadding(dp(14), dp(9), dp(16), dp(9))
        }
        row.addView(WaveDots(this))
        row.addView(TextView(this).apply {
            text = "sedang berpikir"
            setTextColor(Ui.MUTED)
            textSize = 12f
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { leftMargin = dp(8) })
        messages.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.START
            topMargin = dp(8)
        })
        row.alpha = 0f
        row.animate().alpha(1f).setDuration(220).start()
        thinkingView = row
        scrollDown()
    }

    private fun stopThinking() {
        thinkingView?.let { messages.removeView(it) }
        thinkingView = null
    }

    /** Teks AI muncul bertahap (efek mengetik, dengan kursor titik). */
    private fun reveal(tv: TextView, full: String) {
        var idx = 0
        val step = max(3, full.length / 90)
        val r = object : Runnable {
            override fun run() {
                idx = minOf(full.length, idx + step)
                tv.text = if (idx < full.length) full.substring(0, idx) + " ●" else full
                scrollDown(false)
                if (idx < full.length) handler.postDelayed(this, 16) else revealRunnable = null
            }
        }
        revealRunnable = r
        handler.post(r)
    }

    // ================= Scan =================

    private fun scanScreen() {
        hidePanel()
        val cs = CaptureService.instance
        if (cs != null) {
            handler.postDelayed({ cs.capture() }, 500)
        } else {
            startActivity(Intent(this, ProjectionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun scanCamera() {
        hidePanel()
        startActivity(Intent(this, CameraActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ================= Kirim ke AI =================

    private fun stripOldImages() {
        for (i in 0 until history.length()) {
            val content = history.getJSONObject(i).opt("content")
            if (content is JSONArray) {
                for (j in 0 until content.length()) {
                    if (content.getJSONObject(j).optString("type") == "image") {
                        content.put(j, JSONObject().put("type", "text").put("text", "[gambar sebelumnya]"))
                    }
                }
            }
        }
    }

    private fun setBusy(b: Boolean) {
        busy = b
        sendBtn.alpha = if (b) 0.4f else 1f
        setBubbleBusy(b)
    }

    private fun send() {
        if (busy) return
        val q = input.text.toString().trim()
        val img = pendingImage
        if (q.isEmpty() && img == null) return
        if (Prefs.apiKey(this).isBlank()) {
            addMsg("⚠️ API key belum diisi. Buka app AI PITO lalu isi dulu.", user = false, error = true)
            return
        }

        removeSuggestions()
        stripOldImages()
        val content = JSONArray()
        if (img != null) {
            content.put(
                JSONObject().put("type", "image").put(
                    "source", JSONObject()
                        .put("type", "base64")
                        .put("media_type", "image/jpeg")
                        .put("data", Api.toBase64(img))
                )
            )
        }
        val text = if (q.isEmpty()) "Jawab, selesaikan, atau jelaskan isi gambar ini." else q
        content.put(JSONObject().put("type", "text").put("text", text))
        history.put(JSONObject().put("role", "user").put("content", content))

        addMsg((if (img != null) "📎 " else "") + text, user = true)
        startThinking()
        input.setText("")
        setPending(null)
        setBusy(true)

        Thread {
            var reply: String? = null
            var error: String? = null
            try {
                reply = Api.chat(this, history)
            } catch (e: Exception) {
                error = e.message ?: e.toString()
            }
            handler.post {
                stopThinking()
                if (reply != null) {
                    history.put(JSONObject().put("role", "assistant").put("content", reply))
                    reveal(addMsg("", user = false), reply)
                } else {
                    history.remove(history.length() - 1)
                    addMsg("⚠️ Error: $error", user = false, error = true)
                }
                setBusy(false)
            }
        }.start()
    }

    override fun onDestroy() {
        Bridge.onImage = null
        Bridge.onCancel = null
        handler.removeCallbacksAndMessages(null)
        bubbleAnims.forEach { it.cancel() }
        panel?.let { if (panelAttached) runCatching { wm.removeView(it) } }
        panelAttached = false
        bubble?.let { runCatching { wm.removeView(it) } }
        stopService(Intent(this, CaptureService::class.java))
        super.onDestroy()
    }
}
