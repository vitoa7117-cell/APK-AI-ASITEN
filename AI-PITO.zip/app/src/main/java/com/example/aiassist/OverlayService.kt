package com.example.aiassist

import android.animation.Animator
import android.animation.ObjectAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: ImageView? = null
    private var bubbleBg: GradientDrawable? = null
    private val bubbleAnims = mutableListOf<Animator>()

    private var panel: LinearLayout? = null
    private var panelShown = false
    private var panelAttached = false

    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var preview: TextView
    private lateinit var sendBtn: TextView

    private val history = JSONArray()
    private var pendingImage: Bitmap? = null
    private var busy = false

    private var thinkingView: TextView? = null
    private var thinkingRunnable: Runnable? = null
    private var revealRunnable: Runnable? = null

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startFg()
        buildPanel()
        buildBubble()

        Bridge.onImage = { bmp -> handler.post { setPending(bmp); showPanel() } }
        Bridge.onCancel = { handler.post { showPanel() } }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("overlay", "Bubble AI", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "overlay")
            .setContentTitle("AI PITO aktif")
            .setContentText("Ketuk bubble untuk bertanya")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ================= Bubble =================

    private fun buildBubble() {
        val size = dp(58)
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels

        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFF1A1033.toInt())
            setStroke(dp(2), Ui.CYAN)
        }
        bubbleBg = bg

        val v = ImageView(this).apply {
            setImageResource(R.drawable.ic_robot_bubble)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = bg
            elevation = dp(6).toFloat()
        }

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW - size
            y = screenH / 3
        }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + dx; lp.y = sy + dy
                        wm.updateViewLayout(view, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (panelShown) hidePanel() else showPanel()
                    } else {
                        lp.x = if (lp.x + size / 2 < screenW / 2) 0 else screenW - size
                        wm.updateViewLayout(view, lp)
                    }
                    true
                }
                else -> false
            }
        }
        bubble = v
        wm.addView(v, lp)

        // animasi masuk: membal muncul, lalu "bernapas"
        v.scaleX = 0f; v.scaleY = 0f; v.rotation = -90f
        v.animate().scaleX(1f).scaleY(1f).rotation(0f)
            .setDuration(650).setInterpolator(OvershootInterpolator(2f))
            .withEndAction {
                for (p in listOf("scaleX", "scaleY")) {
                    val a = ObjectAnimator.ofFloat(v, p, 1f, 1.08f).apply {
                        duration = 1200
                        repeatCount = ObjectAnimator.INFINITE
                        repeatMode = ObjectAnimator.REVERSE
                        interpolator = AccelerateDecelerateInterpolator()
                        start()
                    }
                    bubbleAnims.add(a)
                }
            }.start()
    }

    private fun setBubbleBusy(b: Boolean) {
        bubbleBg?.setStroke(dp(2), if (b) Ui.PINK else Ui.CYAN)
        bubble?.invalidate()
    }

    // ================= Panel chat =================

    private fun buildPanel() {
        val root = object : LinearLayout(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.action == KeyEvent.ACTION_UP) hidePanel()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF1F1442.toInt(), 0xFF0F172A.toInt())
        ).apply {
            cornerRadius = dp(22).toFloat()
            setStroke(dp(1), 0x5500E5FF)
        }
        root.elevation = dp(12).toFloat()

        // header
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_robot_bubble)
            background = Ui.rounded(0xFF1A1033.toInt(), dp(16), Ui.CYAN, dp(1))
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }, LinearLayout.LayoutParams(dp(34), dp(34)))

        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        titleBox.addView(TextView(this).apply {
            text = "AI PITO"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            textSize = 16f
            letterSpacing = 0.08f
        })
        titleBox.addView(TextView(this).apply {
            text = "● online"
            setTextColor(0xFF69F0AE.toInt())
            textSize = 10f
        })
        header.addView(titleBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val chipBg = { Ui.rounded(0xFF2E2358.toInt(), dp(14)) }
        header.addView(Ui.pill(this, "🗑", chipBg(), Color.WHITE, 13f) { clearChat() })
        header.addView(Ui.pill(this, "⏻", chipBg(), Ui.PINK, 13f) { stopSelf() }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) })
        header.addView(Ui.pill(this, "✕", chipBg(), Color.WHITE, 13f) { hidePanel() }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) })
        root.addView(header)

        // area chat
        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        scroll = ScrollView(this).apply { addView(messages); isVerticalScrollBarEnabled = false }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // lampiran
        preview = TextView(this).apply {
            setTextColor(0xFF9ECBFF.toInt())
            textSize = 12f
            background = Ui.rounded(0x2200E5FF, dp(10))
            setPadding(dp(10), dp(6), dp(10), dp(6))
            visibility = View.GONE
            setOnClickListener { setPending(null) }
        }
        root.addView(preview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) })

        // tombol scan
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val scanBg = { Ui.rounded(0x2200E5FF, dp(16), Ui.CYAN, dp(1)) }
        actions.addView(Ui.pill(this, "📱 Scan layar", scanBg(), Ui.CYAN, 12f) { scanScreen() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(Ui.pill(this, "📷 Kamera", scanBg(), Ui.CYAN, 12f) { scanCamera() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
        root.addView(actions)

        // input
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Tanya apa saja..."
            setHintTextColor(Ui.MUTED)
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 4
            background = Ui.rounded(Ui.FIELD, dp(20))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        sendBtn = Ui.pill(
            this, "➤",
            GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Ui.PURPLE, 0xFF00B8D4.toInt())).apply {
                shape = GradientDrawable.OVAL
            },
            Color.WHITE, 18f
        ) { send() }
        sendBtn.setPadding(0, 0, 0, 0)
        row.addView(sendBtn, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(8) })
        root.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })

        panel = root
        addWelcome()
    }

    private fun addWelcome() {
        addMsg("Halo! Aku AI PITO 🤖\nTanya apa saja, minta bantuan coding, atau scan layar/kamera.", user = false)
    }

    private fun clearChat() {
        if (busy) return
        revealRunnable?.let { handler.removeCallbacks(it) }
        revealRunnable = null
        while (history.length() > 0) history.remove(0)
        messages.removeAllViews()
        setPending(null)
        addWelcome()
    }

    private fun showPanel() {
        val p = panel ?: return
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.94).toInt()
        val h = (dm.heightPixels * 0.58).toInt()
        panelShown = true
        if (!panelAttached) {
            val lp = WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = dp(30)
                softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
            }
            wm.addView(p, lp)
            panelAttached = true
        }
        p.animate().cancel()
        p.pivotX = w * 0.92f
        p.pivotY = 0f
        p.alpha = 0f
        p.scaleX = 0.7f
        p.scaleY = 0.7f
        p.translationY = -dp(12).toFloat()
        p.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(320).setInterpolator(OvershootInterpolator(1.1f)).start()
    }

    private fun hidePanel() {
        val p = panel ?: return
        if (!panelShown) return
        panelShown = false
        p.animate().cancel()
        p.animate().alpha(0f).scaleX(0.85f).scaleY(0.85f).translationY(-dp(8).toFloat())
            .setDuration(180).setInterpolator(DecelerateInterpolator())
            .withEndAction {
                if (!panelShown && panelAttached) {
                    runCatching { wm.removeView(p) }
                    panelAttached = false
                }
            }.start()
    }

    private fun setPending(bmp: Bitmap?) {
        pendingImage = bmp
        if (bmp != null) {
            preview.text = "📎 Gambar terlampir  (ketuk untuk hapus)"
            preview.visibility = View.VISIBLE
        } else {
            preview.visibility = View.GONE
        }
    }

    // ================= Pesan =================

    private fun scrollDown(smooth: Boolean = true) {
        scroll.post {
            if (smooth) scroll.smoothScrollTo(0, messages.height) else scroll.scrollTo(0, messages.height)
        }
    }

    private fun addMsg(text: String, user: Boolean, error: Boolean = false): TextView {
        val maxW = (resources.displayMetrics.widthPixels * 0.94 * 0.8).toInt()
        val tv = TextView(this).apply {
            this.text = text
            textSize = 14f
            maxWidth = maxW
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setTextIsSelectable(true)
            background = when {
                error -> Ui.rounded(0x33FF4081, dp(16), Ui.PINK, dp(1))
                user -> Ui.gradient(Ui.PURPLE, 0xFF5B3FD6.toInt(), dp(16), GradientDrawable.Orientation.TL_BR)
                else -> Ui.rounded(Ui.CARD, dp(16), Ui.STROKE, dp(1))
            }
            if (!user && !error) setTextColor(Ui.TEXT)
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = if (user) Gravity.END else Gravity.START
            topMargin = dp(6)
        }
        messages.addView(tv, lp)
        tv.alpha = 0f
        tv.translationY = dp(14).toFloat()
        tv.animate().alpha(1f).translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        scrollDown()
        return tv
    }

    private fun startThinking() {
        val tv = addMsg("●", user = false)
        thinkingView = tv
        var n = 0
        val r = object : Runnable {
            override fun run() {
                n = (n + 1) % 4
                tv.text = "AI sedang berpikir " + "●".repeat(n).padEnd(3, '○')
                handler.postDelayed(this, 350)
            }
        }
        thinkingRunnable = r
        handler.post(r)
    }

    private fun stopThinking() {
        thinkingRunnable?.let { handler.removeCallbacks(it) }
        thinkingRunnable = null
        thinkingView?.let { messages.removeView(it) }
        thinkingView = null
    }

    /** Teks AI muncul bertahap (efek mengetik). */
    private fun reveal(tv: TextView, full: String) {
        var idx = 0
        val step = max(3, full.length / 90)
        val r = object : Runnable {
            override fun run() {
                idx = minOf(full.length, idx + step)
                tv.text = full.substring(0, idx)
                scrollDown(false)
                if (idx < full.length) handler.postDelayed(this, 16) else revealRunnable = null
            }
        }
        revealRunnable = r
        handler.post(r)
    }

    // ================= Scan =================

    private fun scanScreen() {
        hidePanel()
        val cs = CaptureService.instance
        if (cs != null) {
            handler.postDelayed({ cs.capture() }, 500)
        } else {
            startActivity(Intent(this, ProjectionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun scanCamera() {
        hidePanel()
        startActivity(Intent(this, CameraActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ================= Kirim ke AI =================

    private fun stripOldImages() {
        for (i in 0 until history.length()) {
            val content = history.getJSONObject(i).opt("content")
            if (content is JSONArray) {
                for (j in 0 until content.length()) {
                    if (content.getJSONObject(j).optString("type") == "image") {
                        content.put(j, JSONObject().put("type", "text").put("text", "[gambar sebelumnya]"))
                    }
                }
            }
        }
    }

    private fun setBusy(b: Boolean) {
        busy = b
        sendBtn.alpha = if (b) 0.4f else 1f
        setBubbleBusy(b)
    }

    private fun send() {
        if (busy) return
        val q = input.text.toString().trim()
        val img = pendingImage
        if (q.isEmpty() && img == null) return
        if (Prefs.apiKey(this).isBlank()) {
            addMsg("⚠️ API key belum diisi. Buka app AI PITO lalu isi dulu.", user = false, error = true)
            return
        }

        stripOldImages()
        val content = JSONArray()
        if (img != null) {
            content.put(
                JSONObject().put("type", "image").put(
                    "source", JSONObject()
                        .put("type", "base64")
                        .put("media_type", "image/jpeg")
                        .put("data", Api.toBase64(img))
                )
            )
        }
        val text = if (q.isEmpty()) "Jawab, selesaikan, atau jelaskan isi gambar ini." else q
        content.put(JSONObject().put("type", "text").put("text", text))
        history.put(JSONObject().put("role", "user").put("content", content))

        addMsg((if (img != null) "📎 " else "") + text, user = true)
        startThinking()
        input.setText("")
        setPending(null)
        setBusy(true)

        Thread {
            var reply: String? = null
            var error: String? = null
            try {
                reply = Api.chat(this, history)
            } catch (e: Exception) {
                error = e.message ?: e.toString()
            }
            handler.post {
                stopThinking()
                if (reply != null) {
                    history.put(JSONObject().put("role", "assistant").put("content", reply))
                    reveal(addMsg("", user = false), reply)
                } else {
                    history.remove(history.length() - 1)
                    addMsg("⚠️ Error: $error", user = false, error = true)
                }
                setBusy(false)
            }
        }.start()
    }

    override fun onDestroy() {
        Bridge.onImage = null
        Bridge.onCancel = null
        handler.removeCallbacksAndMessages(null)
        bubbleAnims.forEach { it.cancel() }
        panel?.let { if (panelAttached) runCatching { wm.removeView(it) } }
        panelAttached = false
        bubble?.let { runCatching { wm.removeView(it) } }
        stopService(Intent(this, CaptureService::class.java))
        super.onDestroy()
    }
}
