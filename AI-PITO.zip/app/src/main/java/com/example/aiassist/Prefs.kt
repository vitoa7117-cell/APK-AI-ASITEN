package com.example.aiassist

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object Prefs {
    const val DEFAULT_MODEL = "gemini-2.5-flash"

    /** Link kontak penjual key. Nomor WhatsApp penjual (format 62..., tanpa + dan tanpa 0 di depan). */
    const val BUY_KEY_URL = "https://wa.me/6285640483908?text=Halo%2C%20mau%20beli%20key%20AI%20PITO"

    /** Server Cobalt bawaan untuk unduh video non-TikTok, supaya pengguna tidak perlu setting apa-apa. Kosongkan kalau belum punya. Contoh: "https://cobalt.domainmu.com" */
    const val DEFAULT_COBALT = ""

    private fun sp(c: Context): SharedPreferences = try {
        val mk = MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            c, "secure_prefs", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        c.getSharedPreferences("plain_prefs", Context.MODE_PRIVATE)
    }

    fun soundOn(c: Context): Boolean =
        c.getSharedPreferences("ui_prefs", Context.MODE_PRIVATE).getBoolean("sound", true)

    fun setSound(c: Context, on: Boolean) {
        c.getSharedPreferences("ui_prefs", Context.MODE_PRIVATE).edit().putBoolean("sound", on).apply()
    }

    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""
    fun model(c: Context): String =
        (sp(c).getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL).ifBlank { DEFAULT_MODEL }

    fun save(c: Context, key: String, model: String) {
        sp(c).edit().putString("key", key.trim()).putString("model", model.trim()).apply()
    }
}
