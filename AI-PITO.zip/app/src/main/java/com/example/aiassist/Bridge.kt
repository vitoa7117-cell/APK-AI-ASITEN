package com.example.aiassist

import android.graphics.Bitmap

/** Jembatan sederhana antar Activity/Service. */
object Bridge {
    var onImage: ((Bitmap) -> Unit)? = null
    var onCancel: (() -> Unit)? = null
}
